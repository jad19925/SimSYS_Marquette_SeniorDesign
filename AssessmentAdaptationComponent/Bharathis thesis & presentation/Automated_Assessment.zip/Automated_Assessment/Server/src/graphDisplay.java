import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;	 
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.ChartFrame;
	 	 
public class graphDisplay{	 
  public void genGraph(File directory,String fileName,int level) {
	try {
	  // Create a simple Bar chart
	  DefaultCategoryDataset barDataset = new DefaultCategoryDataset();
	  File file = new File(directory,fileName);   //File to fetch data for the graph
	  InputStream in = new FileInputStream(file);
	  BufferedReader d = new BufferedReader(new InputStreamReader(in));
	  String line;     //line in file
	  int mark = 200;  //datapoint (Goal level score)
	  String score[] = new String[2]; //score string
	  int intScore;    //score in integer form
	  int count = 0;   //number of students in the same score range
	  int i =0;        //'for' loop iterator
	  
	  //read lines from file until EOF
	  while ((line = d.readLine()) != null){ 
	  	score = line.split("#");
	   	int noOfTimes = 0;
	   	//count the number of students at the exact same score
	   	for (int j=0; j < line.length(); j++){
	  	  if (line.charAt(j) == '#'){
	  	    noOfTimes++;
	  	  }
	  	}
	  	intScore = Integer.parseInt(score[0]);
        if(intScore >= mark){  //Falls under the previous data point          	
          count = count + noOfTimes;
        }
        else{ //new data point           	
          if(i != 0){  //should be done only 'after counting'
           	final String displayMark = Integer.toString(mark) + "-" + Integer.toString(mark + 9);  //Eg:10-19
        	barDataset.addValue(count, "mark", displayMark);
          }
          mark = (intScore/10)*10;  //get the datapoint from score. Eg:get datapoint 90 from score 96
          count = noOfTimes;
        }
        i++;
	  }
	  final String displayMark = Integer.toString(mark) + "-" + Integer.toString(mark + 9);
	  barDataset.setValue(count, "mark", displayMark);
	  d.close();
	            
	  //create chart with x-axis,y-axis and title
	  JFreeChart chart = ChartFactory.createBarChart3D(
	  "Class Performance","Marks", "No. of students",barDataset,
	  PlotOrientation.VERTICAL, false, true, false);
	  chart.setBackgroundPaint(Color.white);
	     
	  // Set the background color of the chart
	  chart.getTitle().setPaint(Color.blue);
	   
	  // Adjust the color of the title
	  CategoryPlot plot = chart.getCategoryPlot();
	     
	  // Get the Plot object for a bar graph
	  plot.setRangeGridlinePaint(Color.red);
	  CategoryItemRenderer renderer = plot.getRenderer();
	  renderer.setSeriesPaint(0, Color.red);
	  renderer.setSeriesPaint(1, Color.green);
	  ChartFrame chartFrame = new ChartFrame("Bar Chart for Level " + level, chart);
	  chartFrame.setVisible(true);
	  chartFrame.setSize(560, 400);
	}catch (Exception e) {
	  System.err.println("Problem occurred creating chart" + e.getMessage());
	}
  }
}

