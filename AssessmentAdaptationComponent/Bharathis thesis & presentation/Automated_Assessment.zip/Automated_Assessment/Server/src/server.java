import java.net.*;
import java.io.*;

public class server {
  static final int LISTENING_PORT = 3210;  //server port on which it is listening
  static int noOfLevels = 5;               //number of levels in the game
  
  public static void main(String[] args) {
	String inputDir = " ";   //Home directory in which files are stored
	String inputFile = " ";  //score board file
	String cmd = " ";        //Input command
	String fileName = "";    //score board filename
	
    File directory;        // The directory from which server gets the files that it serves
    ServerSocket listener; // Listens for connection requests.
    Socket connection;     // A socket for communicating with a client
       
    //Get the home directory in which files are stored
    System.out.println("Enter the java FileServer directory:");
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	try{
	  inputDir = reader.readLine();
	}catch (IOException e) {
	  System.out.println("Error!");
	  System.exit(1);
	}
	
	for(;;){  //If the command is not recognized, ask for command again
	  //Get the command
	  System.out.println("Cmd[listen\\display]:");
	  try{
	    cmd = reader.readLine();
	  }catch (IOException e) {
	    System.out.println("Error!");
	    System.exit(1);
	  }
	  System.out.println("cmd:" + cmd);
      directory = new File(inputDir);
      
	  if (cmd.startsWith("listen")){//If the command is 'listen'
        /* Check that the directory exists and
        is in fact a directory. */

        if ( ! directory.exists() ) {
          System.out.println("Specified directory does not exist.");
          return;
        }
        if (! directory.isDirectory() ) {
          System.out.println("The specified file is not a directory.");
          return;
        }

        //Remove the earlier contents of scoreboard files
        for(int i =0;i<noOfLevels;i++){
	      fileName = "MyFile" + i + ".txt";
          File file = new File(directory,fileName);
          try{
            BufferedWriter d = new BufferedWriter(new FileWriter(file,false));
	        d.write("");
	        d.close();
          }catch(Exception e){
          }
        }
    
        /* Listen for connection requests from clients. For
        each connection, create a separate Thread of type
        ConnectionHandler to process it. The ConnectionHandler
        class is defined below. The server runs until the
        program is terminated, for example by a CONTROL-C. */

        try {
          listener = new ServerSocket(LISTENING_PORT);
          System.out.println("Listening on port " + LISTENING_PORT);
          while (true) {
            connection = listener.accept();
            System.out.println("connection accepted");
            new ConnectionHandler(directory,connection); 
          }
        }catch (Exception e) {
          System.out.println("Server shut down unexpectedly.");
          System.out.println("Error: " + e);
          return;
        }
   
      }else if (cmd.startsWith("display")){  //If the command is display
		graphDisplay s = new graphDisplay();
		for(int i =0;i<noOfLevels;i++){
	      inputFile = "MyFile" + i + ".txt";
		  s.genGraph(directory, inputFile,i);//call the display graph function
		}
		break;
	  }else{
		System.out.println("Command not recognized");
	  }
    }
  } // end main()

  static class ConnectionHandler extends Thread {
    // An object of this class is a thread that will
    // process the connection with one client. The
    // thread starts itself in the constructor.

    File directory;       // The directory from which files are served
    Socket connection;    // A connection to the client.
    TextReader incoming;  // For reading data from the client.
    PrintWriter outgoing; // For transmitting data to the client.

    ConnectionHandler(File dir, Socket conn) {
      // Constructor. Record the connection and
      // the directory and start the thread running.
      directory = dir;
      connection = conn;
      start();
    }
  
    public void readFile (String fileName)throws Exception{		
	  // This is called by the run() command in response
	  // to "read <fileName>" command. If the file doesn't
	  // exist, send the message "error". Otherwise,
	  // send the message "ok" followed by the contents
	  // of the file.
	  System.out.println("Inside read file: First line");
	  File file = new File(directory,fileName);
	  try{  	 
	    if ( (! file.exists()) || file.isDirectory() ) {
	      // (Note: Don't try to send a directory, which
	      // shouldn't be there anyway.)
	      outgoing.println("error");
	      System.out.println("Inside read file: error");
	    }
	    else{
	      outgoing.println("ok");
	      System.out.println("Inside read file: ok");
	      InputStream in = new FileInputStream(file);
	      BufferedReader d = new BufferedReader(new InputStreamReader(in));
	      String line;   //line in file
	      int count = 0; //number of lines in the file
	      
	      //Count the number of lines in file
	      while ((line = d.readLine()) != null){
	        count ++;
	      }
	      outgoing.println(count);
	      System.out.println("Count:" +  count);
	      d.close();
	      in = new FileInputStream(file);
	      d = new BufferedReader(new InputStreamReader(in));
	      // Read and send lines from the file until
          // an end-of-file is encountered.
	      while ((line = d.readLine()) != null){ 
	   	    System.out.println("Data sent successfully:" +  line);
	        outgoing.println(line);
	      }
	      d.close();
	    }
	    outgoing.flush(); 
	    if (outgoing.checkError())
	      throw new Exception("Error while transmitting data.");
	  }catch(Exception e){
	  }
    }//End of readFile()

    public void writeFile(String fileName) throws Exception{
	  String line;
	  int count = 0;
	
	  System.out.println("Inside write file");
	  // This is called by the run() command in response
	  // to "write <fileName>" command. If the file doesn't
	  // exist, send the message "error". Otherwise,
	  // send the message "ok" followed by the writing the contents
	  // into the file.
	  File file = new File(directory,fileName);
	  if ( (! file.exists()) || file.isDirectory() ) {
	    // (Note: Don't try to write to a directory, which
	    // shouldn't be there anyway.)
	    outgoing.println("error");
	    System.out.println("Server sending response:error");
	  }else {
	    outgoing.println("ok");
		outgoing.flush();
		System.out.println("Server sending response:ok");
		try{
		  count = Integer.parseInt(incoming.getln());  //Get the number of lines to be written in the file
		}catch (Exception e){//Catch exception if any
		}
		System.out.println("Server count:" + count);
		try{
		  BufferedWriter d = new BufferedWriter(new FileWriter(file,false));
		  
		  //Write received lines into the file
		  for(int i = 0;i<count;i++){
		     line = incoming.getln();
			 d.write(line);
			 System.out.println("Wrire line:" + line);
			 d.newLine();
		  }
		  d.close();
		}catch (Exception e){//Catch exception if any
		  System.err.println("Error: " + e.getMessage());
		}
	  }
	  outgoing.flush();
	  if (outgoing.checkError())
	    throw new Exception("Error while transmitting data.");
    }//end of writeFile()

    public void run() {
      // This is the method that is executed by the thread.
      // It creates streams for communicating with the client,
      // reads a command from the client, and carries out that
      // command. The connection is logged to standard output.
      // An output beginning with ERROR indicates that a network
      // error occurred. A line beginning with OK means that
      // there was no network error, but does not imply that the
      // command from the client was a legal command.
      String command = "Command not read";
      System.out.println("run");
      try {
        incoming = new TextReader( connection.getInputStream() );
        outgoing = new PrintWriter( connection.getOutputStream() );
        System.out.println("Cmd :"); 
        command = incoming.getln();
        System.out.println("Cmd :" + command);
        if (command.startsWith("read")){
          String fileName = command.substring(5).trim();
          readFile(fileName);
        }else if (command.startsWith("write")){
    	  System.out.println("Cmd write");
          String fileName = command.substring(6).trim();
          writeFile(fileName);
        }else {
          outgoing.println("unknown command");
          outgoing.flush();
        }
        System.out.println("OK " + connection.getInetAddress() + " " + command);
      }catch (Exception e) {
        System.out.println("ERROR " + connection.getInetAddress() + " " + command + " " + e);
      }finally {
        try {
          incoming.close();
    	  outgoing.close();
          connection.close();
        }catch (IOException e) {
        }
      }
    }//end of run
  } // end nested class ConnectionHandler
}//end of server class

