/*Concept class*/

public class concept {
  public
	int moderateAnswerCount =0;   //Number of moderate answers in the entire concept
    int correctAnswerCount =0;    //Number of correct answers in the entire concept
    int wrongAnswerCount =0;      //Number of wrong answers in the entire concept
    int timeSpent =0;             //Time spent on the entire concept
    int avgTimeSpent =0;          //Average Time spent on the entire concept 
    int avgOptionsChangeCount =0; //Average number of times options are changed in the concept
    int optionsChangeCount =0;    //Number of times options are changed in the concept
    int noOfQns =0;               //Number of qns in the concept
    int marks = 0;                //Marks in the concept
    int difficulty = 0;           //Adaptation decision for the difficulty of the concept
    char grade;                   //Concept level grade
    concept(int noOfQ){           //Constructor
      noOfQns = noOfQ;  
    }
    
    void conceptCompleted(){	
    }
}
