/*Provides input for all the aspects - Will be removed once the main component of the game is integrated*/

import java.util.Random;
import java.io.*;
import static java.lang.Thread.sleep;

public class inputProvider {
  public
	String uname;          //username of the player
	Random generator = new Random();  //random number generator
	int selectedAns;       //answer selected by the player for a particular qn - randomly generated
	int correctAns;        //correct answer for a particular qn - randomly generated
	int moderateAns;       //moderate answer for a particular qn - randomly generated
	int optionsChangeCnt;  //number of times the player changes the option for a particular qn - randomly generated
	int noOfConcepts = 3;  //number of concepts in a particular level
	int noOfQns;           //number of questions in a particular concept - randomly generated
	int noOfStudents = 0;  //number of students
	int badMarker = 0;     //The number of students in the bad zone
	int avgMarker = 0;     //The number of students in between the bad and average zone
	String studentFlag = "";  //The student's knowledge scale[good/avg/bad]
	int noOfLevels = 5;    //Number of levels in the game
	
	void inputGenerator(){
		
	  //Get the number of students for whom the input should be generated	
	  System.out.println("Enter the number of students in class:");
	  BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	  try{
		noOfStudents = Integer.parseInt(reader.readLine());
	  }catch (IOException e) {
	    System.out.println("Error!");
	    System.exit(1);
	  }
	   
	  badMarker = (noOfStudents * 25)/100; //1/4 of total number of students have bad performance
	  avgMarker = (noOfStudents * 75)/100; //Majority(1/2) of students have average performance
	  for(int p = 0;p<noOfStudents;p++){
		System.out.println("Enter the student's username:");
		try{
		  uname = reader.readLine();
		}catch (IOException e) {
		  System.out.println("Error!");
		  System.exit(1);
		}
	
        level l[] = new level[noOfLevels];                 //level object
        for(int i=0; i<noOfLevels; i++){                         
		  System.out.println("Level:No. of concepts is " + noOfConcepts); 
	      l[i] = new level(noOfConcepts,i);               //Initialize number of concepts and the level id of a particular level
	      concept c[] = new concept[l[i].noOfConcepts];   //concept object
	    
		  for(int j=0; j<l[i].noOfConcepts; j++){
		    noOfQns = generator.nextInt(10) + 10; //Will generate a random number from 10 to 19.
		    System.out.println("Concept:No. of qns is " + noOfQns);
		    c[j] = new concept(noOfQns);          //Initialize number of qns in a particular concept
		    l[i].noOfQns += c[j].noOfQns;         //Total number of qns in a particular level
		    System.out.println("Level:no of qns is " + l[i].noOfQns);
	        quiz q[] = new quiz[c[j].noOfQns];    //quiz object
		   
		    for(int k=0; k<c[j].noOfQns; k++){ 
		      q[k] = new quiz();
			  q[k].screenDisplayed();   //When a quiz is displayed
			
			  if(p <= badMarker){  //If the student falls within the bad range
				/*Generating bad performance*/  
			    studentFlag = "bad";
			    selectedAns = generator.nextInt(4) + 1;   //Will generate a random number from 1 to 4.
			    correctAns = generator.nextInt(4) + 1;    //Will generate a random number from 1 to 4.
		        moderateAns = 5 - correctAns;             //Correct and moderate ans cannot be same.Moderate answer will from 1 to 4.
			    optionsChangeCnt = generator.nextInt(6);  //Will generate a random number from 0 to 5.
			  }else if((p> badMarker) && (p <= avgMarker)){ //If the student falls within the avg range
			    /*Generating avg performance*/
			    studentFlag = "avg";
			    selectedAns = generator.nextInt(4) + 1;   //Will generate a random number from 1 to 4.
			    //Try to make selected answer, correct
			    if(selectedAns < 3){
				  correctAns = selectedAns + generator.nextInt(3);
			    }else{
				  correctAns = selectedAns - generator.nextInt(3);
			    }
			    //Make the selected answer either correct or moderate
			    if(selectedAns == correctAns){
				  moderateAns = 5 - correctAns;            //Correct and moderate ans cannot be same. Moderate answer will from 1 to 4.
			    }else{
				  moderateAns = selectedAns;
			    }
			    optionsChangeCnt = generator.nextInt(4); //average options change count
			   
			  }else if (p > avgMarker){  //If the student falls within the good range	
			    studentFlag = "good";
			    /*Generating good performance*/
			    selectedAns = generator.nextInt(3) + 1;   //Will generate a random number from 1 to 4.
			    //Try to make selected answer, correct
			    if(selectedAns < 3){
			      moderateAns = selectedAns + generator.nextInt(3);
		        }else{
			      moderateAns = selectedAns - generator.nextInt(3);
			    }
			    //Make the selected answer either moderate or correct
			    if(selectedAns == moderateAns){
		          correctAns = 5 - moderateAns;             //Correct and moderate ans cannot be same.Moderate answer will from 1 to 4.
			    }else{
				  correctAns = selectedAns;
			    }
		        optionsChangeCnt = generator.nextInt(2);
			  }
		    
			  /*Sleep to make sure some time is spent on each qn*/
			  try
			  {
			    sleep(500);
			  }
			  catch (InterruptedException ex) {}
			
			  q[k].continueButtonPressed(selectedAns,correctAns,moderateAns,optionsChangeCnt,studentFlag,c[j],l[i]);  //When player has selected answer and pressed continue button for next qns
	        }
		    c[j].conceptCompleted(); //All qns in a particular concept are answered by the player
		    
		    /*To calculate final grade and to make adaptation decision whether the player passed the level*/
		    if(c[j].marks>= 30 && c[j].marks <= 50 ){
			  l[i].avgFlag = 1;  //To assess if the performance was average in any of the concepts in a particular level
			  System.out.println("avg flag set");
		    }else if (c[j].marks < 30){
			  l[i].badFlag = 1;  //To assess if the performance was bad in any of the concepts in a particular level
			  System.out.println("Bad flag set");
		    }
		  } 
		  l[i].levelCompleted();         //All concepts in a particular level are answered by the player 
		
	      l[i].nextLevelDisplay(uname);  //This level is completed by the player and the next level is displayed
		  System.out.println("nextlevel");
        }
	  }
    }	
}