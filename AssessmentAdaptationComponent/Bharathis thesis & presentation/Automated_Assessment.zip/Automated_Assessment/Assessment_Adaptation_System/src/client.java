import java.io.PrintWriter;
import java.net.Socket;

public class client {
  Socket connection;    // A socket for communicating with server
  TextReader incoming;  // For reading data from the client
  PrintWriter outgoing; // For transmitting data to the client
  String fileName;      //filename
  String command;       //command to be sent
  String line;          //line received
  String response = " ";//response received
  static final int LISTENING_PORT = 3210;  //Server port on which client listens
	  
  void readFile(level l){
   	try{
      connection = new Socket("127.0.0.1",LISTENING_PORT);
      System.out.println("Listening on port " + LISTENING_PORT);
    }catch (Exception e) {
      System.out.println("Client shut down unexpectedly.");
      System.out.println("Error: " + e);
      return;
   	}
    try{
      incoming = new TextReader( connection.getInputStream() );    // For reading data from the client.
      outgoing = new PrintWriter( connection.getOutputStream() ); // For transmitting data to the client.
    }catch (Exception e) {
      System.out.println("ERROR " + connection.getInetAddress() + " " + "Error in the reader and writer");
    }

    fileName = "MyFile" + l.level + ".txt";
	command = "read " + fileName;
	try{
      outgoing.println(command);
      System.out.println("Read command sent successfully");
    }catch(Exception e){
      System.err.println("Error while transmitting command.");
   	}
    outgoing.flush();
    try{
      response = incoming.getln();
    }catch (Exception e){//Catch exception if any
      System.err.println("Error: " + e.getMessage());
    }
    System.out.println("Read Response:" + response);
    if(response == "error"){
      System.out.println("Filename does not exist or it is a directory");
    }else{
      System.out.println("Starting to receive data");	
      try{
        l.noOfEntires = Integer.parseInt(incoming.getln()); //receive the number of entries in score board from the server
        l.scoreBoard = new String[l.noOfEntires + 1];       //to add one more student's score, 
                                                            //the score board size should be increased by 1 of the actual size
        System.out.println("Received topscorers cnt:" + l.noOfEntires);
      }catch (Exception e){//Catch exception if any
        System.err.println("Error: " + e.getMessage());
      }
      System.out.println("Received entries cnt:" + l.noOfEntires);
      for(int i =0;i<l.noOfEntires;i++){
        try{
    	  line = incoming.getln();
    	  l.scoreBoard[i] = line; //push the received score from server into temporary scoreBoard in client 
    	  System.out.println("Received scoreboard:" + l.scoreBoard[i]);    		    	  
        }catch (Exception e){//Catch exception if any
          System.err.println("Error while receiving data:" + e.getMessage());
        }
      }
    } 
    try{
      incoming.close();
      outgoing.close();
      connection.close();
    }catch(Exception e){
      System.err.println("Error while closing incoming connection");
    }
  }//End of readFile()
	
  void writeFile(level l){
    try {
   	  connection = new Socket("127.0.0.1",LISTENING_PORT);
	  System.out.println("Listening on port " + LISTENING_PORT);
	}catch (Exception e) {
	  System.out.println("Client shut down unexpectedly.");
	  System.out.println("Error: " + e);
	  return;
	}
	try{
	  incoming = new TextReader( connection.getInputStream() );   // For reading data from the client.
	  outgoing = new PrintWriter( connection.getOutputStream() ); // For transmitting data to the client.
	}catch (Exception e) {
	  System.out.println("ERROR " + connection.getInetAddress() + " " + "Error in the reader and writer");
	}
	fileName = "MyFile" + l.level + ".txt";
	command = "write " + fileName;
	try{
	  outgoing.println(command);
	  System.out.println("Write command sent successfully");
	}catch(Exception e){
	  System.err.println("Error while transmitting command.");
	}
	outgoing.flush();

	response = " ";
	try{
	  response = incoming.getln();
	  System.out.println("Write Response:" + response);    		  
	}catch (Exception e){//Catch exception if any
	  System.err.println("Error: " + e.getMessage());
	}
	System.out.println("Write Response:" + response);
	if(response == "error"){
	  System.out.println("Filename does not exist or it is a directory");
	}else{
	  System.out.println("Starting to write data");	
	  try{
	    outgoing.println(l.noOfEntires); //send the number of entries in score board to the server
	    outgoing.flush();
	  	System.out.println("Sent topscorers cnt:" + l.noOfEntires);
	  }catch (Exception e){//Catch exception if any
	    System.err.println("Error: " + e.getMessage());
	  }
	  for(int i =0;i<l.noOfEntires;i++){
	    try{  	       
	      outgoing.println(l.scoreBoard[i]);//send the scoreBoard to server
	      outgoing.flush();
	      System.out.println("Sent scoreboard:" + l.scoreBoard[i]);	    	  
	    }catch (Exception e){//Catch exception if any
	      System.err.println("Error while receiving data:" + e.getMessage());
	    }
	  }
	} 
	try{
	  incoming.close();
	  outgoing.close();
	  connection.close();
	}catch(Exception e){
	  System.err.println("Error while closing incoming connection");
	}
  }//End of writeFile()
}//End of client class