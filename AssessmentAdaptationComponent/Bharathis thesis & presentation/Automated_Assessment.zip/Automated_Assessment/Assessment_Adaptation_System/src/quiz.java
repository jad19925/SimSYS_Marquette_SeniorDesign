/*Quiz class*/

public class quiz {
  public
	int selectedAnswer = 0;    //answer selected by the player for this qn
    int correctAnswer = 0;     //correct answer for this qn
    int moderateAnswer = 0;    //moderate answer for this qn
    int optionsChangeCount = 0;//number of times the player changes the option for this qn
    String studentFlag;        //Students knowledge level
    
    void screenDisplayed(){
    }
    
    void continueButtonPressed(int selectedAns,int correctAns,int moderateAns,int optionsChangeCnt,String stdntFlag,concept c,level l){	
      selectedAnswer = selectedAns;
      correctAnswer  = correctAns;
      moderateAnswer = moderateAns;
      optionsChangeCount = optionsChangeCnt;
      studentFlag = stdntFlag;
      System.out.println("selectedAnswer: " + selectedAns + "correctAnswer:" + correctAns + "moderateAnswer:" + moderateAns + "optionsChangeCount:" + optionsChangeCnt);
    }
}
