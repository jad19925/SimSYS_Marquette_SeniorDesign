//Downloaded from math.hws.edu

import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The TextReader class provides methods for reading data expressed in human-readable
 * character format.  A TextReader can be used as a wrapper for any Reader or
 * InputStream to enable easy character-based input.
 * 
 * Note that all of the input methods in this class throw errors of type
 * IOException.  An IOException can occur when an attempt is made to read
 * data from the input source.  An error can occur if an attempt is made to
 * read past the end of the input source; the exception in this case is of
 * type TextReader.EndOfStreamError, which is a subclass of IOException.
 * An error can also occur if an attempt is made to read data of a particular
 * type from the input and the next item in input is not of the correct type;
 * in this case, the error is of type TextReader.BadDataException, which is
 * another subclass of IOException.
 * 
 * Once an input stream has been wrapped in a TextReader, data should only be
 * read from the stream using the wrapper.  This is because the TextReader reads
 * and buffers some data internally, and any data that has been buffered is not
 * available for reading except through the TextReader.
 */

public class TextReader {
  private String buffer = null;  // One line read from input.
  private int pos = 0;           // Position of next char in input line that has not yet been processed.
  private BufferedReader in;     // The actual source of the input.
  public final char EOF = (char)0xFFFF; 
	  
  /**
   * Create a TextReader that will take its input from a specified Reader.
   * @s the non-null Reader from which the TextReader will read.
   * @throws NullPointerException if s is null.
   */
  public TextReader(Reader s) {
	if ( s == null )
	  throw new NullPointerException("Can't create a TextReader for a null stream.");
	if (s instanceof BufferedReader)
	  in = (BufferedReader)s;
	else
	  in = new BufferedReader(s);
  }
	
  /**
   * Create a TextReader that will take its input from a specified InputStream.
   * (Internally, the InputStream is wrapped in a Reader of type InputStreamReader.)
   * @s the non-null InputStream from which the TextReader will read.
   * @throws NullPointerException if s is null.
   */
  public TextReader(InputStream s) {
	this( new InputStreamReader(s) );
  }
	   
  private void fillBuffer() throws IOException { // Wait for user to type a line and press return,
	buffer = in.readLine();
	pos = 0;
  }
	
  private char lookChar() throws IOException {  // return next character from input
	if (buffer == null || pos > buffer.length())
	  fillBuffer();
	if (buffer == null)
	  return EOF;
	else if (pos == buffer.length())
	  return '\n';
	else 
	  return buffer.charAt(pos);
  }
	
  /**
   * Represents the error of trying to read past the end of the input source
   * of the TextReader.  Users of the class could catch this exception to
   * detect end-of-stream.  This is a subclass of IOException, so catching
   * IOException will also catch end-of-stream errors.
   */
  public static class EndOfStreamException extends IOException {  
	public EndOfStreamException() {  
	  super("Attempt to read past end-of-stream.");
	}
  }
	 
  private char readChar() throws IOException {  // return and discard next character from input
	char ch = lookChar();
	if (buffer == null) {
	  throw new EndOfStreamException();
	}
	pos++;
	return ch;
  }
	
  /**
   * Reads all the characters from the input source, up to the next end-of-line.  The end-of-line
   * is read but is not included in the return value.  Any other whitespace characters on the line 
   * are retained, even if they occur at the start of input.  The return value will be an empty 
   * string if there are no characters before the end-of-line.  An error occurs if an attempt is 
   * made to read past end-of-file or if an IOException is thrown when an attempt is made to 
   * read data from the input source.
   */
  public String getln() throws IOException {
	StringBuffer s = new StringBuffer(100);
	char ch = readChar();
	while (ch != '\n') {
	  s.append(ch);
	  ch = readChar();
	}
	return s.toString();
  }
	
  /**
   * Closes the stream that is the input source for this TextReader by
   * calling its close() method.  Does not throw any exceptions; if
   * an exception occurs when the input source is closed, that exception
   * is ignored.
   */
  public void close()  {
	try {   
	  in.close();
	}
	catch (IOException e) {
	}
  }  
}