/*Call main function*/

public class mainClass {
  public static void main(String[] args) {
	inputProvider ip = new inputProvider();
	ip.inputGenerator();   //call the input generator
  }
}
