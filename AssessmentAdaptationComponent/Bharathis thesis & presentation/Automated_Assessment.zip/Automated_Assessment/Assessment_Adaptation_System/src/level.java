/*Level class*/

public class level {
  public
	int moderateAnswerCount =0;    //Number of moderate answers in the entire level
    int correctAnswerCount =0;     //Number of correct answers in the entire level
    int wrongAnswerCount =0;       //Number of wrong answers in the entire level
    int timeSpent =0;              //Time spent on the entire level
    int optionsChangeCount =0;     //Number of times options are changed in the level
    int avgTimeSpent = 0;          //Average Time spent on the entire level 
    int avgOptionsChange = 0;      //Average number of times options are changed in the level
    int noOfConcepts =0;           //Number of concepts in the level
    int noOfQns =0;                //Number of qns in the level
    int marks = 0;                 //Marks in the level
    int nextLevel = 0;             //Adaptation decision whether the student passed this level or not
                                   //Next level based on the current level's performance
    char grade;                    //Goal level grade
    char finalGrade;               //Final Grade in current level
    int position = 0;              //Position of the player in this level in the score board
    int noOfEntires = 0;           //Number of entries currently in the score board
    int avgFlag = 0;               //Flag indicating if the player's performance is average in any concept of this level
	int badFlag = 0;               //Flag indicating if the player's performance is bad in any concept of this level
	int level = 0;                 //current level
	String scoreBoard[];           //Score board of players
	
    level(int noOfCnpts, int lvl){    //constructor
      noOfConcepts = noOfCnpts;
      level = lvl;
    }
    void levelCompleted(){		
    }
    void nextLevelDisplay(String uname){	
    } 
}
