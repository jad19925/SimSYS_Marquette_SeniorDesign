package edu.utdallas.gamegenerator.Structure;

/**
 * User: clocke
 * Date: 2/24/13
 * Time: 8:59 PM
 */
public class Screen {
}
