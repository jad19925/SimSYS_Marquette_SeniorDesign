package edu.utdallas.gamegenerator.LearningObjective;

import java.util.List;

/**
 * User: clocke
 * Date: 2/17/13
 * Time: 4:58 PM
 */
public class LearningObjective {
    private List<Lesson> lessons;

    public List<Lesson> getLessons() {
        return lessons;
    }

    public void setLessons(List<Lesson> lessons) {
        this.lessons = lessons;
    }
}
