package edu.utdallas.gamegenerator.LearningObjective.Character;

/**
 * User: clocke
 * Date: 2/17/13
 * Time: 4:05 PM
 */
public enum Movement {
    WALK_ONTO_SCREEN,
    WALK_OFF_SCREEN;

}
