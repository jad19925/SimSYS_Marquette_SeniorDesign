package edu.utdallas.gamegenerator.LearningObjective.Challenge;

/**
 * User: clocke
 * Date: 2/17/13
 * Time: 3:30 PM
 */
public class Reward {
}
