package edu.utdallas.gamegenerator.LearningObjective.Challenge;

/**
 * User: clocke
 * Date: 2/17/13
 * Time: 4:23 PM
 */
public enum ChallengeOptionType {
    BUTTON,
    TIMER;
}
