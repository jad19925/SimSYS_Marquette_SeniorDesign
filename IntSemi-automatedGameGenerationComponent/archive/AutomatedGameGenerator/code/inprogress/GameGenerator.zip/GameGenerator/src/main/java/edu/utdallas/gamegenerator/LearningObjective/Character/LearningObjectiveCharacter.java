package edu.utdallas.gamegenerator.LearningObjective.Character;

import edu.utdallas.gamegenerator.Shared.GameObject;

/**
 * User: clocke
 * Date: 2/17/13
 * Time: 3:29 PM
 */
public class LearningObjectiveCharacter extends GameObject {
    private LearningObjectiveCharacterType characterType;
    private Movement movement;

}
