package edu.utdallas.gamegenerator.LearningObjective.Screen;

/**
 * User: clocke
 * Date: 2/17/13
 * Time: 4:43 PM
 */
public class LearningObjectiveFailure extends LearningObjectiveScreen {
    @Override
    public ScreenType getType() {
        return ScreenType.FAILURE;
    }
}
