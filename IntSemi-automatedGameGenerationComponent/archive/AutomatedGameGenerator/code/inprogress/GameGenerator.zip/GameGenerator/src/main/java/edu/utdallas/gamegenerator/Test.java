package edu.utdallas.gamegenerator;

/**
 * Company: Porpoise Software
 * User: Terminus Est
 * Date: 3/3/13
 * Time: 10:10 PM
 */
public class Test {
    public static void main(String[] args) {
        TestObjects testObjects = new TestObjects();
        testObjects.getTheme().getIntro();

        System.out.println();
    }
}
