package edu.utdallas.gamegenerator.LearningObjective.Screen;

/**
 * User: clocke
 * Date: 2/15/13
 * Time: 9:45 PM
 */
public enum ScreenType {
    LESSON, CHALLENGE, FAILURE, SUCCESS, NEUTRAL
}
