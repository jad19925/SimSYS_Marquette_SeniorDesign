package edu.utdallas.gamegenerator.Structure;

import edu.utdallas.gamegenerator.ScreenNode;

import java.util.List;

/**
 * User: clocke
 * Date: 2/24/13
 * Time: 8:58 PM
 */
public class Scene {
    List<Screen> screens;
}
