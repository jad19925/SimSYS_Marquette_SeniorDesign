package edu.utdallas.gamegenerator.Structure;

import java.util.List;

/**
 * User: clocke
 * Date: 2/24/13
 * Time: 8:54 PM
 */
public class Game {
    List<Act> acts;
}
