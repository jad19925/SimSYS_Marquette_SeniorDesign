package edu.utdallas.gamegenerator.LearningObjective.Screen;

/**
 * User: clocke
 * Date: 2/17/13
 * Time: 3:33 PM
 */
public enum TransitionType {
    BEGINNING_OF_LEARNING_OBJECTIVE,
    BEGINNING_OF_LESSON,
    BEGINNING_OF_STORY,
    BEGINNING_OF_CHALLENGE,
    NEXT_ACT,
    ADDITIONAL,
    NEXT_LESSON,
    NEXT_CHALLENGE;
}
