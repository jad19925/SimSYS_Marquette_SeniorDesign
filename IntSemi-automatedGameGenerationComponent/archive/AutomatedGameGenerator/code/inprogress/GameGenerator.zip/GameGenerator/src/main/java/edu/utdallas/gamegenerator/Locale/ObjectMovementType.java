package edu.utdallas.gamegenerator.Locale;

/**
 * User: clocke
 * Date: 2/24/13
 * Time: 8:46 PM
 */
public enum ObjectMovementType {
    WALK,
    RUN,
    JUMP,
    SIT;
}
