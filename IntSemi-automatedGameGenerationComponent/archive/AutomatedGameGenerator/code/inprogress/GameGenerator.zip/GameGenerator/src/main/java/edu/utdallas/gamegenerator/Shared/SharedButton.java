package edu.utdallas.gamegenerator.Shared;

/**
 * Company: Porpoise Software
 * User: Terminus Est
 * Date: 3/3/13
 * Time: 10:24 PM
 */
public class SharedButton extends GameObject {
    public SharedButton(int locX, int locY, int width, int height, String pathToAsset) {
        super(locX, locY, width, height, pathToAsset);
    }
}
