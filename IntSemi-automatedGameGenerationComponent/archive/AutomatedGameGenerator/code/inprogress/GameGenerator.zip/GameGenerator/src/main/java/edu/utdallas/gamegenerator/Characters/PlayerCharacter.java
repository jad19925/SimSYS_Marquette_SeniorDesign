package edu.utdallas.gamegenerator.Characters;

/**
 * User: clocke
 * Date: 2/17/13
 * Time: 6:04 PM
 */
public class PlayerCharacter extends GameCharacter {
}
