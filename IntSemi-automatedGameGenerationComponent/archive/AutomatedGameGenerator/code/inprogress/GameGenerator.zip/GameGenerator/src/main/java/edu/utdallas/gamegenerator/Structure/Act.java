package edu.utdallas.gamegenerator.Structure;

import java.util.List;

/**
 * User: clocke
 * Date: 2/24/13
 * Time: 8:58 PM
 */
public class Act {
    List<Scene> scenes;
}
