﻿using System;
using System.ComponentModel;
using System.Linq.Expressions;

namespace Common
{
    public class NotifyPropertyChangedBase : INotifyPropertyChanged
    {
        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;


        protected void NotifyPropertyChanged(string name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }

        protected void NotifyOfPropertyChange<TProperty>(Expression<Func<TProperty>> property)
        {
            var body = property.Body as MemberExpression;
            if (body == null)
            {
                throw new ArgumentException("The body must be a member expression");
            }
            NotifyPropertyChanged(body.Member.Name);
        }

        #endregion
    }
}