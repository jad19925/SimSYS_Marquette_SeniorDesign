﻿using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using GameWizard.GameServiceRef;
using GameWizard.Tools;
using GameWizard.ViewModel;
using GameWizard.VisibleAssets;
using GameWizardModel;

namespace GameWizard
{
    public partial class ScreenPreview : UserControl
    {
        #region Private Fields

        private readonly GameServiceClient _client;
        private readonly ToolFactory _toolFactory;
        private readonly List<VisibleAssetBase> _visibleAssets;
        private bool _buttonDown;
        private VisibleAssetBase _currentAsset;
        private AssetContainer _screen;

        #endregion

        #region Public Properties

        public AssetContainer Screen
        {
            set
            {
                if (_screen != null)
                {
                    _screen.PropertyChanged -= Screen_PropertyChanged;
                    _currentAsset = null;
                    SetVMAsset(null);
                }
                _screen = value;
                if (_screen != null)
                {
                    _screen.PropertyChanged += Screen_PropertyChanged;
                }
                DrawScreen();
            }
        }

        #endregion

        #region Construtors

        public ScreenPreview()
        {
            InitializeComponent();

            _visibleAssets = new List<VisibleAssetBase>();
            _toolFactory = new ToolFactory();

            _client = new GameServiceClient();
            _client.GetBackgroundCompleted += client_GetBackgroundCompleted;
        }

        #endregion

        #region Asset Drawing

        public void Refresh()
        {
            DrawScreen();
        }

        private void DrawScreen()
        {
            canvas.Children.Clear();
            _visibleAssets.Clear();

            if (_screen == null)
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(_screen.Background) == false)
            {
                _client.GetBackgroundAsync(_screen.Background);
            }

            foreach (AssetBase asset in _screen.Assets)
            {
                VisibleAssetBase visualAsset = ToolFactory.CreateAsset(asset);
                if (visualAsset != null)
                {
                    _visibleAssets.Add(visualAsset);
                    canvas.Children.Add(visualAsset.UIElement);
                }
            }

            //canvas.Children.Add(new Line { X1 = 10, Y1 = 10, X2 = 50, Y2 = 50, Stroke = new SolidColorBrush(Colors.Black), StrokeThickness = 2 });
            //canvas.Children.Add(new TextBlock { Text = "This is a test this is only a test", Width = 100, Height = 100, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(100, 100, 0, 0) });
        }

        #region Event Handlers

        private void Screen_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            DrawScreen();
        }

        #endregion

        #endregion

        #region Service Callbacks

        private void client_GetBackgroundCompleted(object sender, GetBackgroundCompletedEventArgs e)
        {
            if (e.Result != null)
            {
                var image = new BitmapImage();
                var stream = new MemoryStream(e.Result);
                image.SetSource(stream);

                canvas.Children.Insert(0,
                                       new Image
                                           {
                                               Source = image,
                                               Stretch = Stretch.Uniform,
                                               Width = canvas.ActualWidth,
                                               Height = canvas.ActualHeight
                                           });
            }
        }

        #endregion

        #region Mouse Handlers

        private void UX_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Point point = e.GetPosition(this);

            _buttonDown = true;

            //first see if there is no current asset or if there is one see if the current asset doesn't want the mouse.
            if (_currentAsset == null || _currentAsset.MouseDown(point) == false)
            {
                //if the current tool is an arrow then see what got hit
                if (_toolFactory.MouseDown(point) == false)
                {
                    VisibleAssetBase selected = HitTest(point);
                    //if we hit something different than we already have selected
                    if (selected != _currentAsset)
                    {
                        //first clear the currently selected item
                        if (_currentAsset != null)
                        {
                            UnselectCurrentAsset();
                        }

                        //select the new item
                        if (selected != null)
                        {
                            SelectAsset(selected);
                        }
                    }
                    if (_currentAsset != null)
                    {
                        _currentAsset.MouseDown(point);
                        //this is just so we get the new mouse cursor
                        UX_MouseMove(sender, e);
                    }
                }
                    //if a new asset was created
                else if (_toolFactory.CurrentAsset != null)
                {
                    UnselectCurrentAsset();

                    AddNewAsset(_toolFactory.CurrentAsset);
                }
            }
        }

        private void UX_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Point point = e.GetPosition(this);
            //if the tool didn't want the mouse up message and we have a current asset
            //pass the message to it.
            if (_toolFactory.MouseUp(point) == false && _currentAsset != null)
            {
                _currentAsset.MouseUp(point);
            }
            _buttonDown = false;
            //set the current tool to arrow
            _toolFactory.CurrentTool = ToolFactory.ToolType.Arrow;
        }

        private void UX_MouseMove(object sender, MouseEventArgs e)
        {
            //if the mouse is down then tell the tool factory about the new position
            if (_toolFactory.CurrentTool != ToolFactory.ToolType.Arrow)
            {
                Cursor = _toolFactory.MouseMove(e.GetPosition(this), _buttonDown);
            }
            else if (_currentAsset != null)
            {
                Cursor = _currentAsset.MouseMove(e.GetPosition(this), _buttonDown);
            }
            else
            {
                Cursor = Cursors.Arrow;
            }
        }

        #endregion

        #region Private Methods

        private void DeleteSelectedItem()
        {
            if (_currentAsset != null)
            {
                _visibleAssets.Remove(_currentAsset);
                _screen.Assets.Remove(_currentAsset.Asset);
                _currentAsset = null;
                SetVMAsset(null);
                DrawScreen();
            }
        }

        private VisibleAssetBase HitTest(Point point)
        {
            foreach (VisibleAssetBase asset in _visibleAssets)
            {
                if (asset.HitTest(point))
                {
                    return asset;
                }
            }
            return null;
        }

        private void SelectAsset(VisibleAssetBase selected)
        {
            canvas.Children.Add(selected.SelectedRect);
            canvas.Children.Add(selected.UpperLeftHandle);
            canvas.Children.Add(selected.LowerLeftHandle);
            canvas.Children.Add(selected.UpperRightHandle);
            canvas.Children.Add(selected.LowerRightHandle);

            _currentAsset = selected;

            SetVMAsset(_currentAsset);
        }


        public void SetTool(ToolFactory.ToolType tool, object toolData = null, byte[] imageData = null)
        {
            _toolFactory.ToolData = toolData;
            _toolFactory.ImageData = imageData;
            _toolFactory.CurrentTool = tool;
        }

        private void AddNewAsset(VisibleAssetBase asset)
        {
            if (asset == null)
            {
                return;
            }
            //add the asset to the screen
            _screen.Assets.Add(asset.Asset);

            _visibleAssets.Add(asset);

            //set the current asset to it
            SelectAsset(asset);

            canvas.Children.Add(asset.UIElement);
        }

        private void UnselectCurrentAsset()
        {
            if (_currentAsset == null)
            {
                return;
            }

            canvas.Children.Remove(_currentAsset.SelectedRect);
            canvas.Children.Remove(_currentAsset.UpperLeftHandle);
            canvas.Children.Remove(_currentAsset.LowerLeftHandle);
            canvas.Children.Remove(_currentAsset.UpperRightHandle);
            canvas.Children.Remove(_currentAsset.LowerRightHandle);

            _currentAsset = null;

            SetVMAsset(null);
        }

        private void SetVMAsset(VisibleAssetBase asset)
        {
            var previewVM = DataContext as PreviewVM;
            previewVM.SelectedAsset = asset;
        }

        #endregion

        private void UserControl_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            cm.HorizontalOffset = e.GetPosition(this).X + 2;
            cm.VerticalOffset = e.GetPosition(this).Y + 2;
            cm.IsOpen = true;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            var menuItem = (MenuItem) sender;
            switch (menuItem.Header.ToString())
            {
                case "Cut":
                case "Copy":
                case "Paste":
                    break;
                default:
                    break;
            }
            cm.IsOpen = false;
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            DeleteSelectedItem();
        }
    }
}