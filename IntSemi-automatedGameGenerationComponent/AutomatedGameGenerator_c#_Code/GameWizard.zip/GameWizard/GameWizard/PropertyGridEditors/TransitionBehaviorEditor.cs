﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using GameWizard.PropertyWindows;
using GameWizard.ViewModel;
using GameWizardModel;
using SLPropertyGrid;

namespace GameWizard.PropertyGridEditors
{
    public class TransitionBehaviorEditor : ValueEditorBase
    {
        #region Private Fields

        private readonly Button _button;
        private readonly Game _game;
        private readonly Grid _panel;
        private readonly TransitionTargetSelectorVM _transitionTargetSelectorVM;
        private readonly TextBox _txt;

        #endregion

        public TransitionBehaviorEditor(PropertyGridLabel label, PropertyItem property, object data)
            : base(label, property)
        {
            _game = data as Game;

            _transitionTargetSelectorVM = new TransitionTargetSelectorVM(_game);
            property.PropertyChanged += property_PropertyChanged;
            property.ValueError += property_ValueError;

            _panel = new Grid();
            _panel.ColumnDefinitions.Add(new ColumnDefinition());
            _panel.ColumnDefinitions.Add(new ColumnDefinition());
            _panel.Height = 20;
            Content = _panel;

            _txt = new TextBox();
            //txt.Height = 20;
            if (null != property.Value)
            {
                GameBase item = _game.GetGameObject((Guid) property.Value);
                if (item != null)
                {
                    _txt.Text = item.Name;
                }
                else
                {
                    _txt.Text = "Click Button to Edit";
                }
            }
            else
            {
                _txt.Text = "Click Button to Edit";
            }
            _txt.IsReadOnly = true;
            _txt.Foreground = Property.CanWrite ? new SolidColorBrush(Colors.Black) : new SolidColorBrush(Colors.Gray);
            _txt.Background = new SolidColorBrush(Colors.White);
            _txt.BorderThickness = new Thickness(0);
            _txt.Margin = new Thickness(0);
            _txt.Padding = new Thickness(2);
            _txt.SetValue(Grid.ColumnProperty, 0);
            _panel.Children.Add(_txt);

            if (null != property.Value)
            {
                //button = new Button() { Content = "Click to Edit" };
                _button = new Button {Content = "..."};
                _button.Click += button_Click;
                _button.Margin = new Thickness(1);
                _button.SetValue(Grid.ColumnProperty, 1);
                _panel.Children.Add(_button);
                _panel.ColumnDefinitions[1].Width = new GridLength(20);
            }
            else
                Grid.SetColumnSpan(_txt, 2);

            GotFocus += StringValueEditor_GotFocus;
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if (Property.Value != null)
            {
                var child = new TransitionTargetSelector(_transitionTargetSelectorVM);
                child.Closed += child_Closed;
                child.Show();
            }
        }

        private void child_Closed(object sender, EventArgs e)
        {
            var dlg = sender as TransitionTargetSelector;
            if (dlg.DialogResult == true && _transitionTargetSelectorVM.SelectedItem != null)
            {
                Property.Value = _transitionTargetSelectorVM.SelectedItem.ID;
                _txt.Text = _transitionTargetSelectorVM.SelectedItem.Name;
            }
        }

        private void property_ValueError(object sender, ExceptionEventArgs e)
        {
            MessageBox.Show(e.EventException.Message);
        }

        private void property_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Value")
            {
                if (null != Property.Value)
                    _txt.Text = Property.Value.ToString();
                else
                    _txt.Text = string.Empty;
            }

            if (e.PropertyName == "CanWrite")
            {
                _txt.Foreground = Property.CanWrite
                                      ? new SolidColorBrush(Colors.Black)
                                      : new SolidColorBrush(Colors.Gray);
            }
        }

        private void StringValueEditor_GotFocus(object sender, RoutedEventArgs e)
        {
            if (_button != null)
                _button.Focus();
        }
    }
}