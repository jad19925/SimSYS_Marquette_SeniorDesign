﻿using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Common;
using GameWizard.VisibleAssets;
using GameWizardModel;
using SLPropertyGrid;

namespace GameWizard.ViewModel
{
    public class BehaviorPropertiesVM : NotifyPropertyChangedBase, IPropertyWindowDataProvider
    {
        //this is only used between the veiw and the viewmodel
        public enum BehaviorType
        {
            Transition,
            Reward,
            Visibility,
            EndGame
        }

        #region Fields

        private readonly RelayCommand _addCommand;
        private readonly Game _game;
        private readonly RelayCommand _removeCommand;
        private ObservableCollection<BehaviorType> _behaviorTypes;
        private BehaviorType _selectedBehavior;
        private IList _targetList;

        #endregion

        #region Commands

        public ICommand AddCommand
        {
            get { return _addCommand; }
        }

        public ICommand RemoveCommand
        {
            get { return _removeCommand; }
        }

        #endregion

        #region Properties

        public Object TargetListSelectedItem { get; set; }

        /// <summary>
        ///     This is the displayable list property
        /// </summary>
        public IList TargetList
        {
            get { return _targetList; }
        }

        /// <summary>
        ///     This is used by the comboBox to show the behaviorTypes that can be added to the list
        /// </summary>
        public ObservableCollection<BehaviorType> BehaviorTypes
        {
            get { return _behaviorTypes; }
            set
            {
                _behaviorTypes = value;
                NotifyPropertyChanged("BehaviorTypes");
            }
        }

        /// <summary>
        ///     this stores the selection of the behavior selection combobox to be used when adding a new behavior
        /// </summary>
        public BehaviorType SelectedBehavior
        {
            get { return _selectedBehavior; }
            set
            {
                _selectedBehavior = value;
                NotifyPropertyChanged("SelectedBehavior");
            }
        }

        #endregion

        #region private methods

        /// <summary>
        ///     Adds a new behavior to the list by using what is the SelectedBehavior as the behavior subclass
        /// </summary>
        /// <param name="parameter"></param>
        private void AddExecute(object parameter)
        {
            //TODO: note that I wanted to use a factory pattern for this but I couldn't get 
            //Activator.CreateInstance to work considering that I only have an enum 
            //of the type (either way I would need a conditional to get the type from 
            //the enum or I just use the conditional to make the object)
            //Perhaps there is a better than this but, though more coupled, this way works for now
            if (SelectedBehavior == BehaviorType.Transition)
            {
                var newInstance = new TransitionBehaviorUI(new TransitionBehavior());
                _targetList.Add(newInstance);
            }
            else if (SelectedBehavior == BehaviorType.Reward)
            {
                var newInstance = new RewardBehaviorUI(new RewardBehavior());
                _targetList.Add(newInstance);
            }
            else if (SelectedBehavior == BehaviorType.Visibility)
            {
                var newInstance = new VisibilityBehaviorUI(new VisibilityBehavior());
                _targetList.Add(newInstance);
            }
            else if (SelectedBehavior == BehaviorType.EndGame)
            {
                var newInstance = new EndGameBehaviorUI(new EndGameBehavior());
                _targetList.Add(newInstance);
            }
            else
            {
                throw new NotImplementedException();
            }
        }

        private void RemoveExecute(object parameter)
        {
            _targetList.Remove(TargetListSelectedItem);
        }

        #endregion

        #region Constructor/Destructor

        public BehaviorPropertiesVM(object _data)
        {
            _game = _data as Game;

            //Commands
            _addCommand = new RelayCommand(AddExecute);
            _removeCommand = new RelayCommand(RemoveExecute);

            //Add selector
            _behaviorTypes = new ObservableCollection<BehaviorType>
                {
                    BehaviorType.Transition,
                    BehaviorType.Reward,
                    BehaviorType.Visibility,
                    BehaviorType.EndGame
                };
        }

        /// <summary>
        ///     I need the list to manipulate it here, mostly for remove (the view creates the type of list that they want)
        /// </summary>
        /// <param name="list"></param>
        public void SetList(IList list)
        {
            _targetList = list;
        }

        #endregion

        public object GetDataFor(PropertyItem propertyItem)
        {
            return _game;
        }
    }
}