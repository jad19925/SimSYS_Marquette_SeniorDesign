﻿using System.Collections.Generic;
using Common;
using GameWizardModel;

namespace GameWizard.ViewModel
{
    public class TransitionTargetSelectorVM : NotifyPropertyChangedBase
    {
        #region Private Fields

        private readonly Game _game;
        private GameBase _selectedItem;

        #endregion

        #region Public Properties

        public List<Game> Game { get; set; }

        public GameBase SelectedItem
        {
            get { return _selectedItem; }
            set
            {
                _selectedItem = value;
                NotifyPropertyChanged("SelectedItem");
            }
        }

        #endregion

        #region Constructors

        public TransitionTargetSelectorVM(object game)
        {
            _game = game as Game;
            Game = new List<Game> {_game};
        }

        #endregion
    }
}