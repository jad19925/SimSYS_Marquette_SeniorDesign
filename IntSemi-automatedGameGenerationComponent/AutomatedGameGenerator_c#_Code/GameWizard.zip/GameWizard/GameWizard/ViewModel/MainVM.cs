﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Controls;
using System.Windows.Input;
using Common;
using GameWizardModel;

namespace GameWizard.ViewModel
{
    /// <summary>
    ///     This is the VM that controls the navigation of the program.
    ///     It servers the different pages of the program to main view
    /// </summary>
    public class MainVM : NotifyPropertyChangedBase
    {
        #region Fields

        /// <summary>
        ///     The game selection VM, this holds the user's selections for the type of game they want to create
        /// </summary>
        private readonly GameSelectionVM _gameSelectionVM;

        /// <summary>
        ///     The screens that have been navigated from, we need to be able to
        ///     go back to these if the user wants to navigate back
        /// </summary>
        private readonly Stack<UserControl> _screenStack = new Stack<UserControl>();

        /// <summary>
        ///     The current screen being served to the view
        /// </summary>
        private UserControl _currentScreen;

        /// <summary>
        ///     The generated game object
        /// </summary>
        private Game _game;

        /// <summary>
        ///     The Preview VM holds the game object that can be displayed to the user.
        /// </summary>
        private PreviewVM _previewVM;

        #endregion

        #region Public Properties

        /// <summary>
        ///     The current screen
        /// </summary>
        public UserControl CurrentScreen
        {
            get { return _currentScreen; }
            set
            {
                _currentScreen = value;
                NotifyPropertyChanged("CurrentScreen");
            }
        }

        #endregion

        #region Commands

        /// <summary>
        ///     Navigate to the next view
        /// </summary>
        public ICommand NextCommand
        {
            get
            {
                //get what screen should be next
                return new RelayCommand(NextExecute, CanNext);
            }
        }

        /// <summary>
        ///     Navigate to the previous view
        /// </summary>
        public ICommand BackCommand
        {
            get
            {
                //get what screen should be back
                return new RelayCommand(BackExecute, CanBack);
            }
        }

        #endregion

        #region Constructor/Destructor

        public MainVM()
        {
            _gameSelectionVM = new GameSelectionVM();
            //We want to know when things in the game selection VM has changed
            _gameSelectionVM.PropertyChanged += GameSelectionVM_PropertyChanged;

            //start off at the game selection screen
            NavigateTo(new TempGameSelection(_gameSelectionVM));
        }

        #endregion

        #region Event handlers

        /// <summary>
        ///     Something in the game selection VM has changed, update the next and back command.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GameSelectionVM_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            //when something changes in the child VMs then update the next and previous commands
            NotifyPropertyChanged("NextCommand");
            NotifyPropertyChanged("BackCommand");
        }

        #endregion

        #region Private Methods

        /// <summary>
        ///     Navigate to a specific view
        /// </summary>
        /// <param name="newView">The new view to navigate to</param>
        private void NavigateTo(UserControl newView)
        {
            //save the current view
            _screenStack.Push(newView);

            //set the current view to the new view
            CurrentScreen = newView;

            //send message to listners to update their next and back buttons
            NotifyPropertyChanged("NextCommand");
            NotifyPropertyChanged("BackCommand");
        }

        /// <summary>
        ///     Go to the previous view
        /// </summary>
        private void GoBack()
        {
            //pop the current view off the stack
            _screenStack.Pop();

            //set the CurrentScreen to the one before it
            CurrentScreen = _screenStack.Peek();

            //send message to listners to update their next and back buttons
            NotifyPropertyChanged("NextCommand");
            NotifyPropertyChanged("BackCommand");
        }

        private void BackExecute(object parameter)
        {
            GoBack();
        }

        private bool CanBack(object parameter)
        {
            return _screenStack.Count > 1;
        }

        private void NextExecute(object parameter)
        {
            //TODO: Need a factory method to figure out what screen is next
            if (_gameSelectionVM.BlankGame)
            {
                _game = new Game {Name = _gameSelectionVM.GameName};
            }
            else if (_gameSelectionVM.TemplateGame)
            {
                _game = GameGenerator.GenerateRandomTestGame(_gameSelectionVM.GameName, _gameSelectionVM.SelectedType,
                                                             _gameSelectionVM.SelectedSubject,
                                                             _gameSelectionVM.SelectedDifficulty,
                                                             _gameSelectionVM.SelectedLength);
            }
            else if (_gameSelectionVM.LoadGame)
            {
                _game = _gameSelectionVM.LoadedGame;
            }
            _previewVM = new PreviewVM(_game);
            NavigateTo(new PreviewPage(_previewVM));
        }

        private bool CanNext(object paramater)
        {
            return ((IGameVM) CurrentScreen.DataContext).CanGoNext();
        }

        #endregion
    }
}