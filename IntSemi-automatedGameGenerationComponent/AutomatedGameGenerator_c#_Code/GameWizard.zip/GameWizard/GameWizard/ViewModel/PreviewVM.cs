﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Common;
using GameWizard.VisibleAssets;
using GameWizardModel;
using SLPropertyGrid;

namespace GameWizard.ViewModel
{
    public class PreviewVM : NotifyPropertyChangedBase, IGameVM, IPropertyWindowDataProvider
    {
        #region Private Fields

        private readonly RelayCommand _addActCommand;
        private readonly RelayCommand _addSceneCommand;
        private readonly RelayCommand _addScreenCommand;
        private readonly RelayCommand _backgroundCommand;
        private readonly RelayCommand _buttonCommand;
        private readonly RelayCommand _characterCommand;
        private readonly RelayCommand _deleteCommand;
        private readonly Game _game;
        private readonly RelayCommand _imageCommand;
        private readonly RelayCommand _informationBoxCommand;
        private readonly RelayCommand _moveDownCommand;
        private readonly RelayCommand _moveUpCommand;

        private readonly RelayCommand _saveCommand;
        //private RelayCommand _arrowCommand;

        private VisibleAssetBase _selectedAsset;
        private GameBase _selectedItem;
        private Visibility _showAssetProperty;
        private Visibility _showGameBaseProperty;

        #endregion

        #region Public properties

        public List<Game> Game { get; set; }

        public GameBase SelectedItem
        {
            get { return _selectedItem; }
            set
            {
                _selectedItem = value;
                ShowAssetProperty = Visibility.Collapsed;
                ShowGameBaseProperty = Visibility.Visible;

                NotifyPropertyChanged("SelectedItem");

                _backgroundCommand.RaiseCanExecuteChanged();
                _buttonCommand.RaiseCanExecuteChanged();
                _imageCommand.RaiseCanExecuteChanged();
                _informationBoxCommand.RaiseCanExecuteChanged();
                _characterCommand.RaiseCanExecuteChanged();

                _addActCommand.RaiseCanExecuteChanged();
                _addSceneCommand.RaiseCanExecuteChanged();
                _addScreenCommand.RaiseCanExecuteChanged();
                _deleteCommand.RaiseCanExecuteChanged();

                _moveUpCommand.RaiseCanExecuteChanged();
                _moveDownCommand.RaiseCanExecuteChanged();
            }
        }

        public VisibleAssetBase SelectedAsset
        {
            get { return _selectedAsset; }
            set
            {
                _selectedAsset = value;
                if (_selectedAsset != null)
                {
                    ShowAssetProperty = Visibility.Visible;
                    ShowGameBaseProperty = Visibility.Collapsed;
                }
                else
                {
                    ShowAssetProperty = Visibility.Collapsed;
                    ShowGameBaseProperty = Visibility.Visible;
                }
                NotifyPropertyChanged("SelectedAsset");
            }
        }

        public Visibility ShowGameBaseProperty
        {
            get { return _showGameBaseProperty; }
            set
            {
                _showGameBaseProperty = value;
                NotifyPropertyChanged("ShowGameBaseProperty");
            }
        }

        public Visibility ShowAssetProperty
        {
            get { return _showAssetProperty; }
            set
            {
                _showAssetProperty = value;
                NotifyPropertyChanged("ShowAssetProperty");
            }
        }

        #endregion

        #region Commands

        /// <summary>
        ///     Navigate to the next view
        /// </summary>
        public ICommand BackgroundCommand
        {
            get { return _backgroundCommand; }
        }

        public ICommand ButtonCommand
        {
            get { return _buttonCommand; }
        }

        public ICommand ImageCommand
        {
            get { return _imageCommand; }
        }

        public ICommand InformationBoxCommand
        {
            get { return _informationBoxCommand; }
        }

        public ICommand CharacterCommand
        {
            get { return _characterCommand; }
        }

        public ICommand AddActCommand
        {
            get { return _addActCommand; }
        }

        public ICommand AddSceneCommand
        {
            get { return _addSceneCommand; }
        }

        public ICommand AddScreenCommand
        {
            get { return _addScreenCommand; }
        }

        public ICommand DeleteCommand
        {
            get { return _deleteCommand; }
        }

        public ICommand MoveUpCommand
        {
            get { return _moveUpCommand; }
        }

        public ICommand MoveDownCommand
        {
            get { return _moveDownCommand; }
        }

        public ICommand SaveCommand
        {
            get { return _saveCommand; }
        }

        #endregion

        #region Constructors

        public PreviewVM(Game game)
        {
            _backgroundCommand = new RelayCommand(SelectBackground, IsScene);
            _buttonCommand = new RelayCommand(SelectButton, IsScreen);
            _imageCommand = new RelayCommand(SelectImage, IsScreen);
            _informationBoxCommand = new RelayCommand(SelectInformationBox, IsScreen);
            _characterCommand = new RelayCommand(SelectCharacter, IsScreen);

            _addActCommand = new RelayCommand(AddAct, CanAddAct);
            _addSceneCommand = new RelayCommand(AddScene, CanAddScene);
            _addScreenCommand = new RelayCommand(AddScreen, CanAddScreen);
            _deleteCommand = new RelayCommand(Delete, CanDelete);
            _moveUpCommand = new RelayCommand(MoveUp, CanMoveUp);
            _moveDownCommand = new RelayCommand(MoveDown, CanMoveDown);

            _saveCommand = new RelayCommand(SaveCommandExecute);

            _game = game;
            Game = new List<Game> {game};

            ShowAssetProperty = Visibility.Collapsed;
            ShowGameBaseProperty = Visibility.Visible;
        }

        #endregion

        #region Command Methods

        private void SelectBackground(object param)
        {
            var browser = new ImageBrowser(ImageBrowser.ImageTypes.Background);

            browser.Show();
            browser.Closed += Browser_Closed;
        }

        private bool IsScene(object param)
        {
            return SelectedItem is Scene;
        }

        private void AddAct(object param)
        {
            var game = SelectedItem as Game;
            if (game != null)
            {
                var act = new Act {Name = "New Act"};
                game.Acts.Add(act);
                SelectedItem = act;
            }
        }

        private bool CanAddAct(object param)
        {
            return SelectedItem is Game;
        }

        private void AddScene(object param)
        {
            var act = SelectedItem as Act;
            if (act != null)
            {
                var scene = new Scene {Name = "New Scene"};
                act.Scenes.Add(scene);
                SelectedItem = scene;
            }
        }

        private bool CanAddScene(object param)
        {
            return SelectedItem is Act;
        }

        private void AddScreen(object param)
        {
            var scene = SelectedItem as Scene;
            if (scene != null)
            {
                var screen = new Screen {Name = "New Screen", Background = scene.Background};
                scene.Screens.Add(screen);
                SelectedItem = screen;
            }

        }

        private bool CanAddScreen(object param)
        {
            return SelectedItem is Scene;
        }

        private void Delete(object param)
        {
            DeleteSelected();
        }

        private void MoveUp(object param)
        {
            MoveSelectedItemUp();
        }

        private void MoveDown(object param)
        {
            MoveSelectedItemDown();
        }

        private void SaveCommandExecute(object param)
        {
            var dlg = new SaveFileDialog {DefaultExt = ".txt", Filter = "XML Files|*.xml|All Files|*.*"};
            if (dlg.ShowDialog() == true)
            {
                using (Stream fs = dlg.OpenFile())
                {
                    _game.SaveGame(fs);
                    fs.Close();
                }
            }
        }

        private bool CanDelete(object param)
        {
            return SelectedItem != null;
        }

        private void SelectButton(object param)
        {
        }

        private void SelectImage(object param)
        {
        }

        private void SelectInformationBox(object param)
        {
        }

        private void SelectCharacter(object param)
        {
        }

        private bool IsScreen(object param)
        {
            return SelectedItem is Screen;
        }

        private bool CanMoveUp(object param)
        {
            return true;
        }

        private bool CanMoveDown(object param)
        {
            return true;
        }

        #endregion

        #region Private Methods

        private bool MoveScreenUp(int actIndex, int sceneIndex)
        {
            for (int z = 0; z < _game.Acts[actIndex].Scenes[sceneIndex].Screens.Count; z++)
            {
                if (_game.Acts[actIndex].Scenes[sceneIndex].Screens[z].ID == _selectedItem.ID && z > 0)
                {
                    _game.Acts[actIndex].Scenes[sceneIndex].Screens.Insert(z - 1,
                                                                           _game.Acts[actIndex].Scenes[sceneIndex]
                                                                               .Screens[z]);
                    _game.Acts[actIndex].Scenes[sceneIndex].Screens.RemoveAt(z + 1);

                    return true;
                }
            }
            return false;
        }

        private bool MoveSceneUp(int actIndex)
        {
            for (int x = 0; x < _game.Acts[actIndex].Scenes.Count; x++)
            {
                if (_game.Acts[actIndex].Scenes[x].ID == _selectedItem.ID && x > 0)
                {
                    _game.Acts[actIndex].Scenes.Insert(x - 1, _game.Acts[actIndex].Scenes[x]);
                    _game.Acts[actIndex].Scenes.RemoveAt(x + 1);
                    return true;
                }

                if (MoveScreenUp(actIndex, x))
                {
                    return true;
                }
            } //end of Scenes for loop

            return false;
        }

        private void MoveSelectedItemUp()
        {
            GameBase oldSelectedItem = SelectedItem;
            MoveActUp();
            SelectedItem = oldSelectedItem;
        }

        private void MoveActUp()
        {
            for (int i = 0; i < _game.Acts.Count; i++)
            {
                if (_game.Acts[i].ID == _selectedItem.ID && i > 0)
                {
                    _game.Acts.Insert(i - 1, _game.Acts[i]);
                    _game.Acts.RemoveAt(i + 1);
                    return;
                }

                if (MoveSceneUp(i))
                {
                    return;
                }
            } //end of Acts for loop
        }

        private void MoveSelectedItemDown()
        {
            GameBase oldSelectedItem = SelectedItem;
            MoveActDown();
            SelectedItem = oldSelectedItem;
        }

        private bool MoveScreenDown(int actIndex, int sceneIndex)
        {
            for (int z = 0; z < _game.Acts[actIndex].Scenes[sceneIndex].Screens.Count; z++)
            {
                if (_game.Acts[actIndex].Scenes[sceneIndex].Screens[z].ID == _selectedItem.ID &&
                    (z < _game.Acts[actIndex].Scenes[sceneIndex].Screens.Count - 1))
                {
                    _game.Acts[actIndex].Scenes[sceneIndex].Screens.Insert(z + 2,
                                                                           _game.Acts[actIndex].Scenes[sceneIndex]
                                                                               .Screens[z]);
                    _game.Acts[actIndex].Scenes[sceneIndex].Screens.RemoveAt(z);

                    return true;
                }
            }
            return false;
        }


        private bool MoveSceneDown(int actIndex)
        {
            for (int x = 0; x < _game.Acts[actIndex].Scenes.Count; x++)
            {
                if (_game.Acts[actIndex].Scenes[x].ID == _selectedItem.ID && (x < _game.Acts[actIndex].Scenes.Count - 1))
                {
                    _game.Acts[actIndex].Scenes.Insert(x + 2, _game.Acts[actIndex].Scenes[x]);
                    _game.Acts[actIndex].Scenes.RemoveAt(x);
                    return true;
                }

                if (MoveScreenDown(actIndex, x))
                {
                    return true;
                }
            } //end of Scenes for loop

            return false;
        }

        private void MoveActDown()
        {
            for (int i = 0; i < _game.Acts.Count; i++)
            {
                if (_game.Acts[i].ID == _selectedItem.ID && (i < _game.Acts.Count - 1))
                {
                    _game.Acts.Insert(i + 2, _game.Acts[i]);
                    _game.Acts.RemoveAt(i);
                    return;
                }

                if (MoveSceneDown(i))
                {
                    return;
                }
            } //end of Acts for loop
        }

        private void DeleteSelected()
        {
            DeleteAct();
        }

        private void DeleteAct()
        {
            for (int x = 0; x < _game.Acts.Count; x++)
            {
                if (_selectedItem.ID == _game.Acts[x].ID)
                {
                    _game.Acts.RemoveAt(x);
                    return;
                }

                if (DeleteScene(x))
                {
                    return;
                }
            }
        }

        private bool DeleteScene(int actIndex)
        {
            for (int z = 0; z < _game.Acts[actIndex].Scenes.Count; z++)
            {
                if (_selectedItem.ID == _game.Acts[actIndex].Scenes[z].ID)
                {
                    _game.Acts[actIndex].Scenes.RemoveAt(z);
                    return true;
                }

                if (DeleteScreen(actIndex, z))
                {
                    return true;
                }
            }

            return false;
        }

        private bool DeleteScreen(int actIndex, int sceneIndex)
        {
            for (int i = 0; i < _game.Acts[actIndex].Scenes[sceneIndex].Screens.Count; i++)
            {
                if (_selectedItem.ID == _game.Acts[actIndex].Scenes[sceneIndex].Screens[i].ID)
                {
                    _game.Acts[actIndex].Scenes[sceneIndex].Screens.RemoveAt(i);
                    return true;
                }
            }
            return false;
        }

        #endregion

        #region Event Handlers

        private void Browser_Closed(object sender, EventArgs e)
        {
            var browser = sender as ImageBrowser;
            if (browser != null && browser.DialogResult == true)
            {
                var selectedScreen = SelectedItem as Scene;
                if (selectedScreen != null)
                {
                    selectedScreen.Background = browser.SelectedItem;
                }
            }
        }

        #endregion

        #region IGameVM Implementation

        public bool CanGoNext()
        {
            return false;
        }

        #endregion

        #region IPropertyWindowDataProvider Implementation

        public object GetDataFor(PropertyItem propertyItem)
        {
            return _game;
        }

        #endregion
    }
}