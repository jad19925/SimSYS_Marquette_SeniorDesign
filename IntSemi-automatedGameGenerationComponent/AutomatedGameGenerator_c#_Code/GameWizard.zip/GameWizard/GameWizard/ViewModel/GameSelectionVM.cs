﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Common;
using GameWizard.GameServiceRef;
using GameWizardModel;

namespace GameWizard.ViewModel
{
    public class GameSelectionVM : NotifyPropertyChangedBase, IGameVM
    {
        #region Fields

        private readonly RelayCommand _browseCommand;
        private bool _blankGame;
        private string _filename;
        private string _gameName;
        private ObservableCollection<GameType> _gameTypes;
        private bool _loadGame;
        private Game _loadedGame;
        private GameDifficultiesEnum _selectedDifficulty;
        private GameLengthsEnum _selectedLength;
        private Subject _selectedSubject;
        private GameType _selectedType;
        private ObservableCollection<Subject> _subjects;
        private bool _templateGame;

        #endregion

        #region Public Properties

        /// <summary>
        ///     List of Game lengths that the user can choose from
        /// </summary>
        public List<GameLengthsEnum> GameLengths { get; set; }

        /// <summary>
        ///     List of game difficulties that the user can choose form
        /// </summary>
        public List<GameDifficultiesEnum> GameDifficulties { get; set; }

        /// <summary>
        ///     List of subjects to choose from
        /// </summary>
        public ObservableCollection<Subject> Subjects
        {
            get { return _subjects; }
            set
            {
                _subjects = value;
                NotifyPropertyChanged("Subjects");
            }
        }

        /// <summary>
        ///     List of game types to choose from
        /// </summary>
        public ObservableCollection<GameType> GameTypes
        {
            get { return _gameTypes; }
            set
            {
                _gameTypes = value;
                NotifyPropertyChanged("GameTypes");
            }
        }

        /// <summary>
        ///     The name of the newly generated game
        /// </summary>
        public string GameName
        {
            get { return _gameName; }
            set
            {
                _gameName = value;
                NotifyPropertyChanged("GameName");
            }
        }

        /// <summary>
        ///     The selected game length to generate a game with
        /// </summary>
        public GameLengthsEnum SelectedLength
        {
            get { return _selectedLength; }
            set
            {
                _selectedLength = value;
                NotifyPropertyChanged("SelectedLength");
                NotifyPropertyChanged("ImageSource");
            }
        }

        /// <summary>
        ///     The selected difficulty to generate a game with
        /// </summary>
        public GameDifficultiesEnum SelectedDifficulty
        {
            get { return _selectedDifficulty; }
            set
            {
                _selectedDifficulty = value;
                NotifyPropertyChanged("SelectedDifficulty");
                NotifyPropertyChanged("ImageSource");
            }
        }

        /// <summary>
        ///     The selected game type to generate a game with
        /// </summary>
        public GameType SelectedType
        {
            get { return _selectedType; }
            set
            {
                _selectedType = value;
                NotifyPropertyChanged("SelectedType");
                NotifyPropertyChanged("ImageSource");
            }
        }

        /// <summary>
        ///     The selected subject for the game
        /// </summary>
        public Subject SelectedSubject
        {
            get { return _selectedSubject; }
            set
            {
                _selectedSubject = value;
                NotifyPropertyChanged("SelectedSubject");
                NotifyPropertyChanged("ImageSource");
            }
        }

        /// <summary>
        ///     Image that represents the user's current selection
        /// </summary>
        public string ImageSource
        {
            get
            {
                if (SelectedType == null)
                {
                    return "";
                }
                string path = string.Format("/GameWizard;component/Images/{0}_{1}_{2}.jpg", SelectedType.Name,
                                            SelectedDifficulty.ToString(), SelectedLength.ToString());
                return path;
            }
        }

        public bool TemplateGame
        {
            get { return _templateGame; }
            set
            {
                _templateGame = value;
                NotifyPropertyChanged("TemplateGame");
                NotifyPropertyChanged("ShowTemplateGame");
            }
        }

        public bool LoadGame
        {
            get { return _loadGame; }
            set
            {
                _loadGame = value;
                NotifyPropertyChanged("LoadGame");
                NotifyPropertyChanged("ShowLoadGame");
            }
        }

        public bool BlankGame
        {
            get { return _blankGame; }
            set
            {
                _blankGame = value;
                NotifyPropertyChanged("BlankGame");
                NotifyPropertyChanged("ShowBlankGame");
            }
        }

        public Visibility ShowTemplateGame
        {
            get { return TemplateGame ? Visibility.Visible : Visibility.Collapsed; }
        }

        public Visibility ShowLoadGame
        {
            get { return LoadGame ? Visibility.Visible : Visibility.Collapsed; }
        }

        public Visibility ShowBlankGame
        {
            get { return BlankGame ? Visibility.Visible : Visibility.Collapsed; }
        }

        public ICommand BrowseCommand
        {
            get { return _browseCommand; }
        }

        public string Filename
        {
            get { return _filename; }
            set
            {
                _filename = value;
                NotifyPropertyChanged("Filename");
            }
        }

        public Game LoadedGame
        {
            get { return _loadedGame; }
            set
            {
                _loadedGame = value;
                NotifyPropertyChanged("LoadedGame");
            }
        }

        #endregion

        #region Constructor/Destructor

        public GameSelectionVM()
        {
            _browseCommand = new RelayCommand(BrowseCommandExecute);
            TemplateGame = true;

            //create the list of lengths and difficulties
            //TODO: might want to ask the server for these to be consistent with subject and type
            GameLengths = new List<GameLengthsEnum>
                {
                    GameLengthsEnum.Short,
                    GameLengthsEnum.Medium,
                    GameLengthsEnum.Long
                };


            GameDifficulties = new List<GameDifficultiesEnum>
                {
                    GameDifficultiesEnum.Easy,
                    GameDifficultiesEnum.Medium,
                    GameDifficultiesEnum.Hard
                };

            //ask the server to send us the game subjects and game types
            var client = new GameServiceClient();
            client.GetSubjectsCompleted += client_GetSubjectsCompleted;
            client.GetGameTypesCompleted += client_GetGameTypesCompleted;

            client.GetSubjectsAsync();
            client.GetGameTypesAsync();
        }

        /// <summary>
        ///     Callback for the GetGameTypes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void client_GetGameTypesCompleted(object sender, GetGameTypesCompletedEventArgs e)
        {
            GameTypes = e.Result;
            if (GameTypes.Count > 0)
            {
                SelectedType = GameTypes[0];
            }
        }

        /// <summary>
        ///     Callback for the GetSubjects
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void client_GetSubjectsCompleted(object sender, GetSubjectsCompletedEventArgs e)
        {
            Subjects = e.Result;
            if (Subjects.Count > 0)
            {
                SelectedSubject = Subjects[0];
            }
        }

        private void BrowseCommandExecute(object param)
        {
            var dlg = new OpenFileDialog();
            dlg.Filter = "XML Files (.xml)|*.xml|All Files (*.*)|*.*";
            dlg.Multiselect = false;
            if (dlg.ShowDialog().GetValueOrDefault())
            {
                Filename = dlg.File.Name;
                // Open the selected file to read.
                Stream fileStream = dlg.File.OpenRead();

                using (var reader = new StreamReader(fileStream))
                {
                    LoadedGame = Game.LoadGame(reader);
                }
                fileStream.Close();
            }
        }

        #endregion

        #region IGameVM Implementation

        public bool CanGoNext()
        {
            if (LoadGame)
            {
                return LoadedGame != null;
            }

            return !string.IsNullOrWhiteSpace(GameName) && SelectedType != null && SelectedSubject != null;
        }

        #endregion
    }
}