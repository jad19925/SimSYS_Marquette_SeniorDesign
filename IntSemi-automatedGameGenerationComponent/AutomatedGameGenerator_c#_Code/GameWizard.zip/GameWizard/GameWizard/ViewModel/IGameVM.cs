﻿namespace GameWizard.ViewModel
{
    public interface IGameVM
    {
        bool CanGoNext();
    }
}