﻿using GameWizardModel;

namespace GameWizard.VisibleAssets
{
    public class EndGameBehaviorUI : BehaviorUI
    {
        private EndGameBehavior _endGameBehavior;

        public EndGameBehaviorUI(EndGameBehavior behavior)
            : base(behavior)
        {
            _endGameBehavior = behavior;
        }
    }
}