﻿using System;
using System.ComponentModel;
using GameWizard.PropertyGridEditors;
using GameWizardModel;
using SLPropertyGrid;

namespace GameWizard.VisibleAssets
{
    public class TransitionBehaviorUI : BehaviorUI
    {
        private readonly TransitionBehavior _transitionBehavior;

        public TransitionBehaviorUI(TransitionBehavior behavior)
            : base(behavior)
        {
            _transitionBehavior = behavior;
        }

        [Category("TransitionBehavior")]
        [DisplayName("Transition Target")]
        [Description("Select the Screen to transition to.")]
        [Editor(typeof (TransitionBehaviorEditor))]
        public Guid TransitionID
        {
            get { return _transitionBehavior.TransitionID; }
            set { _transitionBehavior.TransitionID = value; }
        }

        [Category("TransitionBehavior")]
        [DisplayName("Transition Effect")]
        public Transition Transition
        {
            get { return _transitionBehavior.Transition; }
            set { _transitionBehavior.Transition = value; }
        }
    }
}