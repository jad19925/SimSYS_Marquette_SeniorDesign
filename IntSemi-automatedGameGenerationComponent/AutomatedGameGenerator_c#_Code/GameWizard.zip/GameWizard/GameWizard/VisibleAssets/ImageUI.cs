﻿using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using GameWizard.GameServiceRef;
using GameWizardModel;

namespace GameWizard.VisibleAssets
{
    public class ImageUI : VisibleAssetBase
    {
        private ImageAsset _asset;
        protected Image _uIElement;

        #region IVisibleAsset Implementation

        [Browsable(false)]
        public override AssetBase Asset
        {
            get { return _asset; }
            set { _asset = value as ImageAsset; }
        }

        [Browsable(false)]
        public override FrameworkElement UIElement
        {
            get { return _uIElement; }
            set { _uIElement = value as Image; }
        }

        #endregion

        public void GetImageDataCompleted(object sender, GetImageCompletedEventArgs e)
        {
            if (UIElement != null)
            {
                var bmpImage = new BitmapImage();
                var stream = new MemoryStream(e.Result);
                bmpImage.SetSource(stream);

                _uIElement.Source = bmpImage;
            }
        }
    }

    public class CopyOfImageUI : VisibleAssetBase
    {
        private ImageAsset _asset;
        protected Image _uIElement;

        #region IVisibleAsset Implementation

        public override AssetBase Asset
        {
            get { return _asset; }
            set { _asset = value as ImageAsset; }
        }

        public override FrameworkElement UIElement
        {
            get { return _uIElement; }
            set { _uIElement = value as Image; }
        }

        #endregion

        public void GetImageDataCompleted(object sender, GetImageCompletedEventArgs e)
        {
            if (UIElement != null)
            {
                var bmpImage = new BitmapImage();
                var stream = new MemoryStream(e.Result);
                bmpImage.SetSource(stream);

                _uIElement.Source = bmpImage;
            }
        }
    }
}