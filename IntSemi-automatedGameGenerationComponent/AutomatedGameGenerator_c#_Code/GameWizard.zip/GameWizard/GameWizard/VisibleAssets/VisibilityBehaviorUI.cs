﻿using System;
using System.ComponentModel;
using GameWizard.PropertyGridEditors;
using GameWizardModel;
using SLPropertyGrid;

namespace GameWizard.VisibleAssets
{
    public class VisibilityBehaviorUI : BehaviorUI
    {
        private readonly VisibilityBehavior _visibilityBehavior;

        public VisibilityBehaviorUI(VisibilityBehavior behavior)
            : base(behavior)
        {
            _visibilityBehavior = behavior;
        }

        [Category("VisiblityBehavior")]
        [Editor(typeof (EntitySelectorEditor))] //custom editor for model type
        public Guid EntityID
        {
            get { return _visibilityBehavior.EntityID; }
            set { _visibilityBehavior.EntityID = value; }
        }

        [Category("VisiblityBehavior")]
        public VisibilityModifier NewVisiblity
        {
            get { return _visibilityBehavior.NewVisiblity; }
            set { _visibilityBehavior.NewVisiblity = value; }
        }
    }
}