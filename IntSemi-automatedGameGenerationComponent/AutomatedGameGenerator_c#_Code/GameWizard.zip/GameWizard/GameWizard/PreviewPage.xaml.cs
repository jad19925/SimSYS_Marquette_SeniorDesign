﻿using System;
using System.Windows;
using System.Windows.Controls;
using GameWizard.Tools;
using GameWizard.ViewModel;
using GameWizardModel;

namespace GameWizard
{
    public partial class PreviewPage : UserControl
    {
        private PreviewVM _dataContext;

        public PreviewPage(PreviewVM dataContext)
        {
            InitializeComponent();

            _dataContext = dataContext;
            DataContext = dataContext;
        }

        private void TreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            //_dataContext.SelectedItem = e.NewValue as GameBase;

            uxScreenPreview.Screen = e.NewValue as AssetContainer;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            uxScreenPreview.SetTool(ToolFactory.ToolType.Button);
        }

        private void Image_Click(object sender, RoutedEventArgs e)
        {
            var browser = new ImageBrowser(ImageBrowser.ImageTypes.Foreground);

            browser.Show();
            browser.Closed += ImageBrowser_Closed;
        }

        private void InformationBox_Click(object sender, RoutedEventArgs e)
        {
            uxScreenPreview.SetTool(ToolFactory.ToolType.InfoBox);
        }

        private void Character_Click(object sender, RoutedEventArgs e)
        {
            var browser = new ImageBrowser(ImageBrowser.ImageTypes.Character);

            browser.Show();
            browser.Closed += CharacterBrowser_Closed;
        }

        private void ImageBrowser_Closed(object sender, EventArgs e)
        {
            var browser = sender as ImageBrowser;
            if (sender != null && browser.DialogResult == true)
            {
                uxScreenPreview.SetTool(ToolFactory.ToolType.Image, browser.SelectedItem, browser.ImageData);
            }
        }

        private void CharacterBrowser_Closed(object sender, EventArgs e)
        {
            var browser = sender as ImageBrowser;
            if (sender != null && browser.DialogResult == true)
            {
                uxScreenPreview.SetTool(ToolFactory.ToolType.Character, browser.SelectedItem, browser.ImageData);
            }
        }
    }
}