﻿using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using GameWizard.GameServiceRef;
using GameWizard.VisibleAssets;
using GameWizardModel;

namespace GameWizard.Tools
{
    public class ToolFactory
    {
        #region Private Fields

        private ToolType _currentTool;

        #endregion

        #region Public Properties

        public enum ToolType
        {
            Arrow,
            Button,
            Image,
            InfoBox,
            Character
        };

        public ToolType CurrentTool
        {
            get { return _currentTool; }
            set
            {
                _currentTool = value;
                if (_currentTool == ToolType.Arrow)
                {
                    ToolData = null;
                }
                CurrentAsset = null;
            }
        }

        public object ToolData { get; set; }
        public byte[] ImageData { get; set; }

        public VisibleAssetBase CurrentAsset { get; set; }

        #endregion

        #region Public Static Methods

        public static VisibleAssetBase CreateAsset(AssetBase asset)
        {
            if (asset is ButtonAsset)
            {
                return CreateButton(asset as ButtonAsset);
            }
            else if (asset is InformationBoxAsset)
            {
                return CreateInformationBox(asset as InformationBoxAsset);
            }
            else if (asset is CharacterAsset)
            {
                return CreateCharacter(asset as CharacterAsset);
            }
                //Keep Image asset as the last one because other things inherit from it
            else if (asset is ImageAsset)
            {
                return CreateImage(asset as ImageAsset);
            }
            return null;
        }

        #endregion

        #region Public Mouse Methods

        public bool MouseDown(Point point)
        {
            CurrentAsset = CreateAsset();
            if (CurrentAsset != null)
            {
                CurrentAsset.SetRect(point, 1, 1);

                return true;
            }

            return false;
        }

        public Cursor MouseMove(Point point, bool mouseDown)
        {
            if (mouseDown && CurrentAsset != null)
            {
                CurrentAsset.SetBottomRight(point);
            }

            if (_currentTool == ToolType.Arrow)
            {
                return Cursors.Arrow;
            }
            return Cursors.Stylus;
        }

        public bool MouseUp(Point point)
        {
            if (CurrentAsset != null)
            {
                CurrentAsset.SetBottomRight(point);
                return true;
            }
            return false;
        }

        #endregion

        #region Private Factory Methods

        private VisibleAssetBase CreateAsset()
        {
            switch (CurrentTool)
            {
                case ToolType.Button:
                    return CreateButton();
                case ToolType.Image:
                    return CreateImage();
                case ToolType.InfoBox:
                    return CreateInformationBox();
                case ToolType.Character:
                    return CreateCharacter();
            }

            return null;
        }

        private ButtonUI CreateButton()
        {
            return CreateButton(new ButtonAsset {Name = "Button"});
        }

        private ImageUI CreateImage()
        {
            return CreateImage(new ImageAsset {DisplayImage = ToolData as string}, ImageData);
        }

        private InformationBoxUI CreateInformationBox()
        {
            return CreateInformationBox(new InformationBoxAsset {Name = "Information Box"});
        }

        private CharacterUI CreateCharacter()
        {
            return CreateCharacter(new CharacterAsset {DisplayImage = ToolData as string}, ImageData);
        }

        #endregion

        #region Private Static Factory Methods

        private static ButtonUI CreateButton(ButtonAsset asset)
        {
            var button = new ButtonUI {Asset = asset};
            Rect bounds = button.Asset.Bounds;
            button.UIElement = new Button
                {
                    Margin = new Thickness(bounds.X, bounds.Y, 0, 0),
                    Width = bounds.Width,
                    Height = bounds.Height,
                    Content = button.Asset.Name,
                    IsEnabled = false,
                    FontFamily = new FontFamily(asset.FontFamily),
                    Background = new SolidColorBrush(asset.BackgroundColor),
                    FontSize = asset.FontSize,
                    Foreground = new SolidColorBrush(asset.ForegroundColor)
                };

            return button;
        }

        private static ImageUI CreateImage(ImageAsset asset, byte[] imageData = null)
        {
            var image = new ImageUI {Asset = asset};
            Rect bounds = image.Asset.Bounds;
            image.UIElement = new Image
                {
                    Margin = new Thickness(bounds.X, bounds.Y, 0, 0),
                    Width = bounds.Width,
                    Height = bounds.Height
                };

            if (imageData != null)
            {
                var bmpImage = new BitmapImage();
                var stream = new MemoryStream(imageData);
                bmpImage.SetSource(stream);

                (image.UIElement as Image).Source = bmpImage;
            }
            else
            {
                var client = new GameServiceClient();
                client.GetImageCompleted += image.GetImageDataCompleted;
                client.GetImageAsync(asset.DisplayImage);
            }

            return image;
        }


        private static InformationBoxUI CreateInformationBox(InformationBoxAsset asset)
        {
            var infoBox = new InformationBoxUI {Asset = asset};
            Rect bounds = infoBox.Asset.Bounds;
            var textBlock = new TextBlock
                {
                    Text = infoBox.Asset.Name,
                    TextAlignment = TextAlignment.Center,
                    TextWrapping = TextWrapping.Wrap,
                    FontFamily = new FontFamily(asset.FontFamily),
                    FontSize = asset.FontSize,
                    Foreground = new SolidColorBrush(asset.ForegroundColor),
                    VerticalAlignment = VerticalAlignment.Center
                };
            infoBox.UIElement = new Border
                {
                    Margin = new Thickness(bounds.X, bounds.Y, 0, 0),
                    Width = bounds.Width,
                    Height = bounds.Height,
                    Background = new SolidColorBrush(asset.BackgroundColor),
                    Child = textBlock
                };

            return infoBox;
        }

        private static CharacterUI CreateCharacter(CharacterAsset asset, byte[] imageData = null)
        {
            var character = new CharacterUI {Asset = asset};
            Rect bounds = character.Asset.Bounds;
            character.UIElement = new Image
                {
                    Margin = new Thickness(bounds.X, bounds.Y, 0, 0),
                    Width = bounds.Width,
                    Height = bounds.Height
                };

            if (imageData != null)
            {
                var bmpImage = new BitmapImage();
                var stream = new MemoryStream(imageData);
                bmpImage.SetSource(stream);

                (character.UIElement as Image).Source = bmpImage;
            }
            else
            {
                var client = new GameServiceClient();
                client.GetCharacterCompleted += character.GetCharacterDataCompleted;
                client.GetCharacterAsync(asset.DisplayImage);
            }

            return character;
        }

        #endregion
    }
}