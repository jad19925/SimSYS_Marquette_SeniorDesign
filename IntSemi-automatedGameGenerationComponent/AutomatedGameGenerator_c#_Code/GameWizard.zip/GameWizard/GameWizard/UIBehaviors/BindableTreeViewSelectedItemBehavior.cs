using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Interactivity;

namespace Behaviors
{
    /// <summary>
    ///     A behavior to effectively allow two-way binding to the tree view's SelectedItem property
    /// </summary>
    public class BindableTreeViewSelectedItemBehavior : Behavior<TreeView>
    {
        /// <summary>
        ///     Binding dependency property for the data context of the treeview
        /// </summary>
        public static readonly DependencyProperty BindingProperty = DependencyProperty.Register(
            "Binding", typeof (object), typeof (BindableTreeViewSelectedItemBehavior),
            new PropertyMetadata(BindingChanged));

        private static readonly DependencyProperty SelectedItemProperty = DependencyProperty.Register(
            "SelectedItem", typeof (object), typeof (BindableTreeViewSelectedItemBehavior),
            new PropertyMetadata(SelectedItemChanged));

        private bool createdBindings;
        private bool isUpdatingTree;

        /// <summary>
        ///     Gets or sets the binding.
        /// </summary>
        /// <value>The binding.</value>
        public object Binding
        {
            get { return GetValue(BindingProperty); }

            set { SetValue(BindingProperty, value); }
        }

        /// <summary>
        ///     Called after the behavior is attached to an AssociatedObject.
        /// </summary>
        /// <remarks>Override this to hook up functionality to the AssociatedObject.</remarks>
        protected override void OnAttached()
        {
            base.OnAttached();
            AssociatedObject.Loaded += AssociatedObjectLoaded;
            AssociatedObject.SelectedItemChanged += AssociatedObjectSelectedItemChanged;
            if (null != AssociatedObject.DataContext)
            {
                CreateBindings();
            }
        }

        /// <summary>
        ///     Called when the behavior is being detached from its AssociatedObject, but before it has actually occurred.
        /// </summary>
        /// <remarks>Override this to unhook functionality from the AssociatedObject.</remarks>
        protected override void OnDetaching()
        {
            base.OnDetaching();
            AssociatedObject.SelectedItemChanged -= AssociatedObjectSelectedItemChanged;
        }

        private static void BindingChanged(DependencyObject source, DependencyPropertyChangedEventArgs args)
        {
            // establish bindings
            var behavior = source as BindableTreeViewSelectedItemBehavior;
            if (null == behavior)
            {
                return;
            }

            behavior.CreateBindings();
        }

        private static void SelectedItemChanged(DependencyObject source, DependencyPropertyChangedEventArgs args)
        {
            // find the container in the treeview for the selected item and set it's IsSelected property
            var behavior = source as BindableTreeViewSelectedItemBehavior;
            if (null == behavior)
            {
                return;
            }

            behavior.UpdateTreeViewSelectedItem();
        }

        private void UpdateTreeViewSelectedItem()
        {
            if (!createdBindings)
            {
                return;
            }

            if (isUpdatingTree)
            {
                // we started this one
                return;
            }

            if (null == AssociatedObject)
            {
                return;
            }

            object selectedItem = GetValue(SelectedItemProperty);
            ItemContainerGenerator generator = AssociatedObject.ItemContainerGenerator;
            if (null == generator)
            {
                return;
            }

            // check for top level item
            //this.AssociatedObject.ExpandAll();
            AssociatedObject.UpdateLayout();
            TreeViewItem node = AssociatedObject.GetContainerFromItem(selectedItem);

            if (null != node)
            {
                node.IsSelected = true;
                //this.AssociatedObject.CollapseAllButSelectedPath();
            }
        }

        private void AssociatedObjectLoaded(object sender, RoutedEventArgs e)
        {
            if (!createdBindings)
            {
                CreateBindings();
            }
            else
            {
                UpdateTreeViewSelectedItem();
            }
        }

        private void CreateBindings()
        {
            // clear any existing binding
            ClearValue(SelectedItemProperty);

            object data = AssociatedObject.DataContext;
            if (null == data)
            {
                return;
            }

            // retrieve the developer's binding specification
            var expression = ReadLocalValue(BindingProperty) as BindingExpression;
            if (null == expression)
            {
                return;
            }

            // create our own Binding
            var binding = new Binding
                {
                    Source = data,
                    Path = new PropertyPath(expression.ParentBinding.Path.Path),
                    Mode = BindingMode.TwoWay
                };

            // set our flag first since the call to SetBinding will call the change event handler
            createdBindings = true;
            BindingOperations.SetBinding(this, SelectedItemProperty, binding);
        }

        private void AssociatedObjectSelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if (!createdBindings)
            {
                return;
            }

            var treeview = sender as TreeView;
            if (null == treeview)
            {
                return;
            }

            // update the value of our binding to the newly selected item which will get passed to the data context
            isUpdatingTree = true;
            try
            {
                SetValue(SelectedItemProperty, treeview.SelectedValue);
            }
            finally
            {
                isUpdatingTree = false;
            }
        }
    }
}