﻿using System.Windows.Controls;

namespace GameWizard
{
    public partial class TempGameSelection : UserControl
    {
        public TempGameSelection(object dataContext)
        {
            InitializeComponent();

            DataContext = dataContext;
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            (sender as TextBox).GetBindingExpression(TextBox.TextProperty).UpdateSource();
        }
    }
}