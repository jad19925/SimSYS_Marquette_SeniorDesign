﻿namespace GameWizardModel
{
    public class CharacterAsset : TextAsset
    {
        public string Type { get; set; } //example protagonist (could possibly be an enum of types)
        public string Title { get; set; }
        public string Skills { get; set; }
        public int Experience { get; set; }
        public string Communication { get; set; } //example Good (could also be an enum)
        public string Leadership { get; set; } //example Good
        public string Teamwork { get; set; } //example Good
        public string Demographics { get; set; } //example male, caucasion
        public string Degress { get; set; }

        //rewards???
        public int Certificates { get; set; }
        public int Promotions { get; set; }
        public int Trophies { get; set; }
        public int Points { get; set; }
        public int Hint { get; set; }

        public string DisplayImage { get; set; }

        #region Construtors

        #endregion
    }
}