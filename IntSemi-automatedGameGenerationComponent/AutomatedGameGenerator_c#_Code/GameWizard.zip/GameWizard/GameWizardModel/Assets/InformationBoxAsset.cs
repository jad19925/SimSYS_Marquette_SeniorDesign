﻿namespace GameWizardModel
{
    public class InformationBoxAsset : TextAsset
    {
        public ImageAsset Image { get; set; }
        public string Caption { get; set; }
    }
}