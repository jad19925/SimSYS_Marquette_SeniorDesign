﻿using System.Collections.ObjectModel;

namespace GameWizardModel
{
    public class QuestionAsset : AssetBase
    {
        public QuestionAsset()
        {
        }

        public QuestionAsset(bool bIsTrueFalse, bool Answer)
        {
            if (bIsTrueFalse)
            {
                Answers.Add(new AnswerAsset("True", Answer));
                Answers.Add(new AnswerAsset("False", Answer == false));
            }
        }

        public int PointReward { get; set; } //other rewards later
        public int QuestionDifficulty { get; set; } //may want to record this for rewards?
        public string Question { get; set; } //handle image questions later
        public ObservableCollection<AnswerAsset> Answers { get; set; }
    }
}