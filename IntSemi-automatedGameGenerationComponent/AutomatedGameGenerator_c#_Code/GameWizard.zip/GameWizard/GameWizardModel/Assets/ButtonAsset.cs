﻿namespace GameWizardModel
{
    public class ButtonAsset : TextAsset
    {
        //public string _Event { get; set; }
        public string Caption { get; set; }
    }
}