﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Xml.Serialization;

namespace GameWizardModel
{
    public class Game : GameBase
    {
        public static Game thisGame;

        public Game()
        {
            Acts = new ObservableCollection<Act>();
            thisGame = this;
        }

        public ObservableCollection<Act> Acts { get; set; }
        public GameType GameType { get; set; }
        public CharacterAsset Player { get; set; } //there must always be one player //there must always be one player

        public void SaveGame(string fileName)
        {
            var writer = new XmlSerializer(typeof (Game));
            var file = new StreamWriter(fileName);
            writer.Serialize(file, this);
            file.Close();
        }

        public void SaveGame(Stream stream)
        {
            var writer = new XmlSerializer(typeof (Game));
            writer.Serialize(stream, this);
        }

        public string GetGameXML()
        {
            var writer = new XmlSerializer(typeof (Game));
            var file = new MemoryStream();
            writer.Serialize(file, this);
            file.Close();
            var reader = new StreamReader(file);
            return reader.ReadToEnd();
        }

        public static Game LoadGame(string fileName)
        {
            var deserializer = new XmlSerializer(typeof (Game));
            TextReader textReader = new StreamReader(fileName);
            return (Game) deserializer.Deserialize(textReader);
        }

        public static Game LoadGame(StreamReader stream)
        {
            var deserializer = new XmlSerializer(typeof (Game));
            return (Game) deserializer.Deserialize(stream);
        }

        public static Game LoadFromBuffer(string buffer)
        {
            var deserializer = new XmlSerializer(typeof (Game));
            byte[] bytes = Encoding.GetEncoding("iso-8859-1").GetBytes(buffer);
            var textReader = new MemoryStream(bytes);
            return (Game) deserializer.Deserialize(textReader);
        }

        public GameBase GetGameObject(Guid guid)
        {
            foreach (Act act in Acts)
            {
                if (act.ID == guid)
                {
                    return act;
                }
                GameBase item = act.GetGameObject(guid);
                if (item != null)
                {
                    return item;
                }
            }
            return null;
        }
    }
}