﻿using System.ComponentModel;

namespace GameWizardModel
{
    public class RewardBehavior : Behavior
    {
        public RewardBehavior()
        {
            DisplayName = "Reward Behavior";
        }

        public string Certificates { get; set; }

        [Category("RewardBehavior")]
        public string Promotions { get; set; }

        [Category("RewardBehavior")]
        public string Trophies { get; set; }

        [Category("RewardBehavior")]
        public int Points { get; set; }
    }
}