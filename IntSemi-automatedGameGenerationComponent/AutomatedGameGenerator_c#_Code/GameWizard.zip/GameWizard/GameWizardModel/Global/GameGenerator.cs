﻿using System;

namespace GameWizardModel
{
    public class GameGenerator
    {
        public GameLengthsEnum GameLengthsEnum
        {
            get { throw new NotImplementedException(); }
            set { }
        }

        public GameDifficultiesEnum GameDifficultiesEnum
        {
            get { throw new NotImplementedException(); }
            set { }
        }

        public Subject Subject
        {
            get { throw new NotImplementedException(); }
            set { }
        }

        public static Game GenerateGame(GameType type, Subject subject, GameDifficultiesEnum difficulty,
                                        GameLengthsEnum length)
        {
            throw new NotImplementedException();
        }

        public static Game GenerateRandomTestGame(string gameName, GameType type, Subject subject,
                                                  GameDifficultiesEnum difficulty, GameLengthsEnum length)
        {
            var rand = new Random();
            int actCount = ((int) length + 1)*2;

            var game = new Game();
            game.Name = gameName;
            for (int i = 0; i < actCount; ++i)
            {
                var act = new Act();
                game.Acts.Add(act);

                act.Name = string.Format("Act {0}", i + 1);

                int sceneCount = rand.Next(actCount) + 1;
                for (int j = 0; j < sceneCount; ++j)
                {
                    var scene = new Scene();
                    act.Scenes.Add(scene);

                    scene.Name = string.Format("Scene {0}.{1}", i + 1, j + 1);

                    int screenCount = rand.Next(actCount) + 1;
                    for (int k = 0; k < screenCount; ++k)
                    {
                        var screen = new Screen();
                        scene.Screens.Add(screen);

                        screen.Name = string.Format("Screen {0}.{1}.{2}", i + 1, j + 1, k + 1);
                    }
                }
            }

            return game;
        }

        public static Game GenerateTestGame()
        {
            //Screens
            var Screen1 = new Screen();
            Screen1.Name = "Screen 1";
            Screen1.Background = "BlueSky.jpg";
            //there are no game asset types yet

            var Screen1_1 = new Screen();
            Screen1_1.Name = "Screen 1.1";
            Screen1_1.Background = "Park.jpg";
            //there are no game asset types yet

            var Screen2 = new Screen();
            Screen2.Name = "Screen 2";
            Screen2.Background = "Office.jpg";
            //there are no game asset types yet

            //scenes
            var Scene1 = new Scene();
            Scene1.Name = "Scene 1";
            Scene1.Screens.Add(Screen1);

            var Scene1_1 = new Scene();
            Scene1_1.Name = "Scene 1.1";
            Scene1_1.Screens.Add(Screen1_1);

            var Scene2 = new Scene();
            Scene2.Name = "Scene 2";
            Scene2.Screens.Add(Screen2);

            //Acts
            var Act1 = new Act();
            Act1.Name = "Act 1";
            Act1.Scenes.Add(Scene1);
            Act1.Scenes.Add(Scene1_1);

            var Act2 = new Act();
            Act2.Name = "Act 2";
            Act2.Scenes.Add(Scene2);

            //Game
            var newGame = new Game();
            newGame.Name = "Test Game";
            newGame.GameType = new QuizGameType();
            newGame.Acts.Add(Act1);
            newGame.Acts.Add(Act2);

            return newGame;
        }
    }
}