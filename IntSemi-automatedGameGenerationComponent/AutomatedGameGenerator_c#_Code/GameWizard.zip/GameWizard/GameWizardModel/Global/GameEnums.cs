﻿namespace GameWizardModel
{
    public enum GameLengthsEnum
    {
        Short,
        Medium,
        Long
    };

    public enum GameDifficultiesEnum
    {
        Easy,
        Medium,
        Hard
    };

    public enum Transition
    {
        None,
        FadeOutQuick,
        FadeOutSlow,
        FadeInQuick,
        FadeInSlow
        //ect...
    }

    public enum VisibilityModifier
    {
        Hide,
        Show
    }

    public enum TriggerTypes
    {
        Click,
        DoubleClick,
        RightClick,
        Hover,
        Timed
    }

    public enum Control
    {
        Player,
        NPC
    }
}