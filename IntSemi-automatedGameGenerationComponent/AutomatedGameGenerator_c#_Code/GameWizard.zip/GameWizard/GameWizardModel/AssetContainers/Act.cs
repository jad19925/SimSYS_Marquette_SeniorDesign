﻿using System;
using System.Collections.ObjectModel;

namespace GameWizardModel
{
    public class Act : AssetContainer
    {
        public Act()
        {
            Scenes = new ObservableCollection<Scene>();
        }

        public ObservableCollection<Scene> Scenes { get; set; }

        public GameBase GetGameObject(Guid guid)
        {
            foreach (Scene scene in Scenes)
            {
                if (scene.ID == guid)
                {
                    return scene;
                }
                GameBase item = scene.GetGameObject(guid);
                if (item != null)
                {
                    return item;
                }
            }
            return null;
        }
    }
}