﻿using System;
using System.Collections.ObjectModel;

namespace GameWizardModel
{
    public class Scene : AssetContainer
    {
        public Scene()
        {
            Screens = new ObservableCollection<Screen>();
        }

        public ObservableCollection<Screen> Screens { get; set; }

        public override string Background
        {
            get { return _background; }
            set
            {
                _background = value;
                NotifyPropertyChanged("Background");
                SetChildrenBackground();
            }
        }

        private void SetChildrenBackground()
        {
            foreach (Screen screen in Screens)
            {
                screen.Background = _background;
            }
        }

        public GameBase GetGameObject(Guid guid)
        {
            foreach (Screen screen in Screens)
            {
                if (screen.ID == guid)
                {
                    return screen;
                }
            }
            return null;
        }
    }
}