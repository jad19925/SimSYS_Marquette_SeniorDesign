﻿using System.IO;
using System.Xml.Serialization;
using GameWizardModel;

namespace ModelTesting
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            TestSerialization();
        }

        public static void TestSerialization()
        {
            var deserializer = new XmlSerializer(typeof (Game));
            TextReader textReader = new StreamReader(@"./TestXML.xml");
            var readGame = (Game) deserializer.Deserialize(textReader);

            textReader.Close();
        }
    }
}