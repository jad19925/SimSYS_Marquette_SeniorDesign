﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace SLPropertyGrid
{
    public class DateTimeValueEditor : ValueEditorBase
    {
        #region Fields

        private readonly StackPanel pnl;
        private object currentValue;
        protected DatePicker dtp;
        private bool showingDTP;
        protected TextBox txt;

        #endregion

        #region Constructors

        /// <summary>
        ///     Constructor
        /// </summary>
        /// <param name="label"></param>
        /// <param name="property"></param>
        public DateTimeValueEditor(PropertyGridLabel label, PropertyItem property)
            : base(label, property)
        {
            currentValue = property.Value;
            property.PropertyChanged += property_PropertyChanged;
            property.ValueError += property_ValueError;

            pnl = new StackPanel();
            Content = pnl;

            dtp = new DatePicker();
            dtp.Visibility = Visibility.Visible;
            dtp.Margin = new Thickness(0);
            dtp.Padding = new Thickness(2);
            dtp.VerticalAlignment = VerticalAlignment.Center;
            dtp.HorizontalAlignment = HorizontalAlignment.Stretch;
            dtp.CalendarOpened += dtp_CalendarOpened;
            dtp.CalendarClosed += dtp_CalendarClosed;
            dtp.LostFocus += dtp_LostFocus;
            dtp.Background = new SolidColorBrush(Colors.White);
            dtp.Foreground = Property.CanWrite ? new SolidColorBrush(Colors.Black) : new SolidColorBrush(Colors.Gray);

            pnl.Children.Add(dtp);
            dtp.Focus();

            ShowTextBox();
        }

        #endregion

        #region Overrides

        /// <summary>
        /// </summary>
        /// <param name="e"></param>
        protected override void OnGotFocus(RoutedEventArgs e)
        {
            Debug.WriteLine("DateTimeValueEditor : OnGotFocus");

            if (showingDTP)
                return;

            base.OnGotFocus(e);

            if (Property.CanWrite)
                ShowDatePicker();
        }

        /// <summary>
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLostFocus(RoutedEventArgs e)
        {
            Debug.WriteLine("DateTimeValueEditor : OnLostFocus");

            if (showingDTP)
                return;

            base.OnLostFocus(e);
        }

        #endregion

        #region Methods

        private void ShowDatePicker()
        {
            if (null == txt)
                return;

            dtp.SelectedDateChanged -= dtp_SelectedDateChanged;
            dtp.Visibility = Visibility.Visible;
            dtp.Focus();

            txt.Visibility = Visibility.Collapsed;
            pnl.Children.Remove(txt);
            txt = null;

            dtp.SelectedDate = (DateTime) currentValue;
            dtp.SelectedDateChanged += dtp_SelectedDateChanged;
        }

        private void ShowTextBox()
        {
            if (null != txt)
                return;

            txt = new TextBox();
            txt.Height = 20;
            txt.BorderThickness = new Thickness(0);
            txt.Margin = new Thickness(0);
            txt.Padding = new Thickness(2);
            txt.VerticalAlignment = VerticalAlignment.Center;
            txt.HorizontalAlignment = HorizontalAlignment.Stretch;
            txt.Text = currentValue.ToString();
            txt.IsReadOnly = !Property.CanWrite;
            txt.Foreground = Property.CanWrite ? new SolidColorBrush(Colors.Black) : new SolidColorBrush(Colors.Gray);
            txt.Background = new SolidColorBrush(Colors.White);
            txt.Text = ((DateTime) Property.Value).ToShortDateString();
            pnl.Children.Add(txt);

            showingDTP = false;
            dtp.Visibility = Visibility.Collapsed;
        }

        #endregion

        #region Event Handlers

        private void property_ValueError(object sender, ExceptionEventArgs e)
        {
            MessageBox.Show(e.EventException.Message);
        }

        private void property_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Value")
                currentValue = Property.Value;

            if (e.PropertyName == "CanWrite")
            {
                if (!Property.CanWrite && showingDTP)
                    ShowTextBox();
            }
        }

        private void dtp_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            currentValue = e.AddedItems[0];
            Property.Value = currentValue;
        }

        private void dtp_CalendarOpened(object sender, RoutedEventArgs e)
        {
            showingDTP = true;
        }

        private void dtp_CalendarClosed(object sender, RoutedEventArgs e)
        {
            dtp.Focus();
        }

        private void dtp_LostFocus(object sender, RoutedEventArgs e)
        {
            currentValue = dtp.SelectedDate;
            Property.Value = currentValue;
            if (dtp.IsDropDownOpen)
                return;
            ShowTextBox();
        }

        #endregion
    }
}