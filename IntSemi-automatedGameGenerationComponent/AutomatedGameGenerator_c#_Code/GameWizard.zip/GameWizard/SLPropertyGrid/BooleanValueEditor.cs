﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace SLPropertyGrid
{
    /// <summary>
    ///     An editor for a Boolean Type
    /// </summary>
    public class BooleanValueEditor : ValueEditorBase
    {
        protected CheckBox checkBox;

        /// <summary>
        ///     Constructor
        /// </summary>
        /// <param name="label"></param>
        /// <param name="property"></param>
        public BooleanValueEditor(PropertyGridLabel label, PropertyItem property)
            : base(label, property)
        {
            property.PropertyChanged += property_PropertyChanged;

            checkBox = new CheckBox();
            checkBox.Margin = new Thickness(2);
            checkBox.VerticalAlignment = VerticalAlignment.Center;
            checkBox.IsEnabled = Property.CanWrite;
            checkBox.IsChecked = (bool) property.Value;

            checkBox.Checked += checkBox_Checked;
            checkBox.Unchecked += checkBox_Unchecked;

            Content = checkBox;
        }

        private void property_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Value")
                checkBox.IsChecked = (bool) Property.Value;
        }

        private void checkBox_Unchecked(object sender, RoutedEventArgs e)
        {
            Property.Value = false;
        }

        private void checkBox_Checked(object sender, RoutedEventArgs e)
        {
            Property.Value = true;
        }
    }
}