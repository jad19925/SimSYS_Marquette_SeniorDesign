﻿using System;
using System.Globalization;

namespace SLPropertyGrid.Converters
{
    public class Int16Converter : BaseNumberConverter
    {
        // Methods
        internal override Type TargetType
        {
            get { return typeof (short); }
        }

        internal override object FromString(string value, CultureInfo culture)
        {
            return short.Parse(value, culture);
        }

        internal override object FromString(string value, NumberFormatInfo formatInfo)
        {
            return short.Parse(value, NumberStyles.Integer, formatInfo);
        }

        internal override object FromString(string value, int radix)
        {
            return Convert.ToInt16(value, radix);
        }

        internal override string ToString(object value, NumberFormatInfo formatInfo)
        {
            var num = (short) value;
            return num.ToString("G", formatInfo);
        }

        // Properties
    }
}