﻿using System;

namespace SLPropertyGrid
{

    #region Using Directives

    #endregion

    #region EditorAttribute

    /// <summary>
    ///     EditorAttribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public sealed class EditorAttribute : Attribute
    {
        #region Constructors

        /// <summary>
        ///     Constructor
        /// </summary>
        /// <param name="typeName">
        ///     The AssemblyQualifiedName of the type that must inherit from <see cref="ValueEditorBase" />
        /// </param>
        public EditorAttribute(string typeName)
        {
            if (string.IsNullOrEmpty(typeName)) throw new ArgumentNullException("typeName");
            EditorTypeName = typeName;
        }

        /// <summary>
        ///     Constructor
        /// </summary>
        /// <param name="type">
        ///     The type that must inherit from <see cref="ValueEditorBase" />
        /// </param>
        public EditorAttribute(Type type)
        {
            if (type == null) throw new ArgumentNullException("type");
            EditorTypeName = type.AssemblyQualifiedName;
        }

        #endregion

        #region Properties

        /// <summary>
        ///     Gets the Editors TypeName
        /// </summary>
        public string EditorTypeName { get; private set; }

        #endregion

        #region Overrides

        /// <summary>
        ///     Checks for equality
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            if (obj == this)
            {
                return true;
            }
            var attribute = obj as EditorAttribute;
            return (((attribute != null) && (attribute.EditorTypeName == EditorTypeName)));
        }

        /// <summary>
        ///     Gets the hashcode
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        #endregion
    }

    #endregion
}