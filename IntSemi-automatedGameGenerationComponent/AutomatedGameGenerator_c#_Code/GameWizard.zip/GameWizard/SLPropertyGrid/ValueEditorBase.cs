﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace SLPropertyGrid
{
    public abstract class ValueEditorBase : ContentControl, IPropertyValueEditor
    {
        private bool _isSelected;

        #region IPropertyValueEditor Members

        /// <summary>
        ///     Gets the associated label for this Editor control
        /// </summary>
        public PropertyGridLabel Label { get; private set; }

        /// <summary>
        ///     Gets the associated PropertyItem for this control
        /// </summary>
        public PropertyItem Property { get; private set; }

        #endregion

        protected ValueEditorBase()
        {
        }

        /// <summary>
        ///     Constructor
        /// </summary>
        /// <param name="label">The associated label for this Editor control</param>
        /// <param name="property">The associated PropertyItem for this control</param>
        public ValueEditorBase(PropertyGridLabel label, PropertyItem property)
        {
            Label = label;
            Label.MouseLeftButtonDown += Label_MouseLeftButtonDown;
            Label.MouseLeftButtonUp += Label_MouseLeftButtonUp;
            if (!property.CanWrite)
                Label.Foreground = new SolidColorBrush(Colors.Gray);

            Property = property;
            BorderThickness = new Thickness(0);
            Margin = new Thickness(0);
            HorizontalAlignment = HorizontalAlignment.Stretch;
            HorizontalContentAlignment = HorizontalAlignment.Stretch;
        }

        /// <summary>
        ///     Gets or sets whether this item is selected
        /// </summary>
        public bool IsSelected
        {
            get { return _isSelected; }
            set
            {
                if (_isSelected != value)
                {
                    _isSelected = value;

                    if (value)
                    {
                        Label.Background = new SolidColorBrush(PropertyGrid.backgroundColorFocused);
                        Label.Foreground = new SolidColorBrush(Colors.White);
                    }
                    else
                    {
                        Label.Background = new SolidColorBrush(Colors.Transparent);
                        if (Property.CanWrite)
                            Label.Foreground = new SolidColorBrush(Colors.Black);
                        else
                            Label.Foreground = new SolidColorBrush(Colors.Gray);
                    }
                }
            }
        }

        protected override void OnGotFocus(RoutedEventArgs e)
        {
            if (null == Label)
                return;

            base.OnGotFocus(e);
        }

        protected override void OnLostFocus(RoutedEventArgs e)
        {
            if (null == Label)
                return;

            base.OnLostFocus(e);

            if (IsSelected)
                Label.Background = new SolidColorBrush(PropertyGrid.backgroundColor);
            else
                Label.Background = new SolidColorBrush(Colors.Transparent);

            if (Property.CanWrite)
                Label.Foreground = new SolidColorBrush(Colors.Black);
            else
                Label.Foreground = new SolidColorBrush(Colors.Gray);
        }

        private void Label_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
        }

        private void Label_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Focus();
        }
    }
}