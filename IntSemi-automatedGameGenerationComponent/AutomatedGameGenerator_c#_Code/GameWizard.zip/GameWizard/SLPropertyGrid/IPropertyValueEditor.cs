﻿namespace SLPropertyGrid
{
    public interface IPropertyValueEditor
    {
        PropertyGridLabel Label { get; }
        PropertyItem Property { get; }
    }
}