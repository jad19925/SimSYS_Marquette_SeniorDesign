function skipProfileConfig() {
	alert("Profile Configuration skipped!!");
	userProfileConfigurePage();
}

function configureGameElement() {
	document.form1.action = "/GameGenerator/configureActs.htm";
	document.form1.method = "GET";
	document.form1.submit();
}

function userProfileConfigurePage() {
	document.form1.action = "/GameGenerator/userProfile.htm";
	document.form1.method = "GET";
	document.form1.submit();
}

function generateXML() {
	alert("GameEngine Input XML generated!!");
	document.form1.action = "/GameGenerator/generateGameConfig.htm";
	document.form1.method = "GET";
	document.form1.submit();

}

function toggleGameElementConfig() {
	$('#gameElementConfig').show();
}
function popUpWin(url) {
	popupWindow = window
			.open(
					url,
					'popUpWindow',
					'height=700,width=800,left=10,top=10,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes');
}
