package edu.utdallas.gamegenerator.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 * 
 * @author Naveen
 * 
 */
public class Act {

    private String actTitle;
    private String actId;
    private List<Scene> sceneList;
    private int noOfScenes;
    private String defaultStyle = "";

    /**
 * 
 */
    public Act() {
        super();
    }

    /**
     * 
     * @param actId1   
     */
    public Act(final String actId1) {
        super();
        this.actId = actId1;
    }

    /**
     * 
     * @param actId1  
     * @param actTitle1  
     */
    public Act(final String actId1, final String actTitle1) {
        super();
        this.actId = actId1;
        this.actTitle = actTitle1;
    }

    /**
     * @return the actTitle  
     */
    public final String getActTitle() {
        return actTitle;
    }

    /**
     * @param actTitle1  
     *            the actTitle to set
     */
    public final void setActTitle(final String actTitle1) {
        this.actTitle = actTitle1;
    }

    /**
     * @return the sceneList
     */
    public final List<Scene> getSceneList() {
        return sceneList;
    }

    /**
     * @param sceneList1
     *            the sceneList to set
     */
    @XmlElement(name = "Scene")
    public final void setSceneList(final List<Scene> sceneList1) {
        this.sceneList = sceneList1;
    }

    /**
     * @return the actId
     */
    public final String getActId() {
        return actId;
    }

    /**
     * @param actId1
     *            the actId to set
     */
    @XmlTransient
    public final void setActId(final String actId1) {
        this.actId = actId1;
    }

    /**
     * @return the noOfScenes
     */
    public final int getNoOfScenes() {
        return noOfScenes;
    }

    /**
     * @param noOfScenes1
     *            the noOfScenes to set
     */
    public final void setNoOfScenes(final int noOfScenes1) {
        this.noOfScenes = noOfScenes1;
    }

    /**
     * @return the defaultStyle
     */
    public final String getDefaultStyle() {
        return defaultStyle;
    }

    /**
     * @param defaultStyle1
     *            the defaultStyle to set
     */
    @XmlTransient
    public final void setDefaultStyle(final String defaultStyle1) {
        this.defaultStyle = defaultStyle1;
    }

}
