/**
 * 
 */
package edu.utdallas.gamegenerator.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Preethi
 * 
 */
@XmlRootElement
public class UserProfileConfiguration {

    private boolean name;
    private boolean fullName;
    private boolean nickName;
    private boolean profilePicture;
    private boolean age;
    private boolean country;
    private transient boolean languagePref;
    private transient List<String> existingPlayChar;

    /**
     * @return the name
     */
    public final boolean isName() {
return name;
    }

    /**
     * @param name1
     *            the name to set
     */
    @XmlElement
    public final void setName(final boolean name1) {
        this.name = name1;
    }

    /**
     * @return the fullName
     */
    public final boolean isFullName() {
        return fullName;
    }

    /**
     * @param fullName1
     *            the fullName to set
     */
    @XmlElement
    public final void setFullName(final boolean fullName1) {
        this.fullName = fullName1;
    }

    /**
     * @return the nickName
     */
    public final boolean isNickName() {
        return nickName;
    }

    /**
     * @param nickName1
     *            the nickName to set
     */
    @XmlElement
    public final void setNickName(final boolean nickName1) {
        this.nickName = nickName1;
    }

    /**
     * @return the profilePicture
     */
    public final boolean isProfilePicture() {
        return profilePicture;
    }

    /**
     * @param profilePicture1
     *            the profilePicture to set
     */
    @XmlElement
    public final void setProfilePicture(final boolean profilePicture1) {
        this.profilePicture = profilePicture1;
    }

    /**
     * @return the age
     */
    public final boolean isAge() {
        return age;
    }

    /**
     * @param age1
     *            the age to set
     */
    @XmlElement
    public final void setAge(final boolean age1) {
        this.age = age1;
    }

    /**
     * @return the country
     */
    public final boolean isCountry() {
        return country;
    }

    /**
     * @param country1
     *            the country to set
     */
    @XmlElement
    public final void setCountry(final boolean country1) {
        this.country = country1;
    }

    /**
     * @return the languagePreference
     */
    public final boolean isLanguagePreference() {
        return languagePref;
    }

    /**
     * @param languagePref1
     *            the languagePreference to set
     */
    @XmlElement
    public final void setLanguagePreference(final boolean languagePref1) {
        this.languagePref = languagePref1;
    }

    /**
     * @return the existingPlayerCharacter
     */
    public final List<String> getExistingPlayerCharacter() {
        return existingPlayChar;
    }

    /**
     * @param existingPlayChar1
     *            the existingPlayerCharacter to set
     */
    @XmlElement
    public final void setExistingPlayerCharacter(
            final List<String> existingPlayChar1) {
        this.existingPlayChar = existingPlayChar1;
    }

}
