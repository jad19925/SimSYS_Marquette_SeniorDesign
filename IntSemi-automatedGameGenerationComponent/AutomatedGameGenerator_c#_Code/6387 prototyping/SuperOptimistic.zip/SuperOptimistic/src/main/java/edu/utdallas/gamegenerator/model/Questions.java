package edu.utdallas.gamegenerator.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
/**
 * 
 * @author Preethi
 *
 */
@XmlRootElement(name = "Question")
public class Questions {

    private List<QuestionInfo> questionList;

    /**
     * @return the questionList
     */
    public final List<QuestionInfo> getQuestionList() {
        return questionList;
    }

    /**
     * @param questionList1
     *            the questionList to set
     */
    @XmlElement(name = "Question")
    public  final void setQuestionList(List<QuestionInfo> questionList1) {
        this.questionList = questionList1;
    }

}
