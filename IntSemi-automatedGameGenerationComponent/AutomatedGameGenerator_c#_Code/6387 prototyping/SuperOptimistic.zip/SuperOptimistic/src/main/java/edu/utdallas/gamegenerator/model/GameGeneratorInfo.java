package edu.utdallas.gamegenerator.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Naveen
 * 
 */

@XmlRootElement
public class GameGeneratorInfo {

    private transient UserProfileConfiguration userProfile;

    private List<Act> actList;

    private String noOfActs;

    private String selElement;
    
    private String challenge;

    /**
     * @return the userProfileConfiguration
     */
    public final UserProfileConfiguration getUserProfileConfiguration() {
        return userProfile;
    }

    /**
     * @param userProfile1
     *            the userProfileConfiguration to set
     */
    @XmlElement
    public final void setUserProfileConfiguration(
            final UserProfileConfiguration userProfile1) {
        this.userProfile = userProfile1;
    }

    /**
     * @return the actList
     */
    public final List<Act> getActList() {
        return actList;
    }

    /**
     * @param actList1
     *            the actList to set
     */
    @XmlElement(name = "Act")
    public final void setActList(final List<Act> actList1) {
        this.actList = actList1;
    }

    /**
     * @return the noOfActs
     */
    public final String getNoOfActs() {
        return noOfActs;
    }

    /**
     * @param noOfActs1
     *            the noOfActs to set
     */
    public final void setNoOfActs(final String noOfActs1) {
        this.noOfActs = noOfActs1;
    }

    /**
     * @return the selElement
     */
    public final String getSelElement() {
        return selElement;
    }

    /**
     * @param selElement1
     *            the selElement to set
     */
    public final void setSelElement(final String selElement1) {
        this.selElement = selElement1;
    }

    /**
     * @return the challenge
     */
    public final String getChallenge() {
        return challenge;
    }

    /**
     * @param challenge1 the challenge to set
     */
    @XmlElement(name = "Challenge")
    public final void setChallenge(String challenge1) {
        this.challenge = challenge1;
    }

}
