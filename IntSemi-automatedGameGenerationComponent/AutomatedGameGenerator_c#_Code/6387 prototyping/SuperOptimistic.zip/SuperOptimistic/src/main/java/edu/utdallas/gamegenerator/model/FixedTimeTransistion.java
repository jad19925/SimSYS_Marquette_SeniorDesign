package edu.utdallas.gamegenerator.model;

import javax.xml.bind.annotation.XmlElement;

/**
 * 
 * @author Naveen
 * 
 */
public class FixedTimeTransistion extends ScreenTransistion {

    private String unitTime;
    private String type;

    /**
     * @return the unitTime
     */
    public final String getUnitTime() {
        return unitTime;
    }

    /**
     * @param unitTime1
     *            the unitTime to set
     */
    @XmlElement
    public final void setUnitTime(final String unitTime1) {
        this.unitTime = unitTime1;
    }

    /**
     * @return the type
     */
    public final String getType() {
        return type;
    }

    /**
     * @param type1
     *            the type to set
     */
    @XmlElement
    public final void setType(final String type1) {
        this.type = type1;
    }

}
