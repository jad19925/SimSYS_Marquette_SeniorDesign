package edu.utdallas.gamegenerator.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import edu.utdallas.gamegenerator.constants.ApplicationConstants;
import edu.utdallas.gamegenerator.model.Act;
import edu.utdallas.gamegenerator.model.GameGeneratorInfo;
import edu.utdallas.gamegenerator.model.QuestionInfo;
import edu.utdallas.gamegenerator.model.Scene;
import edu.utdallas.gamegenerator.model.Screen;
import edu.utdallas.gamegenerator.service.ManageGameGeneratorService;
import edu.utdallas.gamegenerator.util.ManageGameElementConfigHelper;
import edu.utdallas.gamegenerator.util.Utility;

/**
 * 
 * @author Meyy
 * 
 */
@Controller
public class ManageGameElementConfigController {

    private static final String SCREENCONFIG_METH = "From getScreenCountConfig :";

    private static final String LIST_ACTS_PATH = "/GameElement/ListActs";

    private static final Logger LOG = Logger
            .getLogger(ManageGameElementConfigController.class);

    private transient ManageGameGeneratorService manageGameGenServ;

    /**
     * 
     * This method redirects the control to tree structure page
     * 
     * @param request    
     * @param session  
     * @param model  
     * @param session1  
     * @return ModelAndView   
     */
    @RequestMapping(value = "/listActHierarchy.htm", method = RequestMethod.GET)
    public final ModelAndView listActHierarchy(
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        GameGeneratorInfo gameGeneratorInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);
        if (null == gameGeneratorInfo) {
            gameGeneratorInfo = new GameGeneratorInfo();
            session.setAttribute(ApplicationConstants.GAME_GEN_INFO,
                    gameGeneratorInfo);
        }

        return new ModelAndView(LIST_ACTS_PATH,
                ApplicationConstants.GAME_GEN_INFO, gameGeneratorInfo);
    }

    /**
     * 
     * This method redirects the control to Act Configuration page
     * 
     * @param request   
     * @param session   
     * @param model  
     * @param session1  
     * @return ModelAndView  
     */
    @RequestMapping(value = "/actInfo.htm", method = RequestMethod.GET)
    public final ModelAndView manageGameProfile(
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        final List<Act> populateAct = Utility.populateAct();
        session.setAttribute("ActList", populateAct);

        return new ModelAndView("ConfigureActDetails");
    }

    /**
     * 
     * This method redirects the control to number of act configuration page
     * 
     * @param request  
     * @param session  
     * @param model  
     * @param session1  
     * @return ModelAndView  
     */
    @RequestMapping(value = "/configureActs.htm", method = RequestMethod.GET)
    public final ModelAndView getActInfo(final HttpServletRequest request,
            final HttpSession session, final ModelMap model,
            final HttpSession session1) {
        GameGeneratorInfo gameGeneratorInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);
        if (null == gameGeneratorInfo) {
            gameGeneratorInfo = new GameGeneratorInfo();
            session.setAttribute(ApplicationConstants.GAME_GEN_INFO,
                    gameGeneratorInfo);
        }

        return new ModelAndView("/GameElement/ActsConfig",
                ApplicationConstants.GAME_GEN_INFO, gameGeneratorInfo);
    }

    /**
     * 
     * This method receives acts count configuration details from the view
     * 
     * @param gameGeneratorInfo  
     * @param request  
     * @param session  
     * @param model  
     * @param session1  
     * @return ModelAndView   
     */  
    @RequestMapping(value = "/submitActsInfo.htm", method = RequestMethod.POST)
    public final ModelAndView submitActInfo(
            @ModelAttribute(ApplicationConstants.GAME_GEN_INFO) final GameGeneratorInfo gameGeneratorInfo,
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        List<Act> actList = null;
        String challenge = null;
        if (null != gameGeneratorInfo) {

            final String noOfActs = gameGeneratorInfo.getNoOfActs();
            actList = new ArrayList<Act>();
            Act act;
            challenge = gameGeneratorInfo.getChallenge();
            if (null != noOfActs && !"".equals(noOfActs.trim())
                    && Integer.parseInt(noOfActs) > 0) {
                final int iNoOfActs = Integer.parseInt(noOfActs);
                // if(iNoOfActs > 0)
                // {
                for (int i = 1; i <= iNoOfActs; i++) {
                    act = new Act("act" + i, "Act " + i);
                    actList.add(act);
                }
                // }
            }
        }
        final GameGeneratorInfo curgameGenInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);
        if (null == curgameGenInfo) {
            gameGeneratorInfo.setActList(actList);
            gameGeneratorInfo.setChallenge(challenge);
            session.setAttribute(ApplicationConstants.GAME_GEN_INFO,
                    gameGeneratorInfo);
        } else {
            curgameGenInfo.setActList(actList);
            curgameGenInfo.setChallenge(challenge);
            session.setAttribute(ApplicationConstants.GAME_GEN_INFO,
                    curgameGenInfo);
        }

        return new ModelAndView(LIST_ACTS_PATH);
    }

    /**
     * 
     * This method redirects the control to scene configuration view
     * 
     * @param gameGeneratorInfo  
     * @param request  
     * @param session  
     * @param model  
     * @param session1  
     * @return ModelAndView  
     */
    @RequestMapping(value = "/getSceneConfigForAct.htm", method = RequestMethod.GET)
    public final ModelAndView getSceneConfig(
            @ModelAttribute(ApplicationConstants.GAME_GEN_INFO) final GameGeneratorInfo gameGeneratorInfo,
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        Act act = null;
        if (null != gameGeneratorInfo) {
            final String actId = gameGeneratorInfo.getSelElement();
            LOG.info("From get method :" + actId);

            final GameGeneratorInfo currGameGenInfo = (GameGeneratorInfo) session
                    .getAttribute(ApplicationConstants.GAME_GEN_INFO);
            if (null != currGameGenInfo) {
                final List<Act> actList = currGameGenInfo.getActList();
                if (null != actList && !actList.isEmpty()) {
                    for (Act act1 : actList) {
                        if (act1.getActId().equalsIgnoreCase(actId)) {
                            act = act1;
                        } else {
                            act1.setDefaultStyle(null);
                        }
                    }
                }
            }
        }
        if (null == act) {
            act = new Act();
        }
        act.setDefaultStyle(ApplicationConstants.DEFAULT_STYLE);
        return new ModelAndView("/GameElement/GetSceneCountConfig", "Act", act);
    }

    /**
     * 
     * This method receives scene configuration details from the view
     * 
     * @param act  
     * @param request  
     * @param session  
     * @param model  
     * @param session1  
     * @return ModelAndView  
     */
    @RequestMapping(value = "/submitScenesInfo.htm", method = RequestMethod.POST)
    public final ModelAndView submitSceneConfig(
            @ModelAttribute("Act") final Act act,
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        GameGeneratorInfo gameGeneratorInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);
        List<Scene> sceneList;
        if (null != act) {

            final int noOfScenes = act.getNoOfScenes();
            if (noOfScenes > 0) {
                LOG.info("Selected Scene count : + " + noOfScenes);
                LOG.info("Selected Act Id 1 : + " + act.getActId());
                sceneList = new ArrayList<Scene>();
                StringBuffer sceneId; // Combination of Actid and count

                for (int i = 1; i <= noOfScenes; i++) {
                    sceneId = new StringBuffer();
                    sceneId.append(act.getActId());
                    sceneId.append('_');
                    sceneId.append("scene");
                    sceneId.append(i);
                    final Scene scene = new Scene(sceneId.toString(), "Scene "
                            + i);
                    sceneList.add(scene);

                }
                gameGeneratorInfo = ManageGameElementConfigHelper
                        .populateActWithConfigDetails(act, gameGeneratorInfo,
                                sceneList, noOfScenes);
            } else {
                gameGeneratorInfo = ManageGameElementConfigHelper
                        .populateActWithConfigDetails(act, gameGeneratorInfo,
                                null, noOfScenes);
            }
        }
        session.setAttribute(ApplicationConstants.GAME_GEN_INFO,
                gameGeneratorInfo);
        return new ModelAndView(LIST_ACTS_PATH,
                ApplicationConstants.GAME_GEN_INFO, gameGeneratorInfo);
    }

    /**
     * 
     * This method redirects the control to screen configuration page
     * 
     * @param gameGeneratorInfo  
     * @param request  
     * @param session 
     * @param model  
     * @param session1  
     * @return ModelAndView  
     */
    @RequestMapping(value = "/getScreenCountConfig.htm", method = RequestMethod.GET)
    public final ModelAndView getScreenCountConfig(
            @ModelAttribute(ApplicationConstants.GAME_GEN_INFO) final GameGeneratorInfo gameGeneratorInfo,
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        Scene scene = null;
        if (null != gameGeneratorInfo) {
            final String selectedSceneId = gameGeneratorInfo.getSelElement();
            LOG.info(SCREENCONFIG_METH + selectedSceneId);
            final String[] idArr = selectedSceneId.split("_");
            final String currentActId = idArr[0];

            final GameGeneratorInfo curGameGenInfo = (GameGeneratorInfo) session
                    .getAttribute(ApplicationConstants.GAME_GEN_INFO);
            if (null != curGameGenInfo) {
                final List<Act> actList = curGameGenInfo.getActList();
                if (null != actList && !actList.isEmpty()) {
                    for (Act act : actList) {
                        if (act.getActId().equalsIgnoreCase(currentActId)) {
                            for (Scene currentScene : act.getSceneList()) {
                                if (currentScene.getSceneId().equalsIgnoreCase(
                                        selectedSceneId)) {
                                    scene = currentScene;
                                    act.setDefaultStyle(ApplicationConstants.DEFAULT_STYLE);
                                    scene.setDefaultStyle(ApplicationConstants.DEFAULT_STYLE);
                                } else {
                                    currentScene.setDefaultStyle(null);
                                }
                            }
                        } else {
                            act.setDefaultStyle(null);
                        }
                    }
                }
            }
        }
        if (null == scene) {
            scene = new Scene();
        }
        return new ModelAndView(
                "/GameElement/GetSceneBackDropScreenCountConfig", "Scene",
                scene);
    }

    /**
     * 
     * This method receives screen configuration details from the view
     * 
     * @param scene  
     * @param request  
     * @param session  
     * @param model  
     * @param session1  
     * @return ModelAndView  
     */
    @RequestMapping(value = "/submitScreenCountConfig.htm", method = RequestMethod.POST)
    public final ModelAndView submitScreenCountConfig(
            @ModelAttribute("Scene") final Scene scene,
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {

        GameGeneratorInfo gameGeneratorInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);
        List<Screen> screenList;
        LOG.info("Scene Id :" + scene.getSceneId());
        if (null != scene) {
            final String sceneId = scene.getSceneId();
            final String[] idArr = sceneId.split("_");
            final String currentActId = idArr[0];
            final int noOfScreens = scene.getNoOfScreens();
            if (noOfScreens > 0) {
                LOG.info("Selected Scene count : + " + noOfScreens);
                LOG.info("Selected Scene Id : + " + scene.getSceneId());
                screenList = new ArrayList<Screen>();
                StringBuffer screenId;
                for (int i = 1; i <= noOfScreens; i++) {
                    screenId = new StringBuffer();
                    screenId.append(sceneId);
                    screenId.append('_');
                    screenId.append("screen");
                    screenId.append(i);
                    final Screen screen = new Screen(screenId.toString(),
                            "Screen " + i);
                    screenList.add(screen);
                }
                gameGeneratorInfo = ManageGameElementConfigHelper
                        .populateSceneWithConfigDetails(scene,
                                gameGeneratorInfo, screenList, sceneId,
                                currentActId, noOfScreens);
            } else {
                gameGeneratorInfo = ManageGameElementConfigHelper
                        .populateSceneWithConfigDetails(scene,
                                gameGeneratorInfo, null, sceneId, currentActId,
                                noOfScreens);
            }
        }
        session.setAttribute(ApplicationConstants.GAME_GEN_INFO,
                gameGeneratorInfo);
        return new ModelAndView(LIST_ACTS_PATH,
                ApplicationConstants.GAME_GEN_INFO, gameGeneratorInfo);

    }

    /**
     * @return the manageGameGeneratorService
     */
    public final ManageGameGeneratorService getManageGameGeneratorService() {
        return manageGameGenServ;
    }

    /**
     * @param manageGameServ
     *            the manageGameGeneratorService to set
     */
    public final void setManageGameGeneratorService(
            final ManageGameGeneratorService manageGameServ) {
        this.manageGameGenServ = manageGameServ;
    }

    /**
     * 
     * @param request  
     * @param session  
     * @param model  
     * @param session1  
     * @return ModelAndView  
     */
    @RequestMapping(value = "/showQuestions.htm", method = RequestMethod.GET)
    public final ModelAndView showQuestions(final HttpServletRequest request,
            final HttpSession session, final ModelMap model,
            final HttpSession session1) {
        final String selScreenId = request.getParameter("screen");

        System.out.println("Selected Screen for questionslist :" + selScreenId);

        List<QuestionInfo> questionList = null;
        try {
            questionList = Utility.getQuestionsList();
        } catch (Exception e) {

            e.printStackTrace();
        }

        if (null != questionList) {
            Map<String, List<QuestionInfo>> map = new HashMap<String, List<QuestionInfo>>();
            map.put(selScreenId, questionList);
            session.setAttribute("QuestionList", questionList);
            session.setAttribute("screenId", selScreenId);
            session.setAttribute("questionlistScreenMap", map);
        }
        return new ModelAndView("/GameElement/questionslist");
    }

    /**
     * 
     * @param request  
     * @param session  
     * @param model  
     * @param session1  
     * @return ModelAndView  
     */
    @RequestMapping(value = "/showQuestions.htm", method = RequestMethod.POST)
    public final ModelAndView submitSelQuestions(
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        final String strSelQuestions = request.getParameter("selectedProfiles");
        final String selectedScreen = request.getParameter("selScreenId");
        List<QuestionInfo> questionList = new ArrayList<QuestionInfo>();
        Map<String, List<QuestionInfo>> selectedQuestionsmap = new HashMap<String, List<QuestionInfo>>();
        Map<String, List<QuestionInfo>> map = (Map<String, List<QuestionInfo>>) session
                .getAttribute("questionlistScreenMap");

        if (null != map && null != strSelQuestions
                && !"".equals(strSelQuestions.trim())) {
            List<QuestionInfo> list = map.get(selectedScreen);
            if (null != list) {
                final String[] selProfiles = strSelQuestions.split(":");
                if (selProfiles.length > 0) {
                    for (String questionId : selProfiles) {
                        for (QuestionInfo questionInfo : list) {
                            if (questionId.equalsIgnoreCase(questionInfo
                                    .getQuestionId())) {
                                questionList.add(questionInfo);
                            }
                        }
                    }
                }
            }
        }

        selectedQuestionsmap.put(selectedScreen, questionList);
        if (selectedQuestionsmap.size() > 0) {
            session.setAttribute("selectedQuestionsmap", selectedQuestionsmap);
        }

        return new ModelAndView("/GameElement/questionslist");
    }

}
