package edu.utdallas.gamegenerator.model;

import javax.xml.bind.annotation.XmlElement;

/**
 * 
 * @author Preethi
 * 
 */
public class UserControlledTransistion extends ScreenTransistion {

    private String eventType;

    /**
     * @return the eventType
     */
    public final String getEventType() {
        return eventType;
    }

    /**
     * @param eventType1
     *            the eventType to set
     */
    @XmlElement
    public final void setEventType(final String eventType1) {
        this.eventType = eventType1;
    }

}
