package edu.utdallas.gamegenerator.controller;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import edu.utdallas.gamegenerator.constants.ApplicationConstants;
import edu.utdallas.gamegenerator.constants.ScreenType;
import edu.utdallas.gamegenerator.model.Act;
import edu.utdallas.gamegenerator.model.GameGeneratorInfo;
import edu.utdallas.gamegenerator.model.Prop;
import edu.utdallas.gamegenerator.model.Scene;
import edu.utdallas.gamegenerator.model.Screen;
import edu.utdallas.gamegenerator.service.ManageGameGeneratorService;
import edu.utdallas.gamegenerator.util.ManageGameElementConfigHelper;
import edu.utdallas.gamegenerator.util.Utility;

/**
 * 
 * @author Meyy
 * 
 */

@Controller
public class ManageGameConfigController {
    private static final String SCREEN = "Screen";

    private static final String SCREENCONFIG_METH = "From getScreenCountConfig :";

    private static final String LIST_ACTS_PATH = "/GameElement/ListActs";

    private static final Logger LOG = Logger
            .getLogger(ManageGameConfigController.class);

    private transient ManageGameGeneratorService manageGameGenServ;

    /**
     * 
     * This method redirects the control to screen type configuration page
     * 
     * @param gameGeneratorInfo   
     * @param request  
     * @param session  
     * @param model  
     * @param session1  
     * @return ModelAndView  
     */
    @RequestMapping(value = "/getScreenConfig.htm", method = RequestMethod.GET)
    public final ModelAndView getScreenTypeConfig(
            @ModelAttribute(ApplicationConstants.GAME_GEN_INFO) final GameGeneratorInfo gameGeneratorInfo,
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        Screen screen = null;
        final GameGeneratorInfo curGameGenInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);
        if (null != gameGeneratorInfo) {
            final String selectedScreenId = gameGeneratorInfo.getSelElement();
            LOG.info(SCREENCONFIG_METH + selectedScreenId);
            final String[] idArr = selectedScreenId.split("_");
            final String currentActId = idArr[0];
            final String currentSceneId = idArr[1];

            if (null != curGameGenInfo) {
                final List<Act> actList = curGameGenInfo.getActList();
                screen = getScreenConfigForAnAct(screen, selectedScreenId,
                        currentActId, currentSceneId, actList);
            }
        }
        if (null == screen) {
            screen = new Screen();
        }
        String viewName = "/GameElement/ScreenConfig";
        if (null != screen) {
            final String screenType = screen.getScreenType();
            LOG.info("ScreenType :" + screenType);
            if (null != screenType && !"".equals(screenType)) {
                viewName = setViewName(viewName, screenType);
            }
        }
        session.setAttribute(ApplicationConstants.GAME_GEN_INFO, curGameGenInfo);
        LOG.info("Screen Id :" + screen.getScreenId());
        return new ModelAndView(viewName, SCREEN, screen);
    }

    /**
     * @param viewName  
     * @param screenType  
     * @return viewName   
     */
    private String setViewName(String viewName, final String screenType) {
        if (screenType.equalsIgnoreCase(ScreenType.DIFFICULTYLEVEL.toString())) {
            viewName = "/GameElement/DifficultyLevelConfig";
        }
        if (screenType.equalsIgnoreCase(ScreenType.LISTOFQUESTIONS.toString())) {
            viewName = "/GameElement/ListOfQuestionsConfig";
        }
        if (screenType.equalsIgnoreCase(ScreenType.NOOFQUESTIONS.toString())) {
            viewName = "/GameElement/GetQuestionCountConfig";
        }
        return viewName;
    }

    /**
     * @param screen  
     * @param selectedScreenId   
     * @param currentActId   
     * @param currentSceneId   
     * @param actList  
     * @return screen  
     */
    private Screen getScreenConfigForAnAct(Screen screen,
            final String selectedScreenId, final String currentActId,
            final String currentSceneId, final List<Act> actList) {
        if (null != actList && !actList.isEmpty()) {
            for (Act act : actList) {
                if (act.getActId().equalsIgnoreCase(currentActId)) {
                    for (Scene currentScene : act.getSceneList()) {
                        screen = processScreenConfig(screen, selectedScreenId,
                                currentActId, currentSceneId, act, currentScene);
                    }
                } else {
                    act.setDefaultStyle(null);
                }
            }
        }
        return screen;
    }

    /**
     * @param screen  
     * @param selectedScreenId  
     * @param currentActId  
     * @param currentSceneId  
     * @param act  
     * @param currentScene   
     * @return screen   
     */
    private Screen processScreenConfig(Screen screen,
            final String selectedScreenId, final String currentActId,
            final String currentSceneId, final Act act, final Scene currentScene) {
        if (currentScene.getSceneId().equalsIgnoreCase(
                currentActId + "_" + currentSceneId)) {
            for (Screen screen1 : currentScene.getScreenList()) {
                if (screen1.getScreenId().equalsIgnoreCase(selectedScreenId)) {
                    act.setDefaultStyle(ApplicationConstants.DEFAULT_STYLE);
                    currentScene
                            .setDefaultStyle(ApplicationConstants.DEFAULT_STYLE);
                    screen1.setDefaultStyle(ApplicationConstants.DEFAULT_STYLE);
                    screen = screen1;
                    screen.setPropList(Utility.populatePropList());
                    screen.setNonPlayingCharList(Utility.populateNPList());
                    screen.setButtonList(Utility.populateButtonList());
                    screen.setInformBox(new Prop());

                } else {
                    screen1.setDefaultStyle(null);
                }
            }
        } else {
            currentScene.setDefaultStyle(null);
        }
        return screen;
    }

    /**
     * 
     * This method redirects the control to difficulty level configuration page
     * 
     * @param selectedScreen   
     * @param request  
     * @param session  
     * @param model  
     * @param session1   
     * @return ModelAndView   
     */
    @RequestMapping(value = "/getDiffConfigLevel.htm", method = RequestMethod.GET)
    public final ModelAndView getDifficultyConfig(
            @ModelAttribute(SCREEN) final Screen selectedScreen,
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        Screen screen = null;
        final GameGeneratorInfo curGameGenInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);

        screen = ManageGameElementConfigHelper.getScreenForConfig(
                selectedScreen, screen, curGameGenInfo,
                ScreenType.DIFFICULTYLEVEL.toString(), session);

        final Map<String, Object> mapObj = new HashMap<String, Object>();
        mapObj.put(SCREEN, screen);
        mapObj.put(ApplicationConstants.GAME_GEN_INFO, curGameGenInfo);

        return new ModelAndView("/GameElement/DifficultyLevelConfig", mapObj);
    }

    /**
     * 
     * This method receives difficulty level details from the view
     * 
     * @param selectedScreen  
     * @param request   
     * @param session  
     * @param model  
     * 
     * @return ModelAndView   
     */
    @RequestMapping(value = "/submitDiffConfigLevel.htm", method = RequestMethod.POST)
    public final ModelAndView submitDifficultyConfig(
            @ModelAttribute(SCREEN) final Screen selectedScreen,
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model) {
        GameGeneratorInfo curGameGenInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);
        curGameGenInfo = ManageGameElementConfigHelper
                .addConfiguredScreenToGameGenInfo(selectedScreen, session,
                        curGameGenInfo, ScreenType.DIFFICULTYLEVEL.toString());
        return new ModelAndView(LIST_ACTS_PATH,
                ApplicationConstants.GAME_GEN_INFO, curGameGenInfo);
    }

    /**
     * 
     * This method redirects the control to the Question configuration page
     * 
     * @param selectedScreen  
     * @param request  
     * @param session   
     * @param model  
     * @param session1   
     * @return ModelAndView   
     */
    @RequestMapping(value = "/getQuestionCountConfig.htm", method = RequestMethod.GET)
    public final ModelAndView getQuestionCountConfig(
            @ModelAttribute(SCREEN) final Screen selectedScreen,
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        Screen screen = null;
        final GameGeneratorInfo curGameGenInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);

        screen = ManageGameElementConfigHelper.getScreenForConfig(
                selectedScreen, screen, curGameGenInfo,
                ScreenType.NOOFQUESTIONS.toString(), session);

        final Map<String, Object> mapObj = new HashMap<String, Object>();
        mapObj.put(SCREEN, screen);
        mapObj.put(ApplicationConstants.GAME_GEN_INFO, curGameGenInfo);
        session.setAttribute(ApplicationConstants.GAME_GEN_INFO, curGameGenInfo);
        return new ModelAndView("/GameElement/GetQuestionCountConfig", mapObj);
    }

    /**
     * 
     * This method receives question configuration details from view
     * 
     * @param selectedScreen  
     * @param request  
     * @param session  
     * @param model   
     * 
     * @return ModelAndView   
     */
    @RequestMapping(value = "/submitQuestionCountConfig.htm", method = RequestMethod.POST)
    public final ModelAndView submitQuestionCountConfig(
            @ModelAttribute(SCREEN) final Screen selectedScreen,
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model) {
        GameGeneratorInfo curGameGenInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);
        curGameGenInfo = ManageGameElementConfigHelper
                .addConfiguredScreenToGameGenInfo(selectedScreen, session,
                        curGameGenInfo, ScreenType.NOOFQUESTIONS.toString());
        return new ModelAndView(LIST_ACTS_PATH,
                ApplicationConstants.GAME_GEN_INFO, curGameGenInfo);
    }

    /**
     * This method generates the game input xml from GameGeneratarInfo
     * 
     * @param request   
     * @param session  
     * @param model  
     * @param session1  
     * @return ModelAndView  
     */
    @RequestMapping(value = "/generateGameConfig.htm", method = RequestMethod.GET)
    public final ModelAndView generateGameConfig(
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        final GameGeneratorInfo curGameGenInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);
        if (null != curGameGenInfo) {
            manageGameGenServ.generateXML(curGameGenInfo);
        }
        return new ModelAndView("/UserProfile/homepage");
    }

    /**
     * 
     * This method deletes the act configuration
     * 
     * @param act    
     * @param request        
     * @param session   
     * @param model  
     * @param session1     
     * @return ModelAndView    
     */
    @RequestMapping(value = "/deleteAct.htm", method = RequestMethod.POST)
    public final ModelAndView deleteActConfig(
            @ModelAttribute("Act") final Act act,
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        final GameGeneratorInfo gameGeneratorInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);
        if (null != act && null != gameGeneratorInfo) {
            // if(null != gameGeneratorInfo)
            // {
            final Iterator<Act> iterator = gameGeneratorInfo.getActList()
                    .iterator();
            while (iterator.hasNext()) {
                final Act act2 = (Act) iterator.next();
                if (act2.getActId().equalsIgnoreCase(act.getActId())) {
                    iterator.remove();
                }
            }
            // }
        }
        session.setAttribute(ApplicationConstants.GAME_GEN_INFO,
                gameGeneratorInfo);
        return new ModelAndView(LIST_ACTS_PATH,
                ApplicationConstants.GAME_GEN_INFO, gameGeneratorInfo);
    }

    /**
     * 
     * This method deletes the scene configuration
     * 
     * @param scene   
     * @param request  
     * @param session  
     * @param model  
     * @param session1  
     * @return ModelAndView   
     */
    @RequestMapping(value = "/deleteScene.htm", method = RequestMethod.POST)
    public final ModelAndView deleteSceneConfig(
            @ModelAttribute("Scene") final Scene scene,
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        final GameGeneratorInfo gameGeneratorInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);
        LOG.info("Scene Id :" + scene.getSceneId());
        if (null != scene) {
            final String sceneId = scene.getSceneId();
            final String[] idArr = sceneId.split("_");
            final String currentActId = idArr[0];

            if (null != gameGeneratorInfo) {
                final Iterator<Act> actListIterator = gameGeneratorInfo
                        .getActList().iterator();
                while (actListIterator.hasNext()) {
                    final Act act = (Act) actListIterator.next();
                    if (act.getActId().equalsIgnoreCase(currentActId)) {
                        final Iterator<Scene> sceneListIterator = act
                                .getSceneList().iterator();
                        while (sceneListIterator.hasNext()) {
                            final Scene currentScene = (Scene) sceneListIterator
                                    .next();
                            if (currentScene.getSceneId().equalsIgnoreCase(
                                    sceneId)) {
                                sceneListIterator.remove();
                                act.setNoOfScenes(act.getNoOfScenes() - 1);
                            }
                        }
                    }
                }

            }
        }
        session.setAttribute(ApplicationConstants.GAME_GEN_INFO,
                gameGeneratorInfo);
        return new ModelAndView(LIST_ACTS_PATH,
                ApplicationConstants.GAME_GEN_INFO, gameGeneratorInfo);
    }

    /**
     * 
     * This method deletes the scene configuration
     * 
     * @param selectedScreen   
     * @param request  
     * @param session  
     * @param model    
     * @param session1  
     * @return ModelAndView  
     */
    @RequestMapping(value = "/deleteScreen.htm", method = RequestMethod.POST)
    public final ModelAndView deleteScreenConfig(
            @ModelAttribute(SCREEN) final Screen selectedScreen,
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        final GameGeneratorInfo curGameGenInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);

        if (null != selectedScreen) {
            final String selectedScreenId = selectedScreen.getScreenId();
            LOG.info("From deleteScreenConfig :" + selectedScreenId);
            final String[] idArr = selectedScreenId.split("_");
            final String currentActId = idArr[0];
            final String currentSceneId = idArr[1];

            if (null != curGameGenInfo) {
                final List<Act> actList = curGameGenInfo.getActList();
                if (null != actList && !actList.isEmpty()) {
                    final Iterator<Act> iterator = actList.iterator();
                    while (iterator.hasNext()) {
                        final Act act = (Act) iterator.next();
                        if (act.getActId().equalsIgnoreCase(currentActId)) {
                            final Iterator<Scene> sceneListiterator = act
                                    .getSceneList().iterator();
                            while (sceneListiterator.hasNext()) {
                                final Scene currentScene = (Scene) sceneListiterator
                                        .next();
                                if (currentScene.getSceneId().equalsIgnoreCase(
                                        currentActId + "_" + currentSceneId)) {
                                    final Iterator<Screen> screenListit = currentScene
                                            .getScreenList().iterator();
                                    while (screenListit.hasNext()) {
                                        final Screen currentScreen = (Screen) screenListit
                                                .next();
                                        if (currentScreen.getScreenId()
                                                .equalsIgnoreCase(
                                                        selectedScreenId)) {
                                            screenListit.remove();
                                            currentScene
                                                    .setNoOfScreens(currentScene
                                                            .getNoOfScreens() - 1);
                                        }
                                    }
                                } else {
                                    currentScene.setDefaultStyle(null);
                                }
                            }
                        } else {
                            act.setDefaultStyle(null);
                        }
                    }

                }
            }
        }

        /*
         * Map<String,Object> mapObj = new HashMap<String, Object>();
         * mapObj.put("Screen", screen);
         * mapObj.put(ApplicationConstants.GAME_GENERATOR_INFO,
         * currentGameGenInfo);
         */
        return new ModelAndView(LIST_ACTS_PATH,
                ApplicationConstants.GAME_GEN_INFO, curGameGenInfo);
    }

    /**
     * 
     * This method deletes the scene configuration
     * 
     * @param selectedScreen  
     * @param request  
     * @param session  
     * @param model  
     * @param session1  
     * @return ModelAndView   
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/resetScreen.htm", method = RequestMethod.POST)
    public final ModelAndView resetScreenConfig(
            @ModelAttribute(SCREEN) final Screen selectedScreen,
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        final GameGeneratorInfo curGameGenInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);

        if (null != selectedScreen) {
            final String selectedScreenId = selectedScreen.getScreenId();
            LOG.info("From resetScreenConfig :" + selectedScreenId);
            final String[] idArr = selectedScreenId.split("_");
            final String currentActId = idArr[0];
            final String currentSceneId = idArr[1];
            Screen resetScreen = null;

            if (null != curGameGenInfo) {
                final List<Act> actList = curGameGenInfo.getActList();
                if (null != actList && !actList.isEmpty()) {
                    final Iterator<Act> iterator = actList.iterator();
                    while (iterator.hasNext()) {
                        final Act act = (Act) iterator.next();
                        if (act.getActId().equalsIgnoreCase(currentActId)) {
                            final Iterator<Scene> sceneListiterator = act
                                    .getSceneList().iterator();
                            while (sceneListiterator.hasNext()) {
                                final Scene currentScene = (Scene) sceneListiterator
                                        .next();
                                if (currentScene.getSceneId().equalsIgnoreCase(
                                        currentActId + "_" + currentSceneId)) {
                                    final Iterator<Screen> screenListite = currentScene
                                            .getScreenList().iterator();
                                    while (screenListite.hasNext()) {
                                        final Screen currentScreen = (Screen) screenListite
                                                .next();
                                        if (currentScreen.getScreenId()
                                                .equalsIgnoreCase(
                                                        selectedScreenId)) {
                                            screenListite.remove();
                                            act.setDefaultStyle(ApplicationConstants.DEFAULT_STYLE);
                                            currentScene
                                                    .setDefaultStyle(ApplicationConstants.DEFAULT_STYLE);
                                            // currentScreen.setDefaultStyle(ApplicationConstants.DEFAULT_STYLE);
                                            resetScreen = new Screen(
                                                    currentScreen.getScreenId(),
                                                    currentScreen
                                                            .getScreenName());
                                            resetScreen
                                                    .setDefaultStyle(ApplicationConstants.DEFAULT_STYLE);
                                            break;
                                        } else {
                                            currentScreen.setDefaultStyle(null);
                                        }
                                    }
                                    currentScene.getScreenList().add(
                                            resetScreen);
                                    Collections.sort(
                                            currentScene.getScreenList(),
                                            new Comparator() {

                                                public int compare(
                                                        final Object obj1,
                                                        final Object obj2) {
                                                    final Screen screen1 = (Screen) obj1;
                                                    final Screen screen2 = (Screen) obj2;
                                                    return screen1
                                                            .getScreenId()
                                                            .compareToIgnoreCase(
                                                                    screen2.getScreenId());
                                                }

                                            });
                                } else {
                                    currentScene.setDefaultStyle(null);
                                }
                            }
                        } else {
                            act.setDefaultStyle(null);
                        }
                    }

                }
            }
        }

        return new ModelAndView(LIST_ACTS_PATH,
                ApplicationConstants.GAME_GEN_INFO, curGameGenInfo);
    }

    /**
     * 
     * This method receives question configuration details from view
     * 
     * @param selectedScreen  
     * @param request  
     * @param session  
     * @param model  
     * 
     * @return ModelAndView  
     */
    @RequestMapping(value = "/submitScreenConfig.htm", method = RequestMethod.POST)
    public final ModelAndView submitScreenConfig(
            @ModelAttribute(SCREEN) final Screen selectedScreen,
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model) {
        GameGeneratorInfo curGameGenInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);
        curGameGenInfo = ManageGameElementConfigHelper
                .addScreenConfigToGameGenInfo(selectedScreen, session,
                        curGameGenInfo);
        return new ModelAndView(LIST_ACTS_PATH,
                ApplicationConstants.GAME_GEN_INFO, curGameGenInfo);
    }

    /**
     * @return the manageGameGeneratorService
     */
    public final ManageGameGeneratorService getManageGameGeneratorService() {
        return manageGameGenServ;
    }

    /**
     * @param manageGameServ
     *            the manageGameGeneratorService to set
     */
    public final void setManageGameGeneratorService(
            final ManageGameGeneratorService manageGameServ) {
        this.manageGameGenServ = manageGameServ;
    }

}
