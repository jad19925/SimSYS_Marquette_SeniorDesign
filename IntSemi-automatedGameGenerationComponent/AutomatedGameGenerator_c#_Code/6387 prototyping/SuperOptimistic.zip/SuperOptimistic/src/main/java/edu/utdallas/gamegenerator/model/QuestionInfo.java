package edu.utdallas.gamegenerator.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * 
 * @author Naveen
 * 
 */

public class QuestionInfo extends Prop {

    private String subjectName;
    private String questionId;
    private String grade;
    private String statement;
    private String noOfImages;
    private List<String> imagePathList;
    private List<String> optionList;
    
    private String option1;
    private String option2;
    private String option3;
    private String option4;
    
    private String noOfOptions;
    private String answer;
    private String awardPts;
    private String negativePts;

    
    /**
     * 
     
     */
    public QuestionInfo() {
        super();
       
    }
    /**
     * 
     * @param questionId1   
     */
    public QuestionInfo(final String questionId1) {
        super();
        this.questionId = questionId1;
    }

    private String penaltyPts;

    /**
     * @return the subjectName
     */
    public final String getSubjectName() {
        return subjectName;
    }

    /**
     * @param subjectName1
     *            the subjectName to set
     */
    @XmlElement
    public final void setSubjectName(final String subjectName1) {
        this.subjectName = subjectName1;
    }

    /**
     * @return the grade
     */
    public final String getGrade() {
        return grade;
    }

    /**
     * @param grade1
     *            the grade to set
     */
    @XmlElement
    public final void setGrade(final String grade1) {
        this.grade = grade1;
    }

    /**
     * @return the statement
     */
    public final String getStatement() {
        return statement;
    }

    /**
     * @param statement1
     *            the statement to set
     */
    @XmlElement
    public final void setStatement(final String statement1) {
        this.statement = statement1;
    }

    /**
     * @return the noOfImages
     */
    public final String getNoOfImages() {
        return noOfImages;
    }

    /**
     * @param noOfImages1
     *            the noOfImages to set
     */
    public final void setNoOfImages(final String noOfImages1) {
        this.noOfImages = noOfImages1;
    }

    /**
     * @return the imagePathList
     */
    public final List<String> getImagePathList() {
        return imagePathList;
    }

    /**
     * @param imagePathList1
     *            the imagePathList to set
     */
    @XmlElement
    public final void setImagePathList(final List<String> imagePathList1) {
        this.imagePathList = imagePathList1;
    }

    /**
     * @return the optionList
     */
    public final List<String> getOptionList() {
        return optionList;
    }

    /**
     * @param optionList1
     *            the optionList to set
     */
    @XmlElement
    public final void setOptionList(final List<String> optionList1) {
        this.optionList = optionList1;
    }

    /**
     * @return the noOfOptions
     */
    public final String getNoOfOptions() {
        return noOfOptions;
    }

    /**
     * @param noOfOptions1
     *            the noOfOptions to set
     */
    public final void setNoOfOptions(final String noOfOptions1) {
        this.noOfOptions = noOfOptions1;
    }

    /**
     * @return the answer
     */
    public final String getAnswer() {
        return answer;
    }

    /**
     * @param answer1
     *            the answer to set
     */
    @XmlElement
    public final void setAnswer(final String answer1) {
        this.answer = answer1;
    }

    /**
     * @return the awardPts
     */
    public final String getAwardPts() {
        return awardPts;
    }

    /**
     * @param awardPts1
     *            the awardPts to set
     */
    @XmlElement
    public final void setAwardPts(final String awardPts1) {
        this.awardPts = awardPts1;
    }

    /**
     * @return the penaltyPts
     */
    public final String getPenaltyPts() {
        return penaltyPts;
    }

    /**
     * @param penaltyPts1
     *            the penaltyPts to set
     */
    @XmlElement
    public final void setPenaltyPts(final String penaltyPts1) {
        this.penaltyPts = penaltyPts1;
    }

    /**
     * @return the questionId
     */
    public final String getQuestionId() {
        return questionId;
    }

    /**
     * @param questionId1
     *            the questionId to set
     */
   
    public final void setQuestionId(final String questionId1) {
        this.questionId = questionId1;
    }

    /**
     * @return the option1
     */
    public final String getOption1() {
        return option1;
    }

    /**
     * @param stroption1 the option1 to set
     */
    public final void setOption1(String stroption1) {
        this.option1 = stroption1;
    }

    /**
     * @return the option2
     */
    public  final String getOption2() {
        return option2;
    }

    /**
     * @param stroption2 the option2 to set
     */
    public final void setOption2(String stroption2) {
        this.option2 = stroption2;
    }

    /**
     * @return the option3
     */
    public  final String getOption3() {
        return option3;
    }

    /**
     * @param stroption3 the option3 to set
     */
    public final void setOption3(String stroption3) {
        this.option3 = stroption3;
    }

    /**
     * @return the option4
     */
    public final String getOption4() {
        return option4;
    }

    /**
     * @param stroption4 the option4 to set
     */
    public final void setOption4(String stroption4) {
        this.option4 = stroption4;
    }

    /**
     * @return the negativePts
     */
    public  final String getNegativePts() {
        return negativePts;
    }

    /**
     * @param strnegativePts the negativePts to set
     */
    public  final void setNegativePts(String strnegativePts) {
        this.negativePts = strnegativePts;
    }

}
