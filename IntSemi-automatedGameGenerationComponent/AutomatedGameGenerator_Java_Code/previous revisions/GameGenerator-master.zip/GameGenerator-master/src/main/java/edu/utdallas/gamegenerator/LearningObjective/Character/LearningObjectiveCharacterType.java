package edu.utdallas.gamegenerator.LearningObjective.Character;

/**
 * User: clocke
 * Date: 2/17/13
 * Time: 3:59 PM
 */
public enum LearningObjectiveCharacterType {
    PLAYER,
    HERO,
    VILLIAN,
    ALT;
}
