package edu.utdallas.gamegenerator.LearningObjective.Screen;

/**
 * User: clocke
 * Date: 2/17/13
 * Time: 4:44 PM
 */
public class LearningObjectiveSuccess extends LearningObjectiveScreen {
    @Override
    public ScreenType getType() {
        return ScreenType.SUCCESS;
    }
}
