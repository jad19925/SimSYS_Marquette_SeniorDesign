package edu.utdallas.gamegenerator.Shared;

/**
 * User: clocke
 * Date: 3/13/13
 * Time: 9:05 PM
 */
public enum ButtonLocationType {
    BACK,
    NEXT,
    CHALLENGE_1,
    CHALLENGE_2,
    CHALLENGE_3,
    CHALLENGE_4;
}
