package edu.utdallas.gamegenerator;

import edu.utdallas.gamegenerator.Challenge.Challenge;
import edu.utdallas.gamegenerator.Characters.Characters;
import edu.utdallas.gamegenerator.LearningObjective.LearningObjective;
import edu.utdallas.gamegenerator.LearningObjective.LessonAct;
import edu.utdallas.gamegenerator.Lesson.Lesson;
import edu.utdallas.gamegenerator.Locale.Locale;
import edu.utdallas.gamegenerator.Structure.Game;
import edu.utdallas.gamegenerator.Structure.Structure;
import edu.utdallas.gamegenerator.Subject.Subject;
import edu.utdallas.gamegenerator.Theme.Theme;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static edu.utdallas.gamegenerator.Layers.*;

/**
 * User: clocke
 * Date: 4/15/13
 * Time: 8:55 PM
 */
public class GameGenerator {
    public static void main(String[] args) {
        if(args.length == 6) {
            Map<String, String> xmlFiles = new HashMap<String, String>();
            xmlFiles.put(CHARACTERS, args[0]);
            xmlFiles.put(LESSONS, args[1]);
            xmlFiles.put(CHALLENGES, args[2]);
            xmlFiles.put(LOCALE, args[3]);
            xmlFiles.put(SUBJECT, args[4]);
            xmlFiles.put(THEME, args[5]);

            GameGenerator gameGenerator = new GameGenerator();

            String exportFilename = "C:\\Users\\Terminus Est\\Dropbox\\SimSYS Development Platform\\IntSemi-automatedGameGenerationComponent\\Samples\\Sample Game XMLs\\Game.xml";

            try {
                Layers layers = gameGenerator.loadXmlComponents(xmlFiles);
                Game game = gameGenerator.buildGame(layers);
                gameGenerator.exportGame(game, exportFilename);
            } catch (JAXBException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Please enter the file names of the layers:\n");
            System.out.println(
                    "\tie: GameGenerator characters.xml lesson1.xml,lesson2xml challenge1.xml,challenge2.xml locale.xml subject.xml, theme.xml\n\n");
        }
    }

    /**
     * Exports the Game object to xml
     * @param game the Game object containing the game
     * @throws JAXBException
     */
    public void exportGame(Game game, String exportFilename) throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(Game.class);
        Marshaller marshaller = jaxbContext.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        File file = new File(exportFilename);
        marshaller.marshal(game, file);
    }

    /**
     * Builds the Game object from the layers
     * @param layers a Layer object containing all game layers
     * @return a Game object built from the layers
     */
    public Game buildGame(Layers layers) {
        return layers.getStructure().createGame();
    }

    /**
     * Loads the xml for each layer from a map of filenames
     * @param xmlFiles a map of layer constants to filenames
     * @return Layers object containing the loaded xml
     * @throws JAXBException
     */
    public Layers loadXmlComponents(Map<String, String> xmlFiles) throws JAXBException {
        Layers layers = new Layers();

        JAXBContext jaxbContext = null;
        File file = null;
        Unmarshaller unmarshaller = null;

        jaxbContext = JAXBContext.newInstance(Characters.class);
        file = new File(xmlFiles.get(CHARACTERS));
        unmarshaller = jaxbContext.createUnmarshaller();
        layers.setCharacters((Characters) unmarshaller.unmarshal(file));

        jaxbContext = JAXBContext.newInstance(Subject.class);
        file = new File(xmlFiles.get(SUBJECT));
        unmarshaller = jaxbContext.createUnmarshaller();
        layers.setSubject((Subject) unmarshaller.unmarshal(file));

        jaxbContext = JAXBContext.newInstance(Theme.class);
        file = new File(xmlFiles.get(THEME));
        unmarshaller = jaxbContext.createUnmarshaller();
        layers.setTheme((Theme) unmarshaller.unmarshal(file));

        jaxbContext = JAXBContext.newInstance(Locale.class);
        file = new File(xmlFiles.get(LOCALE));
        unmarshaller = jaxbContext.createUnmarshaller();
        layers.setLocale((Locale) unmarshaller.unmarshal(file));

        String[] lessonFiles = xmlFiles.get(LESSONS).split(",");

        jaxbContext = JAXBContext.newInstance(Lesson.class);
        unmarshaller = jaxbContext.createUnmarshaller();
        List<Lesson> lessons = new ArrayList<Lesson>();
        for(int i = 0; i < lessonFiles.length; i++) {
            file = new File(lessonFiles[i]);
            Lesson lesson = ((Lesson) unmarshaller.unmarshal(file));
            lessons.add(lesson);
        }

        String[] challengeFiles = xmlFiles.get(CHALLENGES).split(",");

        jaxbContext = JAXBContext.newInstance(Challenge.class);
        unmarshaller = jaxbContext.createUnmarshaller();
        List<Challenge> challenges = new ArrayList<Challenge>();
        for(int i = 0; i < challengeFiles.length; i++) {
            file = new File(challengeFiles[i]);
            Challenge challenge = ((Challenge) unmarshaller.unmarshal(file));
            challenges.add(challenge);
        }

        List<LearningObjective> learningObjectives = new ArrayList<LearningObjective>();
        for(int i = 0; i < lessons.size(); i++) {
            LearningObjective learningObjective = new LearningObjective();
            List<LessonAct> lessonActs = new ArrayList<LessonAct>();
            LessonAct lessonAct = new LessonAct();
            lessonAct.setLessonScreens(lessons.get(i).getLessonScreens());
            lessonAct.setLessonChallenges(challenges.get(i).getLessonChallenges());
            lessonActs.add(lessonAct);
            learningObjective.setLessonActs(lessonActs);
            learningObjectives.add(learningObjective);
        }

        layers.setLearningObjectives(learningObjectives);

        layers.setStructure(new Structure());
        wireUpLayers(layers);

        return layers;
    }

    /**
     * Injects dependent layers into each other
     * @param layers a Layers object with all layers populated
     */
    private void wireUpLayers(Layers layers) {
        layers.getLocale().setTheme(layers.getTheme());
        layers.getLocale().setLearningObjectives(layers.getLearningObjectives());
        layers.getLocale().setCharacters(layers.getCharacters());
        layers.getTheme().setSubject(layers.getSubject());
        layers.getTheme().setCharacters(layers.getCharacters());
        layers.getStructure().setLocale(layers.getLocale());
        layers.getStructure().setTheme(layers.getTheme());
    }


}
