/**
 * This file contains the Control class for Act Model. This class is to be updated and used as the interaction with Act becomes complex
 */
package gamePlayEngine.model.act;

public class ActControl {
}
