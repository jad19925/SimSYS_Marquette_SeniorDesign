/*
 * Derived Model class for Audio deriving from GameElement
 */
package gamePlayEngine.model.audio;

import gamePlayEngine.model.gameElement.GameElement;

public class Audio extends GameElement {

}
