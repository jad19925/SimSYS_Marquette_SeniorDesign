/*
 * Quiz class extends Challenge base class
 */
package gamePlayEngine.model.challenge;

public class Quiz extends Challenge {

}
