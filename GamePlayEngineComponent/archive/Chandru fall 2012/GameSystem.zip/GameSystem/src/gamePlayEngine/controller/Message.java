package gamePlayEngine.controller;

public enum Message {
	Start,
	Play,
	End
}
