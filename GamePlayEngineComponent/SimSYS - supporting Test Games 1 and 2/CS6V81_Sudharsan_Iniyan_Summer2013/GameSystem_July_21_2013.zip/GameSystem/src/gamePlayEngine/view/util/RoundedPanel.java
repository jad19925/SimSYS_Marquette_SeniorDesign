package gamePlayEngine.view.util;

import gamePlayEngine.model.gameElement.ReadBehavior;
import gamePlayEngine.model.gameElement.graphic.Prop;
import gamePlayEngine.model.gameElement.player.reward.Reward;
import gamePlayEngine.model.gamemodel.GameModel;
import gamePlayEngine.util.Util;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.font.LineBreakMeasurer;
import java.awt.font.TextAttribute;
import java.awt.font.TextLayout;
import java.text.AttributedCharacterIterator;
import java.text.AttributedString;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

public class RoundedPanel extends JPanel{
	 /** Stroke size. it is recommended to set it to 1 for better view */
    protected int strokeSize = 1;
    /** Color of shadow */
    protected Color shadowColor = Color.black;
    /** Sets if it drops shadow */
    protected boolean shady = true;
    /** Sets if it has an High Quality view */
    protected boolean highQuality = true;
    /** Double values for Horizontal and Vertical radius of corner arcs */
    protected Dimension arcs = new Dimension(20, 20);
    /** Distance between shadow border and opaque panel border */
    protected int shadowGap = 5;
    /** The offset of shadow.  */
    protected int shadowOffset = 4;
    /** The transparency value of shadow. ( 0 - 255) */
    protected int shadowAlpha = 150;
    
    private String stringTextToDisplay;
    private Prop prop = null;
    
    public RoundedPanel(Prop prop) {
        super();		
        String toDisplay = "";                
        toDisplay = prop.getText();
        
        try{
        	ReadBehavior readBehavior = new ReadBehavior(prop.getBehavior());
        	if (readBehavior.getModel().trim().equals("Reward")) {
    			if (readBehavior.getAction().trim().equals("GetPoints")) {
    				Reward reward = GameModel.getGameModelObject().getCharacter()
    						.getReward();
    				System.out.println("Points are" + reward.getPoints());
    				toDisplay = toDisplay+ " " + reward.getPoints();
    			}
    		}
        }catch(Exception e){
        	
        }       
        		
		System.out.println("Text from prop is : "+toDisplay);		
		this.stringTextToDisplay = toDisplay;
		this.prop = prop;		
        setOpaque(false);        
    }
    
    
    
    protected void paintComponent(Graphics g) {
        //super.paintComponent(g);
        int width = 200;
        int height = 100;
        int shadowGap = this.shadowGap;
        Color shadowColorA = new Color(shadowColor.getRed(), 
        shadowColor.getGreen(), shadowColor.getBlue(), shadowAlpha);
        //g.setColor(Color.BLACK);
          
        Graphics2D graphics = (Graphics2D) g;
        
        //Sets antialiasing if HQ.
        if (highQuality) {
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
			RenderingHints.VALUE_ANTIALIAS_ON);
        }

        //Draws shadow borders if any.
        if (shady) {
            /*graphics.setColor(shadowColorA);
            graphics.fillRoundRect(
                    shadowOffset,// X position
                    shadowOffset,// Y position
                    width - strokeSize - shadowOffset, // width
                    height - strokeSize - shadowOffset, // height
                    arcs.width, arcs.height);// arc Dimension*/
        } else {
            shadowGap = 1;
        }

        //Draws the rounded opaque panel with borders.
        //graphics.setColor(getBackground());
        /*graphics.fillRoundRect(0, 0, width - shadowGap, 
		height - shadowGap, arcs.width, arcs.height);*/
        //graphics.setColor(getForeground());
        //graphics.setStroke(new BasicStroke(strokeSize));
        
        JPanel jPanel = Util.panelPosition(prop.getLocation(), false, prop);
        graphics.setStroke(new BasicStroke(10));
        graphics.setColor(Color.BLACK);
        System.out.println("Hello!!!!!456");
        jPanel.setPreferredSize((Util.panelDimension(prop.getSize())));
        System.out.println("Hello!!!!!123");
        Dimension dim = Util.panelDimension(prop.getSize());
        graphics.drawRoundRect(3, 3, (int)dim.getWidth()-5, 
		(int)dim.getHeight() -5, arcs.width, arcs.height);        

        //Sets strokes to default, is better.
        graphics.setStroke(new BasicStroke()); 
        
        graphics.setColor(Util.StringToColor(prop.getColor().toString().trim()));         
        graphics.fillRoundRect(3, 3, (int)dim.getWidth()-5, 
        		(int)dim.getHeight() -5, arcs.width, arcs.height);     

        graphics.setFont(new Font("Serif",Font.PLAIN,Integer.parseInt(prop.getTextSize())));
        graphics.setColor(Color.BLACK);
        drawStringRect(graphics,3,3,(int)dim.getWidth()-5,(int)dim.getHeight() -5,1.5f,stringTextToDisplay);
       
    }
    
    private void drawStringRect(Graphics2D graphics, int x1, int y1, int x2, int y2, 
            float interline, String txt) {
            AttributedString as = new AttributedString(txt);
            as.addAttribute(TextAttribute.FOREGROUND, graphics.getPaint());
            as.addAttribute(TextAttribute.FONT, graphics.getFont());
            System.out.println("Font name is " + graphics.getFont().getFontName());
            AttributedCharacterIterator aci = as.getIterator();
            FontRenderContext frc = new FontRenderContext(null, true, false);
            LineBreakMeasurer lbm = new LineBreakMeasurer(aci, frc);
            float width = x2 - x1;

            while (lbm.getPosition() < txt.length()) {
                TextLayout tl = lbm.nextLayout(width);
                y1 += tl.getAscent();
                tl.draw(graphics, x1, y1);
                y1 += tl.getDescent() + tl.getLeading() + (interline - 1.0f) * tl.getAscent();
                if (y1 > y2) {
                    break;
                }
            }
        }
}
