/**
 * Boundary class for Player. This can be used if interaction with Player becomes complex.
 */
package gamePlayEngine.model.gameElement.player;

public class PlayerBoundary {

}
