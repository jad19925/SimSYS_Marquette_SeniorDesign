/*
 * Challenge class - used as a base class for other derived classes like Quiz
 */
package gamePlayEngine.model.challenge;

import java.util.Observable;

public class Challenge extends Observable {

}
