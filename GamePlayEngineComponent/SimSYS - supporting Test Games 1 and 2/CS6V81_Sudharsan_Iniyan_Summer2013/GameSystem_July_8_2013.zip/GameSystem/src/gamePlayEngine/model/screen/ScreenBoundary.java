/**
 * This file contains the Boundary class for Screen Model. It is to be used if the current interaction with Screen model becomes complex
 */
package gamePlayEngine.model.screen;

public class ScreenBoundary {

}
