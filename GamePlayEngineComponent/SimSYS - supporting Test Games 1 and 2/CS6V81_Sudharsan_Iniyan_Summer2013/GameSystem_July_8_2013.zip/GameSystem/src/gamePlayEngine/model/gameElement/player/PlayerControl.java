/**
 * PlayerControl class is to be used if the interaction with Player model becomes complex. 
 */
package gamePlayEngine.model.gameElement.player;

public class PlayerControl {
}
