/**
 * NonPlayer class derives from GameCharacter
 * The implementation of NonPlayer is to be added for complex games.
 */
package gamePlayEngine.model.gameElement.character;


public class NonPlayer extends GameCharacter {
}
