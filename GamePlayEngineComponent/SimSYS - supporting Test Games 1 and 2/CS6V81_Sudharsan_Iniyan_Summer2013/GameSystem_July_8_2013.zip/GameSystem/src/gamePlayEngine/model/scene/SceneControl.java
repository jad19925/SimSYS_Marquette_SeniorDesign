 /**
 * This file contains the Control class for Scene Model. This class is to be updated and used as the interaction with Scene becomes complex
 */
package gamePlayEngine.model.scene;

public class SceneControl {
}
