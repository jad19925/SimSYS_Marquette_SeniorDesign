/**
 * This file contains the Boundary class for Scene Model. It is to be used if the current interaction with Scene model becomes complex
 */
package gamePlayEngine.model.scene;

public class SceneBoundary {
	
}
