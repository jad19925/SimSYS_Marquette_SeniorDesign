package gamePlayEngine.model.gameElement;

import javax.xml.bind.annotation.XmlRootElement;

import gamePlayEngine.model.gameElement.graphic.Prop;

@XmlRootElement(name="Information-Box")
public class InformationBox extends Prop{

}
