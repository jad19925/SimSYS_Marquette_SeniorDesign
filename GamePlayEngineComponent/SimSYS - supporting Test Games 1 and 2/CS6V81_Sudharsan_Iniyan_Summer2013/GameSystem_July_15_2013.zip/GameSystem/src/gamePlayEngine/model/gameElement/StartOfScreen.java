package gamePlayEngine.model.gameElement;

public class StartOfScreen extends ScreenDescription{

	
}
