package gamePlayEngine.model.gameElement.graphic;

public enum Time {
	QUICK
}
