package gamePlayEngine.util;

import java.awt.AlphaComposite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.JButton;

import org.jdesktop.animation.timing.Animator;
import org.jdesktop.animation.timing.Animator.Direction;
import org.jdesktop.animation.timing.Animator.RepeatBehavior;
import org.jdesktop.animation.timing.TimingTarget;

@SuppressWarnings("serial")
public class FadingButton extends JButton implements ActionListener, TimingTarget {

float alpha = 1.0f;                 // current opacity of button
Animator animator;                  // for later start/stop actions
int animationDuration = 2000;   // each cycle will take 2 seconds
BufferedImage buttonImage = null;
long animationStartTime;

/** Creates a new instance of FadingButtonTF 
 * @return */
public FadingButton(String label) {
super(label);
this.setText("Play To Win");
setOpaque(false);
animator = new Animator(animationDuration/2, Animator.INFINITE, 
        RepeatBehavior.REVERSE, this);
//animator.setStartFraction(0.0f);
//animator.setStartDirection(Direction.FORWARD);
long currentTime = System.nanoTime() / 1000000;
long totalTime = currentTime - animationStartTime;
if (totalTime > animationDuration) {
animationStartTime = currentTime;
}
float fraction = (float)totalTime / animationDuration;
fraction = Math.min(1.0f, fraction);
// This calculation will cause alpha to go from 1 to 0 
// and back to 1 as the fraction goes from 0 to 1
alpha = Math.abs(1 - (2 * fraction));
repaint();
animator.start();
addActionListener(this);
animator.stop();
//setOpaque(true);
//alpha = 1.0f;
}

public void paint(Graphics g) {
// Create an image for the button graphics if necessary
if (buttonImage == null || buttonImage.getWidth() != getWidth() ||
        buttonImage.getHeight() != getHeight()) {
    buttonImage = getGraphicsConfiguration().
            createCompatibleImage(getWidth(), getHeight());
}
Graphics gButton = buttonImage.getGraphics();
gButton.setClip(g.getClip());

//  Have the superclass render the button for us
super.paint(gButton);

// Make the graphics object sent to this paint() method translucent
Graphics2D g2d  = (Graphics2D)g;
AlphaComposite newComposite = 
AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha);
g2d.setComposite(newComposite);

// Copy the button's image to the destination graphics, translucently
g2d.drawImage(buttonImage, 0, 0, null);
}

/**
* This method receives click events, which start and stop the animation
*/
public void actionPerformed(ActionEvent ae) {
if (!animator.isRunning()) {
    //this.setText("Stop Animation");
    //alpha =1.0f;
    //animator.start();    
} else {
    /*animator.stop();
    this.setText("Start Animation");
    // reset alpha to opaque
    alpha = 1.0f;*/
}
}
// Ununsed MouseListener implementations
public void begin() {
	//this.setText("Stop Animation");
    alpha =0.0f;    
}
public void end() {}
public void repeat() {}

/**
* TimingTarget implementation: this method sets the alpha of our button
* to be equal to the current elapsed fraction of the animation
*/
public void timingEvent(float fraction) {
alpha = fraction;
// redisplay our cbutton
repaint();
}

}