/*
 * SoundEffect model class extending base Audio class
 */
package gamePlayEngine.model.audio;

public class SoundEffect extends Audio {

}
