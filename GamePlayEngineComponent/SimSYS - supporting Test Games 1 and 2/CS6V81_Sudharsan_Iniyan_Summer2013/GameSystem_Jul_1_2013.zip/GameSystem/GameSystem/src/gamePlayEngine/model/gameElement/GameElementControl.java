 /**
 * This file contains the Control class for GameElement Model. This class is to be updated and used as the interaction with GameElement becomes complex
 */
package gamePlayEngine.model.gameElement;

public class GameElementControl {

}
