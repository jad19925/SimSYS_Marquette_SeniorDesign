/*
 * Derived class from GameElement presenting Music Model.
 */
package gamePlayEngine.model.audio;

public class Music extends Audio {

}
