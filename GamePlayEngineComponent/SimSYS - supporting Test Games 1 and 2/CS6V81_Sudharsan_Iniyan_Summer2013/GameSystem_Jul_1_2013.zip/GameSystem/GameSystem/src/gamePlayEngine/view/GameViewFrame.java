/**
 * Dummy View class implementation - Will be replaced by actual view classes 
 */
package gamePlayEngine.view;

import gamePlayEngine.controller.GameController;
import gamePlayEngine.controller.GameState;
import gamePlayEngine.controller.Message;
import gamePlayEngine.controller.MessageType;
import gamePlayEngine.model.gameElement.graphic.Backdrop;
import gamePlayEngine.model.gameElement.graphic.Prop;
import gamePlayEngine.model.gameElement.player.reward.Reward;
import gamePlayEngine.util.CustomDialog;
import gamePlayEngine.util.FadingButton;
import gamePlayEngine.util.Util;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import java.lang.reflect.Field;

public class GameViewFrame extends javax.swing.JFrame {

	private GameController controller;
	JFrame jFrame;
	JPanel jPanelScene;
	JLayeredPane layeredPane;
	
	public GameViewFrame() {
		System.out.println("view has been initialized");
	}

	public GameController getController() {
		return controller;
	}

	public void setController(GameController controller) {
		this.controller = controller;
	}

	public void viewStartAct() {
		jFrame = new JFrame();
		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jFrame.setLocationRelativeTo(null);
		jFrame.pack();
		jFrame.setVisible(true);
		jFrame.setSize(1000, 800);
		jFrame.setLayout(new BorderLayout());
		
		//Dispaly frame in center of the screen
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		jFrame.setLocation(dim.width/2-jFrame.getSize().width/2, dim.height/2-jFrame.getSize().height/2);
		layeredPane = new JLayeredPane();
		jFrame.add(layeredPane,BorderLayout.CENTER);
		layeredPane.setBounds(0, 0, 1000, 800);
	}

	public void addinformationBox(Prop currentProp){
		jPanelScene = Util.panelPosition(currentProp.getLocation());
		layeredPane.add(jPanelScene,new Integer(0),0);
		CustomDialog myDialog = new CustomDialog(jPanelScene, true, currentProp);		
	}
	
	public JFrame createNewFrame(String name)
	{
		JFrame jFrame = new JFrame(name);
		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//3. Create components and put them in the frame.
		//...create emptyLabel...
		jFrame.setSize(1000, 800);
		jFrame.setLayout(new BorderLayout());
		

		//4. Size the frame.
		jFrame.pack();

		//5. Show it.
		jFrame.setVisible(false);
		return jFrame;
		
	}
	
	public void addButton(final GameState gameState) {
		final Prop prop = (Prop) gameState.getGameElement();
		final Timer timer = new Timer(100, null);
		float alpha = 1f;
		
		JButton btn = new JButton();
		
		System.out.println(prop.getColor());
		
		if(prop.getColor() == null)
			btn.setBackground(new Color(255,255,255));
		else
			btn.setBackground(Util.StringToColor(prop.getColor().toString()));
						
		
		
		btn.setText(prop.getText());
		btn.setFont(new Font(prop.getFont().toString(),Font.PLAIN,Integer.parseInt(prop.getTextSize())));
		btn.setPreferredSize(Util.panelDimension(prop.getSize()));
				
        btn.setOpaque(true);        
       timer.setInitialDelay(1000);
       //timer.addActionListener(this);
       timer.start();
      /* btn.addActionListener(new ActionListener(){      	   
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					float alpha = 1f;
					final float DELTA = -0.1f;
	    	        alpha += DELTA;
	    	        if (alpha < 0) {
	    	            alpha = 1;
	    	            timer.restart();
	    	        }					
				}
       });*/
		
		/**
		 *Create panel with Act+Scene+Screen name. and populate with game elements.
		  Once we create all the panels, link the panels with user interaction. 
		 */
		
		
		// Retrieve Actname, Scenename, Screen name.
		
		String panelName = gameState.getAct().getActGameElement().getActId() + gameState.getScene().getIdentifier().getId() + gameState.getGameElement();
		
		createNewFrame(panelName);
		
		
		System.out.println("Iniyan...." + gameState.getAct().getActGameElement().getActId());
		System.out.println("Iniyan...." + gameState.getGameElement().getGameElementIdentifier().getId() + gameState.getScene().getIdentifier().getId());
		
		jPanelScene = Util.panelPosition(prop.getLocation());
		layeredPane.add(jPanelScene,new Integer(0),0);		
		jPanelScene.add(btn);
		
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String next = prop.getNext();
				System.out.println("Next to display is" + prop.getNext());
				
				//Start the nextscreen
				
				if(next.contains("screen"))
				{
					GameController.startNextScreen(next, gameState);
				}
				
			}
		});
		//new FadingButton("Hello!!!!");
	}
}