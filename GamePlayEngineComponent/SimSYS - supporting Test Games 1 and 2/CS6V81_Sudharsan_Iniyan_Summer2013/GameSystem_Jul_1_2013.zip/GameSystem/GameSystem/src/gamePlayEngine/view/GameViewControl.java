package gamePlayEngine.view;

public class GameViewControl {
	private GameView gameView;
	
	public GameViewControl(GameView gameView){
		this.gameView=gameView;
		//System.out.println("view has been initialized");
	}

}
