package gamePlayEngine.util;

import gamePlayEngine.model.gameElement.graphic.Prop;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class CustomDialog extends JDialog implements ActionListener {
    private JPanel myPanel = null;
    private JButton okButton = null;
    private JButton cancelButton = null;
    private boolean answer = false;
    public boolean getAnswer() { return answer; }

    public CustomDialog(JPanel panel, boolean modal, Prop currentProp) {
        //super(frame, modal);
        myPanel = new JPanel();
        getContentPane().add(myPanel);
        myPanel.add(new JLabel(currentProp.getText()));
        okButton = new JButton("OK");
        okButton.addActionListener(this);
        myPanel.add(okButton);        
        pack();
        if(currentProp.getColor() == null)
        	myPanel.setBackground(new Color(255,255,255));
		else
			myPanel.setBackground(Util.StringToColor(currentProp.getColor().toString()));
        
        setLocationRelativeTo(panel);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if(okButton == e.getSource()) {
            System.err.println("User chose OK.");
            answer = true;
            setVisible(false);
        }        
    }
    
}
