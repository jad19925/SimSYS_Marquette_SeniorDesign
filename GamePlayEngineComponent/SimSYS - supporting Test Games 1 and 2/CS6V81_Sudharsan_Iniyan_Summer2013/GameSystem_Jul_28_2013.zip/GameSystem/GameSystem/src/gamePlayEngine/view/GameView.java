package gamePlayEngine.view;

import gamePlayEngine.controller.GameController;
import gamePlayEngine.controller.GameState;
import gamePlayEngine.controller.Message;
import gamePlayEngine.model.act.Act;
import gamePlayEngine.model.gameElement.GameElement;
import gamePlayEngine.model.gameElement.graphic.Backdrop;
import gamePlayEngine.model.gameElement.graphic.Event;
import gamePlayEngine.model.gameElement.graphic.Identifier;
import gamePlayEngine.model.gameElement.graphic.Prop;
import gamePlayEngine.model.gameElement.graphic.Time;
import gamePlayEngine.model.gameElement.graphic.Type;
import gamePlayEngine.model.gameElement.player.reward.Reward;
import gamePlayEngine.model.gamemodel.GameModel;
import gamePlayEngine.model.scene.Scene;
import gamePlayEngine.model.screen.Screen;
import gamePlayEngine.util.GameElementTimer;

import javax.swing.*;
import javax.xml.bind.annotation.XmlRootElement;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class GameView implements Observer {
	int count;
	GameViewFrame gameViewFrame;
	private String displayInfo;
	public static final String Button1 = "Button1";
	public static final String Button2 = "Button2";
	public static final String Image = "Image";
	public static final String png = "png";
	public static final String jpg = "jpg";

	public GameView() {
		gameViewFrame = new GameViewFrame();
	}

	@Override
	public void update(Observable arg0, Object arg1) {
		count++;
		GameState gameState = (GameState) arg1;
		Message msg = gameState.getMessage();

		if (GameModel.class.isInstance(arg0)) {
			if (msg == Message.Start) {
				// Do something for GameModel Start
				// TODO Find why it is called in the second time.
				System.out.println("View: Message GameModelStartComplete sent");
				gameState.setMessage(Message.StartComplete);
				GameController.viewListener(arg0, gameState);

			}
			if (msg == Message.Play) {
				// Do something for GameModel Play
				System.out.println("View: Message GameModelPlayComplete sent");
				gameViewFrame.viewStartAct();
				gameState.setMessage(Message.PlayComplete);
				GameController.viewListener(arg0, gameState);
			}
		}

		else if (Act.class.isInstance(arg0)) {
			if (msg == Message.Start) {
				// Do something for Act Start.

				System.out.println("View: Message ActStartComplete sent");
				gameState.setMessage(Message.StartComplete);
				GameController.viewListener(arg0, gameState);

			}
			if (msg == Message.Play) {
				// Do something for Act Play.
				System.out.println("View: Message ActPlayComplete sent");
				gameState.setMessage(Message.PlayComplete);
				GameController.viewListener(arg0, gameState);

			}
			if (msg == Message.End) {
				// Do something for Act Play.
				System.out.println("View: Message ActEndComplete sent");
				gameState.setMessage(Message.EndComplete);
				GameController.viewListener(arg0, gameState);

			}
		}

		else if (Scene.class.isInstance(arg0)) {
			if (msg == Message.Start) {
				System.out.println("View: Message SceneStartComplete sent");
				gameState.setMessage(Message.StartComplete);
				GameController.viewListener(arg0, gameState);
			} else if (msg == Message.Play) {
				System.out.println("View: Message ScenePlayComplete sent");
				gameState.setMessage(Message.PlayComplete);
				GameController.viewListener(arg0, gameState);
			} else if (msg == Message.End) {
				System.out.println("View: Message SceneEndComplete sent");
				gameState.setMessage(Message.EndComplete);
				GameController.viewListener(arg0, gameState);
			}
		}

		else if (Screen.class.isInstance(arg0)) {
			if (msg == Message.Start) {
				System.out.println("View: Message ScreenStartComplete sent");
				gameState.setMessage(Message.StartComplete);
				GameController.viewListener(arg0, gameState);
			} else if (msg == Message.Play) {
				System.out.println("View: Message ScreenPlayComplete sent");
				gameState.setMessage(Message.PlayComplete);
				GameController.viewListener(arg0, gameState);
			} else if (msg == Message.End) {
				System.out.println("View: Message ScreenEndComplete sent");
				gameState.setMessage(Message.EndComplete);
				GameController.viewListener(arg0, gameState);
			}
		}
		if (GameElement.class.isInstance(arg0)) {
			if (msg == Message.Start) {
				System.out
						.println("View: Message GameElementStartComplete sent");
				gameState.setMessage(Message.StartComplete);
				GameController.viewListener(arg0, gameState);
			} else if (msg == Message.Play) {
				System.out
						.println("View: Message GameElementPlayComplete sent");
				gameState.setMessage(Message.PlayComplete);

				if (Prop.class.isInstance(arg0)) {
					Prop currentProp = (Prop) (gameState.getGameElement());
					System.out.println("Current Prop is"
							+ currentProp.getType());
					System.out.println("Yes yes!!! : "
							+ currentProp.getType().getTypeName());

					if (currentProp.getType() != null) {
						if (currentProp.getType().getTypeName().trim()
								.equals(Button1)) {
							gameViewFrame.addButton(gameState);
						}
						if (currentProp.getType().getTypeName()
								.startsWith("InformationBox")) {
							System.out
									.println("Calling method to add information box!!"
											+ currentProp);
							gameViewFrame.addinformationBox(currentProp,
									gameState);
						}
						if (currentProp.getType().getTypeName().trim()
								.equals(Button2)) {
							gameViewFrame.addButton(gameState);
						}
						System.out.println("Prop is name is : "+currentProp.getType().getTypeName().trim() +"+++++++++++++++++++++++++++++++++++++++++++++++++++++");
						if ((currentProp.getType().getTypeName().trim())
								.contains(png)) {
							gameViewFrame.addImage(gameState);
							System.out.println("Displaying Image.");
						}
					}
				}
				GameController.viewListener(arg0, gameState);
			} else if (msg == Message.End) {

				/**
				 * Write code for removing the game elements in the current
				 * screen.
				 * 
				 */
				GameElementTimer gameElementTimer = new GameElementTimer();

				// Read timer from xml and set it.
				// Iterate through the set of events. and do according to the
				// event.

				Prop currentProp = (Prop) gameState.getGameElement();
				Time time = currentProp.getType().getEvents().get(0).getTime();
				System.out.println("Time is" + time.name());

				// Read the value for the time found above.
				List<gamePlayEngine.model.gameConstants.Timer> timers = GameModel
						.getGameModelObject().getGameConstants().getTimers();
				int timerValue = 0;
				for (gamePlayEngine.model.gameConstants.Timer timer : timers) {
					System.out.println("Timer name is..." + timer.getName());
					if (timer.getName() != null) {
						if (timer.getName().trim().equals(time.name())) {
							timerValue = Integer.parseInt(timer.getValue());
							System.out.println("Timer value is" + timerValue);
						}
					}
				}

				final GameState localGameState = gameState;
				final Observable localArg = arg0;
				Timer timer = new Timer(timerValue, new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent arg1) {
						System.out.println("Timer expired");
						GameViewFrame.resetLayeredPane();
						System.out
								.println("View: Message GameElementEndComplete sent");
						localGameState.setMessage(Message.EndComplete);

						GameController.viewListener(localArg, localGameState);

					}
				});
				timer.setRepeats(false);
				timer.start();
			}
		}
	}

}