package gamePlayEngine.view.util;

import gamePlayEngine.controller.GameController;
import gamePlayEngine.controller.GameState;
import gamePlayEngine.model.gameElement.ReadBehavior;
import gamePlayEngine.model.gameElement.graphic.Prop;
import gamePlayEngine.model.gameElement.player.reward.Reward;
import gamePlayEngine.model.gamemodel.GameModel;
import gamePlayEngine.util.Util;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.JButton;
import javax.swing.border.LineBorder;

import org.jdesktop.animation.timing.Animator;
import org.jdesktop.animation.timing.Animator.Direction;
import org.jdesktop.animation.timing.TimingTarget;
import org.jdesktop.animation.timing.Animator.RepeatBehavior;

public class TimedButton extends JButton implements ActionListener,TimingTarget{

	float alpha = 1.0f;
	Animator animator;
	int animationDuration = 2000;
	BufferedImage buttonImage = null;
	private GameState gameState;
	@SuppressWarnings("rawtypes")
	private Prop prop;
	
	public TimedButton(String label){
		super(label);
		setOpaque(false);
        animator = new Animator(animationDuration/2,1, 
                RepeatBehavior.REVERSE, this);
        animator.setStartFraction(1.0f);
        animator.setStartDirection(Direction.BACKWARD);
        addActionListener(this);
		//((Prop) gameState.getGameElement()).getText()
		/*this.gameState = gameState;
		this.prop = (Prop) gameState.getGameElement();		
		this.setText(this.prop.getText());
		System.out.println(this.getText());*/
		//this.setForeground(Color.YELLOW);
		//this.setOpaque(false);
		//this.setBackground(Color.YELLOW);
		//setPreferredSize(new Dimension(150,50));
		/*animator = new Animator(2000,1,RepeatBehavior.REVERSE,this);
		animator.setStartFraction(1.0f);
		animator.setStartDirection(Direction.BACKWARD);						
		*/
		/*this.setFont(new Font(this.prop.getFont().toString(), Font.PLAIN, Integer
				.parseInt(this.prop.getTextSize())));
		this.setPreferredSize(Util.panelDimension(this.prop.getSize()));		
		this.setBorder(new LineBorder(Color.BLACK,4));		
		if (this.prop.getColor() == null)
			this.setBackground(new Color(255, 255, 255));
		else{
			this.setBackground(Util.StringToColor(this.prop.getColor().toString()));
			System.out.println("Color is set accordingly!!! " + this.getBackground().toString());
		}*/
		//addActionListener(this);		
	} 
    
    
    public void paint(Graphics g) {
        // Create an image for the button graphics if necessary
        if (buttonImage == null || buttonImage.getWidth() != getWidth() ||
                buttonImage.getHeight() != getHeight()) {
            buttonImage = getGraphicsConfiguration().
                    createCompatibleImage(getWidth(), getHeight());            
        }
        
        System.out.println("In the paint method !!!");
        Graphics gButton = buttonImage.getGraphics();
        gButton.setClip(g.getClip());        
        //  Have the superclass render the button for us
        super.paint(gButton);
        
        // Make the graphics object sent to this paint() method translucent
  Graphics2D g2d  = (Graphics2D)g;
  //g2d.setBackground(Color.YELLOW);
  AlphaComposite newComposite = 
  AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha);
  
  g2d.setComposite(newComposite);
        
        // Copy the button's image to the destination graphics, translucently
        g2d.drawImage(buttonImage, 0, 0, null);        
    }
        
    // Ununsed MouseListener implementations
    public void begin() { }
    public void end() {       	
    	ReadBehavior readBehavior = new ReadBehavior(this.prop.getBehavior());

		// Code if we get the behavior like this.
		// Reward.AddPoints.5000

		if (readBehavior.getModel().trim().equals("Reward")) {
			// 2 Actions.
			// getPoints and AddPoints

			if (readBehavior.getAction().trim().equals("AddPoints")) {
				if (readBehavior.getParameter() != null) {
					int pointsToAdd = Integer.parseInt(readBehavior
							.getParameter().trim());

					// Get the Reward object and add the points.
					Reward reward = GameModel.getGameModelObject()
							.getCharacter().getReward();
					reward.addPoints(pointsToAdd);
					// Set the reward back to the game character.
					GameModel.getGameModelObject().getCharacter()
							.setReward(reward);
					System.out.println("Reward Points are"
							+ reward.getPoints());
				}
			}
			if (readBehavior.getAction().equals("getPoints")) {

			}
		}

		String next = prop.getNext();
		System.out.println("Next to display is" + prop.getNext());

		// Start the nextscreen

		if (next.contains("screen")) {
			GameController.startNextScreen(next, gameState);
		}	

    }
    public void repeat() {}
    
    /**
     * TimingTarget implementation: this method sets the alpha of our button
     * to be equal to the current elapsed fraction of the animation
     */
    public void timingEvent(float fraction) {
        alpha = fraction;
        // redisplay our cbutton
        if(alpha > 0){        	
        	repaint();
        }else{
        	animator.stop();
        }        	        
    }
	@Override
	public void actionPerformed(ActionEvent e) {
						
			animator.start();			
		
		// TODO Auto-generated method stub
		/*	*/
	}
	
	public void paintComponent(Graphics g){
		Graphics2D graphics = (Graphics2D)g;
		AlphaComposite newComposite = AlphaComposite.getInstance(AlphaComposite.SRC_OVER,alpha);
		graphics.setComposite(newComposite);
	}
}
