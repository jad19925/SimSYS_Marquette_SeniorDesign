package gamePlayEngine.model.gameElement.graphic;

public enum Animation {
	FADEIN,
	FADEOUT
}