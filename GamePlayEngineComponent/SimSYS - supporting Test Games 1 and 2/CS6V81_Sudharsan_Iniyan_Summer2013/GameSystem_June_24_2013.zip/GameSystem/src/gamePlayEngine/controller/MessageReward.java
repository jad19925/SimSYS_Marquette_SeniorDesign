package gamePlayEngine.controller;

public enum MessageReward {
    StartReward,
	PlayReward,
	EndReward
}
