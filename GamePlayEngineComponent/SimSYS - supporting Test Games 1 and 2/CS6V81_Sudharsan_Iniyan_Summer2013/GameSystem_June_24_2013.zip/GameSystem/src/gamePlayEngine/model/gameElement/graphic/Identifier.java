package gamePlayEngine.model.gameElement.graphic;

public class Identifier extends Graphic{

	/**
	 * This file contains Identifier implementation which extends Graphic
	 */

		String id;
		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}
	
	
}
