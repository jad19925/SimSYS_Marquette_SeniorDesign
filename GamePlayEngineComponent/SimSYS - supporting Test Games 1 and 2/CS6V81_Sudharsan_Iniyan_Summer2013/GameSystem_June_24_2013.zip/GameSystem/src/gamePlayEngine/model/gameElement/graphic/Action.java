package gamePlayEngine.model.gameElement.graphic;

public enum Action {
	HIDE,
	SHOW,
	ENDGAME
}

