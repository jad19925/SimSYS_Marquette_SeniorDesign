package gamePlayEngine.model.gameElement;

public class Interactions extends ScreenDescription{

}
