 /**
 * This file contains the Control class for Screen Model. This class is to be updated and used as the interaction with Screen becomes complex
 */
package gamePlayEngine.model.screen;

public class ScreenControl {

}
