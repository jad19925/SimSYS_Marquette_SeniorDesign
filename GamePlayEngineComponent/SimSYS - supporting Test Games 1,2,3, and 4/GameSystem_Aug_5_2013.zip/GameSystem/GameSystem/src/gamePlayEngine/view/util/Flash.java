package gamePlayEngine.view.util;

import gamePlayEngine.view.util.RoundedButton;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.Queue;

import javax.swing.JButton;
import javax.swing.JComponent;

public class Flash implements ActionListener{

	private final float N = 32;
    private JComponent component;
    private final Queue<Color> clut = new LinkedList<Color>();
    private final JButton btn;
   

    public Flash(JButton btn) {
		// TODO Auto-generated constructor stub
    	this.btn = btn;
        for (int i = 0; i < N; i++) {
            clut.add(Color.getHSBColor(1, 1 - (i / N), 1));
        }
        for (int i = 0; i < N; i++) {
            clut.add(Color.getHSBColor(1, i / N, 1));
        }
	}

	public void actionPerformed(ActionEvent e) {
        btn.setBackground(clut.peek());
        clut.add(clut.remove());
    }
}
