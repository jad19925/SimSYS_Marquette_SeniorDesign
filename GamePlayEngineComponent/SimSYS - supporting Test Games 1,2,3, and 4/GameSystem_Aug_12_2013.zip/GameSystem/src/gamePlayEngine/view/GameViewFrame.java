/**
 * Dummy View class implementation - Will be replaced by actual view classes 
 */
package gamePlayEngine.view;

import gamePlayEngine.controller.GameController;
import gamePlayEngine.controller.GameState;
import gamePlayEngine.controller.Message;
import gamePlayEngine.model.gameElement.graphic.If;
import gamePlayEngine.model.gameElement.graphic.Location;
import gamePlayEngine.model.gameElement.graphic.Prop;
import gamePlayEngine.model.gameElement.player.Profile;
import gamePlayEngine.model.gameElement.player.reward.Reward;
import gamePlayEngine.model.gamemodel.GameModel;
import gamePlayEngine.util.Util;
import gamePlayEngine.view.util.ImagePanel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.List;
import java.util.Observable;
import java.util.Timer;
import java.util.TimerTask;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.LineBorder;

public class GameViewFrame extends javax.swing.JFrame {

	private GameController controller;
	JFrame jFrame;
	JPanel jPanelScene;
	private static JLayeredPane layeredPane;
	private BufferedImage myPicture;

	public GameViewFrame() {
		System.out.println("view has been initialized");
	}

	public GameController getController() {
		return controller;
	}

	public void setController(GameController controller) {
		this.controller = controller;
	}

	public void viewStartAct() {

		jFrame = new JFrame("Background Example");

		// jFrame.getContentPane().add(jxImagePanel,0);

		// JLabel picLabel = new JLabel(new ImageIcon(myPicture));
		JLabel picLabel = new JLabel();

		picLabel.setSize(this.getWidth(), this.getHeight());
		picLabel.setLayout(new FlowLayout());

		// picLabel.setSize(1000, 800);
		// jFrame.getContentPane().add(picLabel, 0);

		// jFrame.getContentPane().setBackground(new Color(0, 255, 255));
		jFrame.setLocationRelativeTo(null);
		jFrame.pack();
		jFrame.setVisible(true);
		jFrame.setSize(1000, 800);
		jFrame.setLayout(new BorderLayout());

		// Display frame in center of the screen
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		jFrame.setLocation(dim.width / 2 - jFrame.getSize().width / 2,
				dim.height / 2 - jFrame.getSize().height / 2);
		layeredPane = new JLayeredPane();
		jFrame.add(layeredPane, BorderLayout.CENTER);
		layeredPane.setBounds(0, 0, 1000, 800);
		//setBackgroundImage("BlueSky.png");
	}

	public void setBackgroundImage(String imageName) {
		// TODO Read image name from the backdrop and check whether it is
		// present in resources folder.
		/*
		 * try { myPicture =
		 * ImageIO.read((this.getClass().getResource("./Resources/BlueSky.png"
		 * ))); } catch (IOException e) { e.printStackTrace(); }
		 * 
		 * JXImagePanel jxImagePanel = new JXImagePanel();
		 * jxImagePanel.setImage(myPicture); jxImagePanel.setBounds(0, 0, 1000,
		 * 800); jxImagePanel.setLayout(null); layeredPane = new JLayeredPane();
		 * layeredPane.add(jxImagePanel, JLayeredPane.DEFAULT_LAYER);
		 * jFrame.add(layeredPane, BorderLayout.CENTER);
		 * layeredPane.setBounds(0, 0, 1000, 800);
		 */
		Image image = null;
		try {
			image = ImageIO.read(getClass().getResource(imageName));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		jFrame.add(new ImagePanel(image));
		jFrame.setSize(800, 600);
		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jFrame.setVisible(true);
	}

	public void displayNext(Prop prop, GameState gameState) {
		if (prop != null) {
			String next = prop.getNext();
			System.out.println("Iniyan ... Next to display is" + prop.getNext());

			// Start the nextscreen
			
			if (next != null) {
				if (next.contains("screen")) {
					//gameState.setMessage(Message.PlayComplete);
					//GameController.viewListener((Observable)prop, gameState);
					//GameController.screenToEnd(gameState);
					//if(!(prop.getType().getTypeName().equals("Button3"))){
							
								GameController.startNextScreen(next, gameState);
							
				}
			} else {
				System.out.println("Need to start sequencing");
			}
			// TODO if next tag is not present do sequencing.
			setVisible(false);
		}
	}

	
	public void addCheckBox(final Prop currentProp, final GameState gameState,char answerValue) {
		jPanelScene = Util.panelPosition(currentProp.getLocation(), false, currentProp);
		JCheckBox checkBox = new JCheckBox(currentProp.getText());
		System.out.println("Answer Value is : "+ answerValue);
		checkBox.setMnemonic(answerValue);
		checkBox.setSelected(false);		
		checkBox.setBackground(Color.yellow);
		jPanelScene.add(checkBox);
		layeredPane.add(jPanelScene,100);	
		
		checkBox.addMouseListener(new MouseListener(){
			JTextArea ta = new JTextArea();
			JScrollPane scrollPane = new JScrollPane();
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub
				jPanelScene = Util.panelPosition(Location.UL, false, currentProp);				
				ta = new JTextArea(currentProp.getHint(),5,15);				
				ta.setLineWrap(true);					
				ta.setWrapStyleWord(true);
				scrollPane = new JScrollPane(ta);
				jPanelScene.add(new JLabel("Hint : "));
				jPanelScene.add(scrollPane);				
				layeredPane.add(jPanelScene);
			}

			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub
				System.out.println("Exitting!!!");
				jPanelScene.remove(scrollPane);
			}

			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
		});
		
		checkBox.addItemListener(new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				String[] params = e.paramString().split(",");
				if(((JCheckBox)e.getSource()).getMnemonic() == 'C'){
				gameState.setIsCorrect(true);
				// Get the Reward object and add the points.
				/*Reward reward = GameModel.getGameModelObject()
						.getCharacter().getReward();
				reward.addPoints(5000);
				// Set the reward back to the game character.
				GameModel.getGameModelObject().getCharacter()
						.setReward(reward);
				System.out.println("Reward Points are"
						+ reward.getPoints());
		    			
				System.out.println(params[params.length - 1]);*/
					
				}                
			}			
		});
	}
		
	
	public void addinformationBox(final Prop currentProp, final GameState gameState) {		
		try {			
			jPanelScene = Util.panelPosition(currentProp.getLocation(), true,
					currentProp);
		} catch (NullPointerException e) {
			jPanelScene = Util.panelPosition(Location.C, true, currentProp);
		}
		layeredPane.add(jPanelScene, 100);
		
		displayNext(currentProp, gameState);
	}

	public JFrame createNewFrame(String name) {
		JFrame jFrame = new JFrame(name);
		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// 3. Create components and put them in the frame.
		// ...create emptyLabel...
		jFrame.setSize(1000, 800);
		jFrame.setLayout(new BorderLayout());

		// 4. Size the frame.
		jFrame.pack();

		// 5. Show it.
		jFrame.setVisible(false);
		return jFrame;

	}

	public static void resetLayeredPane() {
		layeredPane.removeAll();
		layeredPane.revalidate();
		layeredPane.repaint();
	}
		

	public void addImage(final GameState gameState) {

		// TODO Add the Image.
		// When mouse Hover occurs display Profile information.
		final Prop prop = (Prop) gameState.getGameElement();
		try{
			jPanelScene = Util.panelPosition(prop.getLocation(), false, prop);
		}catch(Exception e){
			jPanelScene = Util.panelPosition(Location.C, false, prop);
		}		
		
		try{
			System.out.println(gameState.getScene().getBackdrop()+"&&&&&&&&&&&&&&&&&&&&&&&&");
			setBackgroundImage(gameState.getScene().getBackdrop());
		}catch(NullPointerException ns){
			System.out.println("Yes.. backdrop is null!!!");
		}
				
		
		
		String imageName = ((Prop)gameState.getGameElement()).getType().getTypeName();
		System.out.println("./Resources/"+((Prop)gameState.getGameElement()).getType().getTypeName());
		Image image = null;
		try {
			image = ImageIO.read(getClass().getResource(imageName));
			System.out.println("^^^^^^^^^^^^&&&&&&77777777777777777777777777777777777777");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		ImagePanel ip = new ImagePanel(image);
		ip.setSize(jPanelScene.getSize());
		ip.setBounds(jPanelScene.getX(), jPanelScene.getY(), jPanelScene.getWidth(), jPanelScene.getHeight());
		ip.setOpaque(false);
		layeredPane.add(ip);
		System.out.println("Image done!!!!!!!!!");
		Profile profile = GameModel.getGameModelObject().getCharacter().getProfile();		
		String title = profile.getTitle();
		String teamWork = profile.getTeamwork();
		String communication = profile.getCommunication();
		String demoGraphics = profile.getDemographics();
		final String toDisplay = "Title : "+title+"\r\nTeamWork : "+teamWork+"\r\nCommunication : "+communication+"\r\nDemographics : "+demoGraphics;		
		ip.addMouseListener(new MouseListener(){

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				System.out.println("Profiel Information is : "+toDisplay);
				jPanelScene = Util.panelPosition(Location.UC, false, prop);
				//jPanelScene.setSize(250, 250);
				//JLabel ta = new JLabel(toDisplay);
				JTextArea ta = new JTextArea(toDisplay);
				jPanelScene.add(ta);
				layeredPane.add(jPanelScene);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
		});
		/*System.out.println(profile.getExperienceYears());
		System.out.println(profile.getLeadership());
		System.out.println(profile.getResumePhotoLink());
		System.out.println(profile.getSkills());
		System.out.println(profile.getTeamwork());
		System.out.println("Player demographics is:-" + demoGraphics);*/

	}

	public void addButton(final GameState gameState) {

		// resetLayeredPane();
		final Prop prop = (Prop) gameState.getGameElement();
		// TimedButton tbtn = null;		
		if (prop.getType().getTypeName().equals("Button1")) {
			jPanelScene = Util.panelPosition(prop.getLocation(), false, prop);
			jPanelScene.add(new FadingButtonTF(gameState));
			// jPanelScene.add(new JButton("Hello!!!!"));
			layeredPane.add(jPanelScene, new Integer(0), 100);
		} else if (prop.getType().getTypeName().equals("Button2")) {

			JButton btn = new JButton(prop.getText());
			if (prop.getColor() == null)
				btn.setBackground(new Color(255, 255, 255));
			else
				btn.setBackground(Util
						.StringToColor(prop.getColor().toString()));

			btn.setFont(new Font(prop.getFont().toString(), Font.PLAIN, Integer
					.parseInt(prop.getTextSize())));
			btn.setPreferredSize(Util.panelDimension(prop.getSize()));
			btn.setBorder(new LineBorder(Color.BLACK, 4));
			System.out
					.println("Button End GAme Created !!!!!@#$%@#$%!#$!@#$!@#$!@#$!@#$!@#$!@#$#!@");
			jPanelScene = Util.panelPosition(prop.getLocation(), false, prop);
			jPanelScene.add(btn);
			layeredPane.add(jPanelScene, new Integer(0), 100);

			btn.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {					
					resetLayeredPane();
				}
			});
		}else if(prop.getType().getTypeName().equals("Button3")){
			JButton btn = new JButton(prop.getText());
			if (prop.getColor() == null)
				btn.setBackground(new Color(255, 255, 255));
			else
				btn.setBackground(Util
						.StringToColor(prop.getColor().toString()));

			btn.setFont(new Font(prop.getFont().toString(), Font.PLAIN, Integer
					.parseInt(prop.getTextSize())));
			btn.setPreferredSize(Util.panelDimension(prop.getSize()));
			btn.setBorder(new LineBorder(Color.BLACK, 4));			
			jPanelScene = Util.panelPosition(prop.getLocation(), false, prop);
			jPanelScene.add(btn);
			layeredPane.add(jPanelScene, new Integer(0), 100);
			
			btn.addActionListener(new ActionListener() {				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					resetLayeredPane();
					System.out.println("Calling Next screen.......................");
					displayNext(prop, gameState);	
					//gameState.setMessage(Message.PlayComplete);
					//GameController.viewListener((Observable)prop, gameState);
				}
			});
			
		}
		/**
		 * Create panel with Act+Scene+Screen name. and populate with game
		 * elements. Once we create all the panels, link the panels with user
		 * interaction.
		 */

		// Retrieve Actname, Scenename, Screen name.
		final String btnText = prop.getText();
		final JFrame jFrameFinal = jFrame;
		// final TimedButton button = btn;
		/*
		 * btn.addActionListener(new ActionListener() {
		 * 
		 * @Override public void actionPerformed(ActionEvent arg0) {
		 * 
		 * // EndGame => End the current game.
		 * 
		 * if (btnText.trim().equals("End Game")) { resetLayeredPane(); }
		 * 
		 * // Read the Behavior tag of the game element and do accordingly. else
		 * {
		 * 
		 * 
		 * } } });
		 */
	}
}