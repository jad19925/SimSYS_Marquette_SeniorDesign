package gamePlayEngine.model.gameElement;

public class EndOfScreen extends ScreenDescription{

}
