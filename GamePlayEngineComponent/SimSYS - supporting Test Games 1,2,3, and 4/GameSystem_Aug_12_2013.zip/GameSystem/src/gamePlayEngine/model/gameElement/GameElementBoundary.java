/**
 * This file contains the Boundary class for GameElement Model. It is to be used if the current interaction with GameElement model becomes complex
 */
package gamePlayEngine.model.gameElement;

public class GameElementBoundary {

}
