package gamePlayEngine.model.gameElement.graphic;

public enum EventName {
	NONE,
	ENDGAME,
	CLICK
}